<?php
/**
 * Module : Pages personnalisées
 * CPT : nolimit_page | Route : GET /pages/{slug}
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Pages extends NoLimit_Module {
    public function register_post_types(): void {
        register_post_type('nolimit_page', ['labels' => ['name' => 'Pages NoLimit', 'singular_name' => 'Page', 'add_new' => 'Ajouter', 'all_items' => 'Pages'], 'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'supports' => ['title', 'editor', 'thumbnail']]);
    }

    public function get_api_routes(): array {
        return ['pages/(?P<slug>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_page']]];
    }

    public function api_page($request) {
        $post = get_page_by_path($request->get_param('slug'), OBJECT, ['page', 'nolimit_page']);
        if (!$post) return new WP_Error('not_found', 'Page non trouvée', ['status' => 404]);
        return rest_ensure_response(['id' => $post->ID, 'title' => $post->post_title, 'content' => $post->post_content]);
    }
}
