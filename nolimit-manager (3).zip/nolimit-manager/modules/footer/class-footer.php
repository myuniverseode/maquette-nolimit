<?php
/**
 * Module : Footer
 * Route : GET /nolimit/v1/footer
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Footer extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'footer' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_footer'],
            ],
        ];
    }

    public function api_footer(): WP_REST_Response {
        $quick = $this->opt('nl_f_quick', []);
        $quick_page_ids = $this->opt('nl_f_quick_page_ids', []);
        $legal = $this->opt('nl_f_legal', []);
        $legal_page_ids = $this->opt('nl_f_legal_page_ids', []);

        $quickLinks = [];
        if (is_array($quick)) {
            foreach ($quick as $i => $label) {
                if (!empty($label)) {
                    $page_id = $quick_page_ids[$i] ?? 0;
                    $quickLinks[] = ['label' => $label, 'to' => NoLimit_Helpers::page_url($page_id)];
                }
            }
        }

        $legalLinks = [];
        if (is_array($legal)) {
            foreach ($legal as $i => $label) {
                if (!empty($label)) {
                    $page_id = $legal_page_ids[$i] ?? 0;
                    $legalLinks[] = ['label' => $label, 'to' => NoLimit_Helpers::page_url($page_id)];
                }
            }
        }

        $logo_id = (int) $this->opt('nl_logo_id', 0);

        $data = [
            'logo' => [
                'url' => $logo_id ? wp_get_attachment_url($logo_id) : '',
                'alt' => $this->opt('nl_logo_alt', 'NoLimit Aventure'),
            ],
            'colors' => [
                'background' => $this->opt('nl_f_bg', '#111111'),
                'primary'    => $this->opt('nl_primary', '#357600'),
                'secondary'  => $this->opt('nl_secondary', '#eb700f'),
            ],
            'contact' => [
                'phone'       => $this->opt('nl_f_phone', '01 23 45 67 89'),
                'email'       => $this->opt('nl_f_email', 'contact@nolimit-aventure.fr'),
                'description' => $this->opt('nl_f_desc', '5 parcs multi-activités en France pour vivre des sensations fortes en pleine nature.'),
            ],
            'social' => [
                'facebook'  => $this->opt('nl_social_facebook', ''),
                'instagram' => $this->opt('nl_social_instagram', ''),
                'youtube'   => $this->opt('nl_social_youtube', ''),
                'twitter'   => $this->opt('nl_social_twitter', ''),
            ],
            'stats' => [
                ['number' => $this->opt('nl_f_stat1', '5'),   'label' => $this->opt('nl_f_stat1_label', 'Parcs')],
                ['number' => $this->opt('nl_f_stat2', '20+'), 'label' => $this->opt('nl_f_stat2_label', 'Activités')],
                ['number' => $this->opt('nl_f_stat3', '∞'),   'label' => $this->opt('nl_f_stat3_label', 'Souvenirs')],
            ],
            'quickLinks'    => $quickLinks,
            'activities'    => $this->get_activities_simple(),
            'legalLinks'    => $legalLinks,
            'cta' => [
                'title'      => $this->opt('nl_f_cta_title', "Rejoignez l'aventure"),
                'subtitle'   => $this->opt('nl_f_cta_sub', "Réservez dès maintenant et vivez une expérience inoubliable dans l'un de nos 5 parcs"),
                'bookingUrl' => $this->opt('nl_f_cta_booking_url', '/booking'),
                'contactUrl' => $this->opt('nl_f_cta_contact_url', '/contact'),
            ],
            'parks'         => $this->get_parks_for_footer(),
            'showBackToTop' => (bool) $this->opt('nl_f_show_back', 1),
            'currentYear'   => (int) date('Y'),
        ];

        return rest_ensure_response($data);
    }

    /**
     * Parks pour le footer — inclut TOUS les champs nécessaires
     * pour les bulles interactives du frontend
     */
    private function get_parks_for_footer(): array {
        $posts = $this->query('nolimit_parc');
        $parks = [];

        foreach ($posts as $post) {
            $id = $post->ID;
            $slug = $this->acf('parc_slug', $id) ?: sanitize_title($post->post_title);
            $acts = $this->acf('parc_activities', $id);

            $parks[] = [
                'id'         => $slug,
                'name'       => $post->post_title,
                'location'   => $this->acf('parc_location', $id, $post->post_title),
                'emoji'      => $this->acf('parc_emoji', $id, '📍'),
                'url'        => '/parks/' . $slug,
                'minAge'     => (int) ($this->acf('parc_min_age', $id) ?: 3),
                'rating'     => (float) ($this->acf('parc_rating', $id) ?: 4.5),
                'minPrice'   => (int) ($this->acf('parc_min_price', $id) ?: 25),
                'activities' => $acts ? array_map('trim', explode(',', $acts)) : [],
                'cgvUrl'     => $this->acf('parc_cgv_url',   $id, ''),
                'cgvLabel'   => $this->acf('parc_cgv_label', $id, ''),
            ];
        }

        return $parks;
    }

    private function get_activities_simple(): array {
        $posts = $this->query('nolimit_activity', 6);
        $activities = [];

        foreach ($posts as $post) {
            $activities[] = [
                'name'  => $post->post_title,
                'emoji' => $this->acf('activity_emoji', $post->ID, '🎯'),
                'link'  => '/activities/' . ($this->acf('activity_slug', $post->ID) ?: sanitize_title($post->post_title)),
            ];
        }

        return $activities;
    }
}
