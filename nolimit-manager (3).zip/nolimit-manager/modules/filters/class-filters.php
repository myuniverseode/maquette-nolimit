<?php

/**
 * Module : Filtres des Parcs
 *
 * Permet de gérer depuis WordPress les options de filtres affichées
 * dans le composant ParkFilters.tsx du frontend.
 *
 * Routes :
 *   GET  /filters        → retourne toutes les options de filtres
 *   POST /filters/save   → sauvegarde les options (admin uniquement)
 *
 * Options WordPress utilisées :
 *   nl_filters_activities   JSON — liste des activités filtrables
 *   nl_filters_transport    JSON — options de transport/accessibilité
 *   nl_filters_event_types  JSON — types d'événements
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Module_Filters extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'filters' => [
                'methods'             => 'GET',
                'callback'            => [$this, 'api_get'],
                'permission_callback' => '__return_true',
            ],
            'filters/save' => [
                'methods'             => 'POST',
                'callback'            => [$this, 'api_save'],
                'permission_callback' => [$this, 'check_admin'],
            ],
        ];
    }

    // ═══════════════════════════════════════════════════════════
    // PERMISSION
    // ═══════════════════════════════════════════════════════════

    public function check_admin(WP_REST_Request $request): bool {
        $key = $request->get_header('x-nolimit-key');
        return defined('NOLIMIT_API_KEY') && $key === NOLIMIT_API_KEY;
    }

    // ═══════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════

    /** Decode un JSON stocké en option, avec fallback tableau */
    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && !empty($decoded)) return $decoded;
        }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }

    // ── Valeurs par défaut ─────────────────────────────────────

    private function default_activities(): array {
        return [
            ['id' => 'accrobranche',   'label' => 'Accrobranche',          'emoji' => '🌳', 'active' => true],
            ['id' => 'paintball',      'label' => 'Paintball',              'emoji' => '🎯', 'active' => true],
            ['id' => 'escape-game',    'label' => 'Escape Game',            'emoji' => '🔐', 'active' => true],
            ['id' => 'tir-arc',        'label' => "Tir à l'arc",            'emoji' => '🏹', 'active' => true],
            ['id' => 'parcours-filet', 'label' => 'Parcours filet',         'emoji' => '🕸️', 'active' => true],
            ['id' => 'archery-tag',    'label' => 'Archery Tag',            'emoji' => '🎯', 'active' => true],
            ['id' => 'tyrolienne',     'label' => 'Tyrolienne',             'emoji' => '⚡', 'active' => true],
            ['id' => 'orientation',    'label' => 'Orientation',            'emoji' => '🧭', 'active' => true],
            ['id' => 'laser-game',     'label' => 'Laser Game',             'emoji' => '🔫', 'active' => true],
            ['id' => 'parcours-kids',  'label' => 'Parcours Kids',          'emoji' => '👶', 'active' => true],
        ];
    }

    private function default_transport(): array {
        return [
            ['id' => 'voiture', 'label' => 'En voiture', 'icon' => 'Car',   'description' => 'Parking gratuit',      'active' => true],
            ['id' => 'train',   'label' => 'En train',   'icon' => 'Train', 'description' => 'Gare à proximité',     'active' => true],
            ['id' => 'bus',     'label' => 'En bus',     'icon' => 'Bus',   'description' => 'Bus ou navette',       'active' => true],
        ];
    }

    private function default_event_types(): array {
        return [
            ['id' => 'evg',          'label' => 'EVG / EVJF',      'emoji' => '🥂', 'popular' => false, 'active' => true],
            ['id' => 'anniversaire', 'label' => 'Anniversaire',    'emoji' => '🎂', 'popular' => true,  'active' => true],
            ['id' => 'famille',      'label' => 'En famille',      'emoji' => '👨‍👩‍👧‍👦', 'popular' => false, 'active' => true],
            ['id' => 'entreprise',   'label' => 'Team Building',   'emoji' => '💼', 'popular' => false, 'active' => true],
            ['id' => 'scolaire',     'label' => 'Sortie scolaire', 'emoji' => '🏫', 'popular' => false, 'active' => true],
            ['id' => 'ami',          'label' => 'Entre amis',      'emoji' => '🤝', 'popular' => false, 'active' => true],
        ];
    }

    // ═══════════════════════════════════════════════════════════
    // API — GET /filters
    // ═══════════════════════════════════════════════════════════

    public function api_get(): WP_REST_Response {
        $activities  = $this->get_json_option('nl_filters_activities',  $this->default_activities());
        $transport   = $this->get_json_option('nl_filters_transport',   $this->default_transport());
        $event_types = $this->get_json_option('nl_filters_event_types', $this->default_event_types());

        // Filtrer les items désactivés avant de les envoyer au front
        $activities  = array_values(array_filter($activities,  fn($a) => !empty($a['active'])));
        $transport   = array_values(array_filter($transport,   fn($t) => !empty($t['active'])));
        $event_types = array_values(array_filter($event_types, fn($e) => !empty($e['active'])));

        return rest_ensure_response([
            'activities'  => $activities,
            'transport'   => $transport,
            'eventTypes'  => $event_types,
        ]);
    }

    // ═══════════════════════════════════════════════════════════
    // API — POST /filters/save  (usage admin interne)
    // ═══════════════════════════════════════════════════════════

    public function api_save(WP_REST_Request $request): WP_REST_Response {
        $body = $request->get_json_params();

        if (isset($body['activities'])) {
            update_option('nl_filters_activities', wp_json_encode($body['activities']));
        }
        if (isset($body['transport'])) {
            update_option('nl_filters_transport', wp_json_encode($body['transport']));
        }
        if (isset($body['eventTypes'])) {
            update_option('nl_filters_event_types', wp_json_encode($body['eventTypes']));
        }

        return rest_ensure_response(['success' => true, 'message' => 'Filtres sauvegardés.']);
    }

    // ═══════════════════════════════════════════════════════════
    // ADMIN — page de configuration
    // ═══════════════════════════════════════════════════════════

    public function get_admin_config(): array {
        return [
            'slug'  => 'nolimit-filters',
            'title' => '🔍 Filtres des Parcs',
            'view'  => NOLIMIT_PATH . 'admin/views/filters-settings.php',
        ];
    }

    /** Sauvegarde du formulaire admin (POST classique WordPress) */
    public function save_admin_form(): void {
        if (
            !isset($_POST['filters_nonce']) ||
            !wp_verify_nonce($_POST['filters_nonce'], 'nolimit_save_filters')
        ) return;

        // ── Activités ──
        $activities = [];
        if (!empty($_POST['filter_activities'])) {
            foreach ((array) $_POST['filter_activities'] as $item) {
                $activities[] = [
                    'id'     => sanitize_key($item['id'] ?? ''),
                    'label'  => sanitize_text_field($item['label'] ?? ''),
                    'emoji'  => sanitize_text_field($item['emoji'] ?? ''),
                    'active' => !empty($item['active']),
                ];
            }
        }
        if (!empty($activities)) {
            update_option('nl_filters_activities', wp_json_encode($activities));
        }

        // ── Transport ──
        $transport = [];
        if (!empty($_POST['filter_transport'])) {
            foreach ((array) $_POST['filter_transport'] as $item) {
                $transport[] = [
                    'id'          => sanitize_key($item['id'] ?? ''),
                    'label'       => sanitize_text_field($item['label'] ?? ''),
                    'icon'        => sanitize_text_field($item['icon'] ?? 'Car'),
                    'description' => sanitize_text_field($item['description'] ?? ''),
                    'active'      => !empty($item['active']),
                ];
            }
        }
        if (!empty($transport)) {
            update_option('nl_filters_transport', wp_json_encode($transport));
        }

        // ── Types d'événement ──
        $event_types = [];
        if (!empty($_POST['filter_event_types'])) {
            foreach ((array) $_POST['filter_event_types'] as $item) {
                $event_types[] = [
                    'id'      => sanitize_key($item['id'] ?? ''),
                    'label'   => sanitize_text_field($item['label'] ?? ''),
                    'emoji'   => sanitize_text_field($item['emoji'] ?? ''),
                    'popular' => !empty($item['popular']),
                    'active'  => !empty($item['active']),
                ];
            }
        }
        if (!empty($event_types)) {
            update_option('nl_filters_event_types', wp_json_encode($event_types));
        }
    }
}
