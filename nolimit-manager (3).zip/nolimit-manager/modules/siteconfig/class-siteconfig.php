<?php
/**
 * Module : Site Config (Configuration globale)
 *
 * Gère les paramètres transversaux :
 *  - Réseaux sociaux (par parc et globaux)
 *  - Labels du menu ancrage homepage
 *  - Labels des filtres d'activités
 *  - Config des services sur site (parking, snack, etc.)
 *  - Accessibilité
 *  - Tarification types
 *
 * Route : GET /site-config
 *         GET /site-config/park/{slug}  → config spécifique parc
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_SiteConfig extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'site-config' => ['methods' => 'GET', 'callback' => [$this, 'api_global']],
            'site-config/park/(?P<slug>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_park_config']],
        ];
    }

    public function api_global(): WP_REST_Response {
        return rest_ensure_response([
            'social' => [
                'facebook'  => $this->opt('nl_social_facebook', ''),
                'instagram' => $this->opt('nl_social_instagram', ''),
                'youtube'   => $this->opt('nl_social_youtube', ''),
                'twitter'   => $this->opt('nl_social_twitter', ''),
                'tiktok'    => $this->opt('nl_social_tiktok', ''),
                'linkedin'  => $this->opt('nl_social_linkedin', ''),
            ],
            'anchorMenu' => $this->get_json_option('nl_anchor_menu', [
                ['id' => 'parcs',      'label' => 'Parcs',       'section' => 'parcs'],
                ['id' => 'activites',  'label' => 'Activités',   'section' => 'activites'],
                ['id' => 'pourqui',    'label' => 'Pour Qui',    'section' => 'pourqui'],
                ['id' => 'actualites', 'label' => 'Actualités',  'section' => 'actualites'],
                ['id' => 'reserver',   'label' => 'Réserver',    'section' => 'reserver'],
            ]),
            'activityFilters' => $this->get_json_option('nl_activity_filters', [
                ['id' => 'all',          'label' => 'Toutes'],
                ['id' => 'accrobranche', 'label' => 'Accrobranche'],
                ['id' => 'team',         'label' => 'Team Building'],
                ['id' => 'family',       'label' => 'Famille'],
                ['id' => 'extreme',      'label' => 'Sensations fortes'],
            ]),
            'accessibility' => $this->get_json_option('nl_accessibility', [
                ['icon' => '♿',  'label' => 'Mobilité réduite (PMR)',      'detail' => "Accès rampes, sanitaires adaptés, parking PMR", 'available' => true],
                ['icon' => '👁️', 'label' => 'Déficience visuelle',         'detail' => "Parcours balisés, accueil simplifié",           'available' => true],
                ['icon' => '👂', 'label' => 'Déficience auditive',          'detail' => "Communication visuelle, supports écrits",       'available' => true],
                ['icon' => '🧠', 'label' => 'Handicap cognitif',            'detail' => "Activités adaptées sur réservation",            'available' => true],
                ['icon' => '🧒', 'label' => 'Poussettes & jeunes enfants', 'detail' => "Allées larges, zone jeux, aire de change",      'available' => true],
            ]),
            'onSiteServices' => $this->get_json_option('nl_onsite_services', [
                ['icon' => '🅿️', 'label' => 'Parking',    'sub' => '200 places · gratuit'],
                ['icon' => '🍽️', 'label' => 'Snack bar',   'sub' => 'Ouvert 10h–17h'],
                ['icon' => '🚿', 'label' => 'Vestiaires',  'sub' => 'Douches incluses'],
                ['icon' => '📶', 'label' => 'WiFi',        'sub' => 'Gratuit & illimité'],
                ['icon' => '🧰', 'label' => 'Matériel',    'sub' => 'Tout fourni'],
            ]),
            'pricingTypes' => $this->get_json_option('nl_pricing_types', [
                ['name' => 'Individuel',      'priceKey' => 'minPrice', 'description' => "Parfait pour une personne"],
                ['name' => 'Groupe (5-10)',    'priceKey' => 'groupPrice', 'description' => "Idéal entre amis"],
                ['name' => 'Entreprise',       'priceKey' => 'devis',   'description' => "Team building sur mesure"],
            ]),
            'transport' => $this->get_json_option('nl_transport', [
                ['icon' => 'Car',  'title' => 'Voiture', 'desc' => 'Parking gratuit sur place'],
                ['icon' => 'Bike', 'title' => 'Vélo',    'desc' => 'Piste cyclable à proximité'],
            ]),
            'difficultyLevels' => $this->get_json_option('nl_difficulty_levels', [
                ['key' => 'Débutant',      'label' => 'Accessible à tous',       'color' => '#22c55e'],
                ['key' => 'Intermédiaire', 'label' => 'Quelques notions requises','color' => '#eb700f'],
                ['key' => 'Avancé',        'label' => 'Expérience recommandée',   'color' => '#dc2626'],
                ['key' => 'Expert',        'label' => 'Profils confirmés',        'color' => '#7c3aed'],
            ]),
            'audienceTypes' => $this->get_json_option('nl_audience_types', [
                ['id' => 'family',    'emoji' => '👶', 'label' => 'Famille avec enfants',  'desc' => "Activité accessible dès le plus jeune âge.",         'color' => '#f59e0b'],
                ['id' => 'couple',    'emoji' => '💑', 'label' => 'En couple',              'desc' => "Partagez une montée d'adrénaline unique à deux.",    'color' => '#ec4899'],
                ['id' => 'friends',   'emoji' => '👯', 'label' => 'Entre amis',             'desc' => "Les meilleurs souvenirs se créent en groupe.",       'color' => '#eb700f'],
                ['id' => 'corporate', 'emoji' => '🏢', 'label' => 'Team building',          'desc' => "Cohésion d'équipe garantie.",                        'color' => '#3b82f6'],
                ['id' => 'evg',       'emoji' => '🎉', 'label' => 'EVG / EVJF',             'desc' => "Un programme qui marquera les esprits.",             'color' => '#8b5cf6'],
            ]),
        ]);
    }

    /** Config spécifique par parc (social, services sur site, etc.) */
    public function api_park_config($request): WP_REST_Response {
        $slug = $request->get_param('slug');
        $p = 'nl_park_' . $slug . '_';

        return rest_ensure_response([
            'slug' => $slug,
            'social' => [
                'facebook'  => $this->opt($p . 'social_facebook', $this->opt('nl_social_facebook', '')),
                'instagram' => $this->opt($p . 'social_instagram', $this->opt('nl_social_instagram', '')),
                'youtube'   => $this->opt($p . 'social_youtube', $this->opt('nl_social_youtube', '')),
                'tiktok'    => $this->opt($p . 'social_tiktok', $this->opt('nl_social_tiktok', '')),
            ],
            'anchorMenu'     => $this->get_json_option($p . 'anchor_menu', []),
            'onSiteServices' => $this->get_json_option($p . 'onsite_services', $this->get_json_option('nl_onsite_services', [])),
            'googleMapsUrl'  => $this->opt($p . 'google_maps_url', ''),
            'wazeUrl'        => $this->opt($p . 'waze_url', ''),
        ]);
    }

    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && !empty($decoded)) return $decoded;
        }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }
}
