<?php
/**
 * Module : Horaires & Calendrier
 *
 * Gère les horaires d'ouverture de chaque parc :
 *  - Horaires standards haute/basse saison
 *  - Jours de fermeture hebdomadaires
 *  - Fermetures exceptionnelles (jours fériés, travaux...)
 *  - Ouvertures exceptionnelles (nocturnes, événements...)
 *
 * Route : GET /nolimit/v1/horaires
 *         GET /nolimit/v1/horaires/{park_slug}
 *
 * Options WordPress (get_option) :
 *  nl_hor_{slug}_hs_open     Heure ouverture haute saison  (int, ex: 9)
 *  nl_hor_{slug}_hs_close    Heure fermeture haute saison  (int, ex: 19)
 *  nl_hor_{slug}_hs_start    Mois début haute saison       (int 0-11, ex: 3 = avril)
 *  nl_hor_{slug}_hs_end      Mois fin haute saison         (int 0-11, ex: 8 = sept)
 *  nl_hor_{slug}_bs_open     Heure ouverture basse saison  (int, ex: 10)
 *  nl_hor_{slug}_bs_close    Heure fermeture basse saison  (int, ex: 17)
 *  nl_hor_{slug}_closed_days Jours fermés (JSON array, ex: ["monday"])
 *  nl_hor_{slug}_except_closed  Fermetures exceptionnelles (JSON array)
 *  nl_hor_{slug}_except_open    Ouvertures exceptionnelles (JSON array)
 *  nl_hor_{slug}_message     Message d'info libre (string)
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Module_Horaires extends NoLimit_Module {

    // ─── Routes API ────────────────────────────────────────────

    public function get_api_routes(): array {
        return [
            'horaires' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_all'],
                'permission_callback' => '__return_true',
            ],
            'horaires/(?P<slug>[a-zA-Z0-9-]+)' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_single'],
                'permission_callback' => '__return_true',
            ],
        ];
    }

    // ─── Callbacks API ─────────────────────────────────────────

    public function api_all(): WP_REST_Response {
        $slugs = $this->get_park_slugs();
        $result = [];
        foreach ($slugs as $slug) {
            $result[$slug] = $this->get_horaires_for($slug);
        }
        return rest_ensure_response($result);
    }

    public function api_single(WP_REST_Request $request): WP_REST_Response|WP_Error {
        $slug = $request->get_param('slug');
        $slugs = $this->get_park_slugs();

        if (!in_array($slug, $slugs, true)) {
            return new WP_Error('not_found', 'Parc non trouvé', ['status' => 404]);
        }

        return rest_ensure_response($this->get_horaires_for($slug));
    }

    // ─── Lecture des données ───────────────────────────────────

    private function get_park_slugs(): array {
        $posts = $this->query('nolimit_parc');
        $slugs = [];
        foreach ($posts as $post) {
            $slug = get_field('parc_slug', $post->ID);
            if (!$slug) $slug = sanitize_title($post->post_title);
            $slugs[] = $slug;
        }
        // Fallback si aucun parc en base
        if (empty($slugs)) {
            $slugs = ['nolimit-chevry', 'nolimit-nemours', 'nolimit-montargis', 'nolimit-digny', 'nolimit-coudray'];
        }
        return $slugs;
    }

    private function get_horaires_for(string $slug): array {
        $p = 'nl_hor_' . $slug . '_';

        $closed_raw  = get_option($p . 'closed_days', '["monday"]');
        $excl_raw    = get_option($p . 'except_closed', '[]');
        $exop_raw    = get_option($p . 'except_open', '[]');

        return [
            'slug'         => $slug,
            'hauteSaison'  => [
                'moisDebut' => (int) get_option($p . 'hs_start', 3),   // 3 = avril (0-indexé)
                'moisFin'   => (int) get_option($p . 'hs_end', 8),     // 8 = septembre
                'ouverture' => (int) get_option($p . 'hs_open', 9),
                'fermeture' => (int) get_option($p . 'hs_close', 19),
            ],
            'basseSaison'  => [
                'ouverture' => (int) get_option($p . 'bs_open', 10),
                'fermeture' => (int) get_option($p . 'bs_close', 17),
            ],
            'joursFermes'  => json_decode($closed_raw, true) ?: ['monday'],
            'fermeturesExcep' => json_decode($excl_raw, true) ?: [],
            'ouverturesExcep' => json_decode($exop_raw, true) ?: [],
            'message'      => get_option($p . 'message', ''),
        ];
    }

    // ─── ACF (optionnel - non utilisé ici car on passe par get_option) ─

    public function register_acf_fields(): void {}
}
