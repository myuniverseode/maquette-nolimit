<?php
/**
 * Module : Booking Configuration
 *
 * Gère la configuration de la page de réservation (Quickle, créneaux, etc.)
 * Route : GET /booking/config
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Booking extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'booking/config' => ['methods' => 'GET', 'callback' => [$this, 'api_config']],
        ];
    }

    public function api_config(): WP_REST_Response {
        $time_slots = $this->get_json_option('nl_booking_time_slots', [
            ['value' => '09:00', 'label' => '9h00'],
            ['value' => '10:00', 'label' => '10h00'],
            ['value' => '11:00', 'label' => '11h00'],
            ['value' => '13:00', 'label' => '13h00'],
            ['value' => '14:00', 'label' => '14h00'],
            ['value' => '15:00', 'label' => '15h00'],
            ['value' => '16:00', 'label' => '16h00'],
        ]);

        return rest_ensure_response([
            'title'         => $this->opt('nl_booking_title', 'Réservation'),
            'subtitle'      => $this->opt('nl_booking_subtitle', 'Choisissez votre créneau'),
            'quickleUrl'    => $this->opt('nl_booking_quickle_url', ''),
            'quickleEnabled' => (bool) $this->opt('nl_booking_quickle_enabled', 1),
            'minParticipants' => (int) $this->opt('nl_booking_min_participants', 1),
            'maxParticipants' => (int) $this->opt('nl_booking_max_participants', 30),
            'timeSlots'     => $time_slots,
            'closedMessage' => $this->opt('nl_booking_closed_msg', "Les réservations en ligne sont temporairement fermées."),
            'enabled'       => (bool) $this->opt('nl_booking_enabled', 1),
        ]);
    }

    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && !empty($decoded)) return $decoded;
        }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }
}
