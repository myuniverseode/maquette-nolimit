<?php

/**
 * Module : Bloc Texte (entre Hero et Parcs)
 *
 * Route : GET /nolimit/v1/text-bloc
 *
 * Options WordPress :
 *   nl_textbloc_enabled        bool
 *   nl_textbloc_badge          string
 *   nl_textbloc_title          string  (supporte **vert** et ~~orange~~)
 *   nl_textbloc_text           string  (paragraphe principal)
 *   nl_textbloc_text_secondary string  (paragraphe secondaire)
 *   nl_textbloc_cta_label      string
 *   nl_textbloc_cta_url        string
 *   nl_textbloc_stats          JSON    (tableau de {value, label, sublabel?})
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Module_TextBloc extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'text-bloc' => [
                'methods'             => 'GET',
                'callback'            => [$this, 'api_get'],
                'permission_callback' => '__return_true',
            ],
        ];
    }

    // ── Valeurs par défaut ─────────────────────────────────────

    private function default_stats(): array {
        return [
            ['value' => '5',       'label' => 'Parcs en France',      'sublabel' => 'Île-de-France & régions'],
            ['value' => '+10 000', 'label' => 'Aventuriers / an',      'sublabel' => 'Nous font confiance'    ],
            ['value' => '15+',     'label' => 'Activités différentes', 'sublabel' => 'Pour tous les niveaux'  ],
            ['value' => '4.9★',   'label' => 'Note moyenne',          'sublabel' => 'Sur +1 200 avis'         ],
        ];
    }

    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) {
            $d = json_decode($raw, true);
            if (is_array($d) && !empty($d)) return $d;
        }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }

    // ── Endpoint GET /text-bloc ────────────────────────────────

    public function api_get(): WP_REST_Response {
        $stats = $this->get_json_option('nl_textbloc_stats', $this->default_stats());

        return rest_ensure_response([
            'enabled'       => (bool) $this->opt('nl_textbloc_enabled', 1),
            'badge'         => $this->opt('nl_textbloc_badge',          'NoLimit Aventure'),
            'title'         => $this->opt('nl_textbloc_title',          "L'aventure **en pleine nature**, c'est maintenant"),
            'text'          => $this->opt('nl_textbloc_text',           "Depuis plus de 10 ans, NoLimit Aventure vous propose des expériences outdoor uniques dans 5 parcs à travers la France."),
            'textSecondary' => $this->opt('nl_textbloc_text_secondary', "Familles, entreprises, groupes d'amis — chaque sortie devient un souvenir inoubliable."),
            'cta'           => [
                'label' => $this->opt('nl_textbloc_cta_label', 'Découvrir nos activités'),
                'url'   => $this->opt('nl_textbloc_cta_url',   '/activites'),
            ],
            'stats' => $stats,
        ]);
    }

    // ── Données par défaut (activation plugin) ─────────────────

    public function create_defaults(): void {
        if (get_option('nl_textbloc_title')) return;

        update_option('nl_textbloc_enabled', 1);
        update_option('nl_textbloc_badge',   'NoLimit Aventure');
        update_option('nl_textbloc_title',   "L'aventure **en pleine nature**, c'est maintenant");
        update_option('nl_textbloc_text',    "Depuis plus de 10 ans, NoLimit Aventure vous propose des expériences outdoor uniques dans 5 parcs à travers la France. Accrobranche, paintball, escape game, tyrolienne… il y en a pour tous les goûts et tous les âges.");
        update_option('nl_textbloc_text_secondary', "Familles, entreprises, groupes d'amis — chaque sortie devient un souvenir inoubliable.");
        update_option('nl_textbloc_cta_label', 'Découvrir nos activités');
        update_option('nl_textbloc_cta_url',   '/activites');
        update_option('nl_textbloc_stats', wp_json_encode($this->default_stats(), JSON_UNESCAPED_UNICODE));
    }
}
