<?php
/**
 * Module : Actualités / News
 * CPT : nolimit_news
 * Routes : GET /news, GET /news/{slug}, GET /actualites (homepage format)
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_News extends NoLimit_Module {
    public function register_post_types(): void {
        register_post_type('nolimit_news', ['labels' => ['name' => 'Actualités', 'singular_name' => 'Actualité', 'add_new' => 'Ajouter', 'all_items' => 'Actualités'], 'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'page-attributes']]);
    }

    public function register_taxonomies(): void {
        register_taxonomy('nolimit_news_category', 'nolimit_news', ['labels' => ['name' => 'Catégories Actualités', 'singular_name' => 'Catégorie'], 'hierarchical' => true, 'show_ui' => true, 'show_admin_column' => true]);
    }

    public function register_acf_fields(): void {
        acf_add_local_field_group(['key' => 'group_news', 'title' => 'Article', 'fields' => [
            ['key' => 'field_news_featured', 'label' => 'À la une', 'name' => 'news_featured', 'type' => 'true_false'],
            ['key' => 'field_news_is_event', 'label' => 'Est un événement', 'name' => 'news_is_event', 'type' => 'true_false'],
            ['key' => 'field_news_event_link', 'label' => "Lien d'inscription (si événement)", 'name' => 'news_event_link', 'type' => 'url', 'conditional_logic' => [[['field' => 'field_news_is_event', 'operator' => '==', 'value' => '1']]]],
            ['key' => 'field_news_category_tag', 'label' => 'Catégorie affichée', 'name' => 'news_category_tag', 'type' => 'text', 'placeholder' => 'Ex: Événement, Nouveau parcours...'],
            ['key' => 'field_news_author_name', 'label' => 'Auteur affiché', 'name' => 'news_author_name', 'type' => 'text'],
        ], 'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_news']]]]);
    }

    public function get_api_routes(): array {
        return [
            'news' => ['methods' => 'GET', 'callback' => [$this, 'api_list']],
            'news/(?P<slug>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_single']],
            'actualites' => ['methods' => 'GET', 'callback' => [$this, 'api_actualites']],
        ];
    }

    /**
     * Endpoint homepage : retourne les articles formatés pour la section Actualités
     */
    public function api_actualites($request) {
        $max = $request->get_param('limit') ?: (int) $this->opt('nl_home_actualites_max_items', 3);
        $posts = get_posts(['post_type' => 'nolimit_news', 'posts_per_page' => $max, 'orderby' => 'date', 'order' => 'DESC']);

        $articles = [];
        foreach ($posts as $post) {
            $articles[] = [
                'id'               => (string) $post->ID,
                'titre'            => $post->post_title,
                'date'             => get_the_date('Y-m-d', $post),
                'image'            => get_the_post_thumbnail_url($post->ID, 'large') ?: '',
                'extrait'          => $post->post_excerpt ?: wp_trim_words($post->post_content, 30),
                'isEvenement'      => (bool) $this->acf('news_is_event', $post->ID),
                'lienInscription'  => $this->acf('news_event_link', $post->ID) ?: null,
                'lien'             => '/actualites/' . $post->post_name,
                'categorie'        => $this->acf('news_category_tag', $post->ID),
                'auteur'           => $this->acf('news_author_name', $post->ID),
            ];
        }

        return rest_ensure_response([
            'title'             => $this->opt('nl_home_actualites_title', 'Actualités & Événements'),
            'subtitle'          => $this->opt('nl_home_actualites_subtitle', 'Restez informé de nos dernières nouveautés et événements spéciaux'),
            'showViewAllButton' => true,
            'viewAllUrl'        => '/actualites',
            'articles'          => $articles,
        ]);
    }

    public function api_list($request) {
        $page = $request->get_param('page') ?: 1;
        $per_page = $request->get_param('per_page') ?: 10;
        $posts = get_posts(['post_type' => 'nolimit_news', 'posts_per_page' => $per_page, 'paged' => $page, 'orderby' => 'date', 'order' => 'DESC']);
        $news = [];
        foreach ($posts as $post) {
            $news[] = [
                'id' => $post->ID, 'title' => $post->post_title, 'slug' => $post->post_name,
                'excerpt' => $post->post_excerpt ?: wp_trim_words($post->post_content, 30),
                'date' => get_the_date('j F Y', $post),
                'image' => get_the_post_thumbnail_url($post->ID, 'large'),
                'featured' => (bool) $this->acf('news_featured', $post->ID),
                'isEvent' => (bool) $this->acf('news_is_event', $post->ID),
                'eventLink' => $this->acf('news_event_link', $post->ID),
                'category' => $this->acf('news_category_tag', $post->ID),
                'author' => $this->acf('news_author_name', $post->ID),
            ];
        }
        return rest_ensure_response($news);
    }

    public function api_single($request) {
        $post = get_page_by_path($request->get_param('slug'), OBJECT, 'nolimit_news');
        if (!$post) return new WP_Error('not_found', 'Article non trouvé', ['status' => 404]);
        return rest_ensure_response([
            'id' => $post->ID, 'title' => $post->post_title, 'slug' => $post->post_name,
            'content' => $post->post_content, 'date' => get_the_date('j F Y', $post),
            'image' => get_the_post_thumbnail_url($post->ID, 'large'),
            'isEvent' => (bool) $this->acf('news_is_event', $post->ID),
            'eventLink' => $this->acf('news_event_link', $post->ID),
            'category' => $this->acf('news_category_tag', $post->ID),
            'author' => $this->acf('news_author_name', $post->ID),
        ]);
    }
}
