<?php
/**
 * Module : Newsletter
 *
 * Gère la configuration de la section newsletter et l'inscription.
 * Routes : GET  /nolimit/v1/newsletter
 *          POST /nolimit/v1/newsletter/subscribe
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Newsletter extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'newsletter' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_config'],
            ],
            'newsletter/subscribe' => [
                'methods'  => 'POST',
                'callback' => [$this, 'api_subscribe'],
            ],
        ];
    }

    public function api_config(): WP_REST_Response {
        $benefits = [];
        for ($i = 1; $i <= 3; $i++) {
            $icon  = $this->opt("nl_nl_benefit_{$i}_icon", '');
            $title = $this->opt("nl_nl_benefit_{$i}_title", '');
            $desc  = $this->opt("nl_nl_benefit_{$i}_desc", '');
            if ($title) {
                $benefits[] = [
                    'icon'        => $icon,
                    'title'       => $title,
                    'description' => $desc,
                ];
            }
        }

        // Fallback
        if (empty($benefits)) {
            $benefits = [
                ['icon' => '🎟️', 'title' => 'Offres exclusives', 'description' => 'Réductions réservées aux abonnés'],
                ['icon' => '🎯', 'title' => 'Nouveautés en avant-première', 'description' => 'Soyez les premiers informés'],
                ['icon' => '💡', 'title' => "Conseils d'experts", 'description' => 'Astuces pour profiter au maximum'],
            ];
        }

        $data = [
            'title'          => $this->opt('nl_nl_title', 'Restez informé de nos aventures'),
            'subtitle'       => $this->opt('nl_nl_subtitle', "Recevez nos offres exclusives, nouveautés et conseils d'aventure directement dans votre boîte mail"),
            'placeholder'    => $this->opt('nl_nl_placeholder', 'Votre adresse email'),
            'buttonText'     => $this->opt('nl_nl_button', "S'inscrire"),
            'privacyNotice'  => $this->opt('nl_nl_privacy', 'En vous inscrivant, vous acceptez de recevoir nos emails. Vous pouvez vous désabonner à tout moment.'),
            'successMessage' => $this->opt('nl_nl_success', 'Merci ! Vous êtes inscrit à notre newsletter'),
            'benefits'       => $benefits,
            'brevoListId'    => $this->opt('nl_nl_brevo_list_id', ''),
            'brevoApiKey'    => '', // Ne pas exposer la clé API côté front
        ];

        return rest_ensure_response($data);
    }

    public function api_subscribe($request): WP_REST_Response|WP_Error {
        $data  = $request->get_json_params();
        $email = sanitize_email($data['email'] ?? '');

        if (!is_email($email)) {
            return new WP_Error('invalid_email', 'Email invalide', ['status' => 400]);
        }

        // Si Brevo est configuré, envoyer via API
        $brevo_key = $this->opt('nl_nl_brevo_api_key', '');
        $brevo_list = (int) $this->opt('nl_nl_brevo_list_id', 0);

        if ($brevo_key && $brevo_list) {
            $response = wp_remote_post('https://api.brevo.com/v3/contacts', [
                'headers' => [
                    'api-key'      => $brevo_key,
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ],
                'body' => wp_json_encode([
                    'email'            => $email,
                    'listIds'          => [$brevo_list],
                    'updateEnabled'    => true,
                ]),
            ]);

            if (is_wp_error($response)) {
                return new WP_Error('brevo_error', "Erreur d'inscription", ['status' => 500]);
            }
        }

        // Stocker localement aussi
        $subscribers = get_option('nl_newsletter_subscribers', []);
        if (!in_array($email, $subscribers)) {
            $subscribers[] = $email;
            update_option('nl_newsletter_subscribers', $subscribers);
        }

        return rest_ensure_response([
            'success' => true,
            'message' => $this->opt('nl_nl_success', 'Merci ! Vous êtes inscrit à notre newsletter'),
        ]);
    }

    public function create_defaults(): void {
        if (get_option('nl_nl_title')) return;

        $defaults = [
            'nl_nl_title'           => 'Restez informé de nos aventures',
            'nl_nl_subtitle'        => "Recevez nos offres exclusives, nouveautés et conseils d'aventure directement dans votre boîte mail",
            'nl_nl_placeholder'     => 'Votre adresse email',
            'nl_nl_button'          => "S'inscrire",
            'nl_nl_privacy'         => 'En vous inscrivant, vous acceptez de recevoir nos emails. Vous pouvez vous désabonner à tout moment.',
            'nl_nl_success'         => 'Merci ! Vous êtes inscrit à notre newsletter',
            'nl_nl_benefit_1_icon'  => '🎟️',
            'nl_nl_benefit_1_title' => 'Offres exclusives',
            'nl_nl_benefit_1_desc'  => 'Réductions réservées aux abonnés',
            'nl_nl_benefit_2_icon'  => '🎯',
            'nl_nl_benefit_2_title' => 'Nouveautés en avant-première',
            'nl_nl_benefit_2_desc'  => 'Soyez les premiers informés',
            'nl_nl_benefit_3_icon'  => '💡',
            'nl_nl_benefit_3_title' => "Conseils d'experts",
            'nl_nl_benefit_3_desc'  => 'Astuces pour profiter au maximum',
        ];

        foreach ($defaults as $key => $value) {
            update_option($key, $value);
        }
    }
}
