<?php
/**
 * Module : Avis (enrichi)
 * CPT  : nolimit_review
 * Route : GET /nolimit/v1/reviews(?park=slug)
 *
 * Supporte :
 *  - Avis manuels saisis dans WordPress
 *  - Source de l'avis (google, tripadvisor, manual)
 *  - Tag/catégorie (Famille, Entreprise, Anniversaire, etc.)
 *  - Avatar emoji ou image
 *  - Filtrage par parc
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Reviews extends NoLimit_Module {

    // ─── CPT ─────────────────────────────────────────
    public function register_post_types(): void {
        register_post_type('nolimit_review', [
            'labels' => [
                'name' => 'Avis', 'singular_name' => 'Avis',
                'add_new' => 'Ajouter un avis', 'all_items' => 'Tous les avis',
            ],
            'public' => false, 'show_ui' => true, 'show_in_menu' => false,
            'supports' => ['title', 'editor', 'page-attributes'],
        ]);
    }

    // ─── ACF ─────────────────────────────────────────
    public function register_acf_fields(): void {
        acf_add_local_field_group([
            'key' => 'group_review', 'title' => 'Avis Client',
            'fields' => [
                ['key' => 'field_review_author',  'label' => 'Auteur',        'name' => 'review_author',  'type' => 'text'],
                ['key' => 'field_review_rating',  'label' => 'Note (1-5)',    'name' => 'review_rating',  'type' => 'number', 'min' => 1, 'max' => 5, 'default_value' => 5],
                ['key' => 'field_review_date',    'label' => 'Date',          'name' => 'review_date',    'type' => 'text', 'placeholder' => 'Janvier 2025'],
                ['key' => 'field_review_source',  'label' => 'Source',        'name' => 'review_source',  'type' => 'select',
                    'choices' => ['google' => 'Google', 'tripadvisor' => 'TripAdvisor', 'manual' => 'Manuel'],
                    'default_value' => 'manual',
                ],
                ['key' => 'field_review_tag',     'label' => 'Tag / Catégorie', 'name' => 'review_tag', 'type' => 'select',
                    'choices' => [
                        '' => '— Aucun —',
                        'Famille' => 'Famille',
                        'Entreprise' => 'Entreprise',
                        'Anniversaire' => 'Anniversaire',
                        'Amis' => 'Amis',
                        'EVJF' => 'EVJF / EVG',
                        'Team Building' => 'Team Building',
                        'Couple' => 'Couple',
                        'Scolaire' => 'Scolaire',
                    ],
                    'allow_null' => 1,
                ],
                ['key' => 'field_review_avatar',  'label' => 'Avatar (emoji ou image)', 'name' => 'review_avatar', 'type' => 'text', 'placeholder' => '🧗 ou URL image', 'instructions' => 'Emoji (ex: 🧗) ou URL d\'image'],
                ['key' => 'field_review_park',    'label' => 'Parc associé',  'name' => 'review_park',    'type' => 'post_object', 'post_type' => ['nolimit_parc'], 'allow_null' => 1],
            ],
            'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_review']]],
        ]);
    }

    // ─── Routes API ──────────────────────────────────
    public function get_api_routes(): array {
        return [
            'reviews' => ['methods' => 'GET', 'callback' => [$this, 'api_list']],
        ];
    }

    public function api_list($request) {
        $park_filter = $request->get_param('park');
        $source_filter = $request->get_param('source');
        $limit = $request->get_param('limit');
        $posts = $this->query('nolimit_review', $limit ? (int) $limit : -1, 'date', 'DESC');
        $reviews = [];

        foreach ($posts as $post) {
            $review_park = $this->acf('review_park', $post->ID);
            $review_park_id = null;
            $review_park_name = null;

            if ($review_park) {
                $review_park_id = $this->acf('parc_slug', $review_park) ?: sanitize_title(get_the_title($review_park));
                $review_park_name = get_the_title($review_park);
            }

            // Filtrage par parc
            if ($park_filter && $review_park_id !== $park_filter) continue;

            $source = $this->acf('review_source', $post->ID, 'manual');

            // Filtrage par source
            if ($source_filter && $source !== $source_filter) continue;

            $reviews[] = [
                'id'       => $post->ID,
                'author'   => $this->acf('review_author', $post->ID) ?: $post->post_title,
                'avatar'   => $this->acf('review_avatar', $post->ID, '⭐'),
                'rating'   => (int) ($this->acf('review_rating', $post->ID) ?: 5),
                'date'     => $this->acf('review_date', $post->ID) ?: get_the_date('F Y', $post),
                'comment'  => $post->post_content,
                'source'   => $source,
                'tag'      => $this->acf('review_tag', $post->ID, ''),
                'parkId'   => $review_park_id,
                'parkName' => $review_park_name,
            ];
        }

        return rest_ensure_response($reviews);
    }

    // ─── Données par défaut ──────────────────────────
    public function create_defaults(): void {
        if (get_posts(['post_type' => 'nolimit_review', 'posts_per_page' => 1])) return;
        $reviews = [
            ['author' => 'Camille D.', 'rating' => 5, 'date' => 'Janvier 2025', 'source' => 'google', 'tag' => 'Famille', 'avatar' => '🧗', 'comment' => 'Une journée magique avec toute la famille ! Les parcours accrobranche sont variés et bien entretenus. Les moniteurs sont très attentionnés avec les enfants. On reviendra sans hésiter.'],
            ['author' => 'Antoine V.', 'rating' => 5, 'date' => 'Décembre 2024', 'source' => 'tripadvisor', 'tag' => 'Entreprise', 'avatar' => '💼', 'comment' => "Excellent team-building pour notre équipe de 15 personnes. Organisation au top, staff professionnel et souriant. La tyrolienne de 300m est incroyable !"],
            ['author' => 'Nathalie R.', 'rating' => 5, 'date' => 'Novembre 2024', 'source' => 'google', 'tag' => 'Anniversaire', 'avatar' => '🎂', 'comment' => "Anniversaire de mon fils réussi à 100% ! Le parc a tout géré parfaitement, les enfants ont adoré."],
            ['author' => 'Julien M.', 'rating' => 4, 'date' => 'Octobre 2024', 'source' => 'google', 'tag' => 'Amis', 'avatar' => '🎯', 'comment' => "Très bonne expérience globale. Les activités sont nombreuses et bien pensées pour tous les niveaux."],
            ['author' => 'Sophie L.', 'rating' => 5, 'date' => 'Septembre 2024', 'source' => 'tripadvisor', 'tag' => 'EVJF', 'avatar' => '🥂', 'comment' => "Notre EVJF était parfait ! L'équipe a su adapter les activités pour notre groupe et nous a réservé des surprises inattendues."],
            ['author' => 'Marc T.', 'rating' => 5, 'date' => 'Août 2024', 'source' => 'google', 'tag' => 'Famille', 'avatar' => '🌟', 'comment' => "Le meilleur parc de loisirs de la région sans aucun doute. Rapport qualité-prix excellent."],
        ];
        foreach ($reviews as $i => $r) {
            $id = wp_insert_post(['post_title' => $r['author'], 'post_content' => $r['comment'], 'post_type' => 'nolimit_review', 'post_status' => 'publish', 'menu_order' => $i]);
            if (!$id) continue;
            update_field('review_author', $r['author'], $id);
            update_field('review_rating', $r['rating'], $id);
            update_field('review_date', $r['date'], $id);
            update_field('review_source', $r['source'], $id);
            update_field('review_tag', $r['tag'], $id);
            update_field('review_avatar', $r['avatar'], $id);
        }
    }
}
