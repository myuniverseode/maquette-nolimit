<?php
/**
 * Module : Menu Items
 * CPT : nolimit_menu (pas de route API propre, utilisé par Header)
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Menu extends NoLimit_Module {
    public function register_post_types(): void {
        register_post_type('nolimit_menu', ['labels' => ['name' => 'Menu Items', 'singular_name' => 'Menu Item', 'add_new' => 'Ajouter', 'all_items' => 'Menu Items'], 'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'supports' => ['title', 'page-attributes']]);
    }

    public function register_acf_fields(): void {
        acf_add_local_field_group(['key' => 'group_menu', 'title' => 'Configuration Menu', 'fields' => [
            ['key' => 'field_menu_type', 'label' => 'Type', 'name' => 'menu_type', 'type' => 'select', 'choices' => ['simple' => 'Lien Simple', 'megamenu' => 'Mega Menu']],
            ['key' => 'field_menu_url', 'label' => 'URL', 'name' => 'menu_url', 'type' => 'text', 'conditional_logic' => [[['field' => 'field_menu_type', 'operator' => '==', 'value' => 'simple']]]],
            ['key' => 'field_megamenu_type', 'label' => 'Type Mega Menu', 'name' => 'megamenu_type', 'type' => 'select', 'choices' => ['discover' => 'Découvrir', 'audience' => 'Pour qui ?', 'groups' => 'Groupes', 'prepare' => 'Préparer'], 'conditional_logic' => [[['field' => 'field_menu_type', 'operator' => '==', 'value' => 'megamenu']]]],
        ], 'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_menu']]]]);
    }

    // Pas de route API propre - les données menu sont consommées par le module Header
    public function get_api_routes(): array {
        return [];
    }

    public function create_defaults(): void {
        if (get_posts(['post_type' => 'nolimit_menu', 'posts_per_page' => 1])) return;
        $menus = [
            ['title' => 'Accueil', 'type' => 'simple', 'url' => '/'],
            ['title' => 'Découvrir', 'type' => 'megamenu', 'megamenu_type' => 'discover'],
            ['title' => 'Activités', 'type' => 'simple', 'url' => '/activities'],
            ['title' => 'Pour qui ?', 'type' => 'megamenu', 'megamenu_type' => 'audience'],
            ['title' => 'Groupes', 'type' => 'megamenu', 'megamenu_type' => 'groups'],
            ['title' => 'Préparer', 'type' => 'megamenu', 'megamenu_type' => 'prepare'],
            ['title' => 'Contact', 'type' => 'simple', 'url' => '/contact'],
        ];
        foreach ($menus as $i => $menu) {
            $id = wp_insert_post(['post_title' => $menu['title'], 'post_type' => 'nolimit_menu', 'post_status' => 'publish', 'menu_order' => $i]);
            if ($id) {
                update_field('menu_type', $menu['type'], $id);
                if ($menu['type'] === 'simple') { update_field('menu_url', $menu['url'], $id); }
                else { update_field('megamenu_type', $menu['megamenu_type'], $id); }
            }
        }
    }
}
