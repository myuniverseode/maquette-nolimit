<?php
/**
 * Module : Blog / Conseils
 *
 * CPT : nolimit_blog
 * Taxonomy : nolimit_blog_category
 *
 * Routes :
 *   GET /blog             → liste des articles + catégories
 *   GET /blog/{slug}      → article complet
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Blog extends NoLimit_Module {

    public function register_post_types(): void {
        register_post_type('nolimit_blog', [
            'labels' => ['name' => 'Blog / Conseils', 'singular_name' => 'Article Blog', 'add_new' => 'Ajouter', 'all_items' => 'Blog'],
            'public' => false, 'show_ui' => true, 'show_in_menu' => false,
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'page-attributes'],
        ]);
    }

    public function register_taxonomies(): void {
        register_taxonomy('nolimit_blog_category', 'nolimit_blog', [
            'labels' => ['name' => 'Catégories Blog', 'singular_name' => 'Catégorie'],
            'hierarchical' => true, 'show_ui' => true, 'show_admin_column' => true,
        ]);
    }

    public function register_acf_fields(): void {
        acf_add_local_field_group(['key' => 'group_blog', 'title' => 'Article Blog', 'fields' => [
            ['key' => 'field_blog_subtitle',   'label' => 'Sous-titre',         'name' => 'blog_subtitle',    'type' => 'text'],
            ['key' => 'field_blog_read_time',   'label' => 'Temps de lecture',   'name' => 'blog_read_time',   'type' => 'text', 'placeholder' => '8 min'],
            ['key' => 'field_blog_author',      'label' => 'Auteur',             'name' => 'blog_author',      'type' => 'text'],
            ['key' => 'field_blog_author_role',  'label' => "Rôle de l'auteur",  'name' => 'blog_author_role', 'type' => 'text'],
            ['key' => 'field_blog_difficulty',   'label' => 'Niveau',            'name' => 'blog_difficulty',  'type' => 'select', 'choices' => ['debutant' => 'Débutant', 'intermediaire' => 'Intermédiaire', 'avance' => 'Avancé']],
            ['key' => 'field_blog_views',        'label' => 'Nombre de vues',    'name' => 'blog_views',       'type' => 'number', 'default_value' => 0],
            ['key' => 'field_blog_tags',         'label' => 'Tags (virgules)',   'name' => 'blog_tags',        'type' => 'text'],
            ['key' => 'field_blog_featured',     'label' => 'Mis en avant',      'name' => 'blog_featured',    'type' => 'true_false'],
            ['key' => 'field_blog_park',         'label' => 'Parc associé',      'name' => 'blog_park',        'type' => 'post_object', 'post_type' => ['nolimit_parc'], 'allow_null' => 1],
        ], 'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_blog']]]]);
    }

    public function get_api_routes(): array {
        return [
            'blog' => ['methods' => 'GET', 'callback' => [$this, 'api_list']],
            'blog/(?P<slug>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_single']],
        ];
    }

    public function api_list($request) {
        $per_page = $request->get_param('per_page') ?: 20;
        $category = $request->get_param('category') ?: '';
        $park = $request->get_param('park') ?: '';

        $args = ['post_type' => 'nolimit_blog', 'posts_per_page' => $per_page, 'orderby' => 'date', 'order' => 'DESC'];

        if ($category) {
            $args['tax_query'] = [['taxonomy' => 'nolimit_blog_category', 'field' => 'slug', 'terms' => $category]];
        }

        $posts = get_posts($args);
        $articles = [];

        foreach ($posts as $post) {
            $park_post = $this->acf('blog_park', $post->ID);
            $park_slug = $park_post ? ($this->acf('parc_slug', $park_post) ?: sanitize_title(get_the_title($park_post))) : null;

            if ($park && $park_slug !== $park) continue;

            $cats = wp_get_post_terms($post->ID, 'nolimit_blog_category', ['fields' => 'names']);
            $tags_raw = $this->acf('blog_tags', $post->ID);

            $articles[] = [
                'id'         => $post->ID,
                'slug'       => $post->post_name,
                'title'      => $post->post_title,
                'subtitle'   => $this->acf('blog_subtitle', $post->ID),
                'excerpt'    => $post->post_excerpt ?: wp_trim_words($post->post_content, 30),
                'image'      => get_the_post_thumbnail_url($post->ID, 'large') ?: '',
                'date'       => get_the_date('Y-m-d', $post),
                'readTime'   => $this->acf('blog_read_time', $post->ID, '5 min'),
                'author'     => $this->acf('blog_author', $post->ID, 'NoLimit'),
                'authorRole' => $this->acf('blog_author_role', $post->ID),
                'difficulty' => $this->acf('blog_difficulty', $post->ID, 'debutant'),
                'views'      => (int) $this->acf('blog_views', $post->ID, 0),
                'featured'   => (bool) $this->acf('blog_featured', $post->ID),
                'category'   => !empty($cats) ? $cats[0] : 'Conseil',
                'tags'       => $tags_raw ? array_map('trim', explode(',', $tags_raw)) : [],
                'parkSlug'   => $park_slug,
            ];
        }

        // Catégories
        $terms = get_terms(['taxonomy' => 'nolimit_blog_category', 'hide_empty' => false]);
        $categories = [['slug' => 'all', 'name' => 'Tous les articles', 'description' => 'Toute notre base de conseils']];
        if (!is_wp_error($terms)) {
            foreach ($terms as $term) {
                $categories[] = ['slug' => $term->slug, 'name' => $term->name, 'description' => $term->description];
            }
        }

        return rest_ensure_response([
            'title'      => $this->opt('nl_blog_title', 'Blog & Conseils'),
            'subtitle'   => $this->opt('nl_blog_subtitle', "Nos guides pratiques pour profiter au maximum"),
            'categories' => $categories,
            'articles'   => $articles,
        ]);
    }

    public function api_single($request) {
        $post = get_page_by_path($request->get_param('slug'), OBJECT, 'nolimit_blog');
        if (!$post) return new WP_Error('not_found', 'Article non trouvé', ['status' => 404]);

        // Incrémenter les vues
        $views = (int) $this->acf('blog_views', $post->ID, 0);
        update_field('blog_views', $views + 1, $post->ID);

        $cats = wp_get_post_terms($post->ID, 'nolimit_blog_category', ['fields' => 'names']);
        $tags_raw = $this->acf('blog_tags', $post->ID);

        // Articles liés (même catégorie)
        $related_posts = get_posts([
            'post_type' => 'nolimit_blog', 'posts_per_page' => 3,
            'post__not_in' => [$post->ID], 'orderby' => 'rand',
        ]);
        $related = [];
        foreach ($related_posts as $rp) {
            $related[] = [
                'id' => $rp->ID, 'slug' => $rp->post_name, 'title' => $rp->post_title,
                'image' => get_the_post_thumbnail_url($rp->ID, 'medium') ?: '',
                'date' => get_the_date('Y-m-d', $rp),
                'category' => wp_get_post_terms($rp->ID, 'nolimit_blog_category', ['fields' => 'names'])[0] ?? 'Conseil',
            ];
        }

        return rest_ensure_response([
            'id'         => $post->ID,
            'slug'       => $post->post_name,
            'title'      => $post->post_title,
            'subtitle'   => $this->acf('blog_subtitle', $post->ID),
            'content'    => $post->post_content,
            'image'      => get_the_post_thumbnail_url($post->ID, 'large') ?: '',
            'date'       => get_the_date('j F Y', $post),
            'readTime'   => $this->acf('blog_read_time', $post->ID, '5 min'),
            'author'     => $this->acf('blog_author', $post->ID, 'NoLimit'),
            'authorRole' => $this->acf('blog_author_role', $post->ID),
            'difficulty' => $this->acf('blog_difficulty', $post->ID, 'debutant'),
            'views'      => $views + 1,
            'category'   => !empty($cats) ? $cats[0] : 'Conseil',
            'tags'       => $tags_raw ? array_map('trim', explode(',', $tags_raw)) : [],
            'related'    => $related,
        ]);
    }
}
