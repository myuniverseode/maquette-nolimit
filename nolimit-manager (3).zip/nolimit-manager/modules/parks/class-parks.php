<?php
/**
 * Module : Parcs
 * CPT  : nolimit_parc
 * Routes : GET /parks, GET /parks/{id}
 *
 * Les données structurées (tarifs, services, etc.) sont gérées par des
 * metaboxes visuelles et stockées en JSON dans post_meta.
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Parks extends NoLimit_Module {

    public function register_post_types(): void {
        register_post_type('nolimit_parc', [
            'labels' => [
                'name' => 'Parcs', 'singular_name' => 'Parc',
                'add_new' => 'Ajouter un parc', 'all_items' => 'Tous les parcs',
            ],
            'public' => false, 'show_ui' => true, 'show_in_menu' => false,
            'supports' => ['title', 'editor', 'thumbnail', 'page-attributes'],
        ]);

        add_action('add_meta_boxes', [$this, 'add_visual_metaboxes']);
        // Priority 99 = run AFTER ACF saves (priority 10) so we overwrite ACF's empty values
        add_action('save_post_nolimit_parc', [$this, 'save_visual_metaboxes'], 99);
    }

    // ═══════════════════════════════════════════════════════════
    // ACF FIELDS — only simple fields, NO JSON textareas
    // ═══════════════════════════════════════════════════════════

    public function register_acf_fields(): void {
        acf_add_local_field_group([
            'key' => 'group_parc', 'title' => 'Informations Parc',
            'fields' => [
                ['key' => 'field_parc_slug',        'label' => 'Slug (ID unique)',     'name' => 'parc_slug',        'type' => 'text'],
                ['key' => 'field_parc_location',    'label' => 'Localisation',         'name' => 'parc_location',    'type' => 'text', 'placeholder' => 'Chevry, Essonne (91)'],
                ['key' => 'field_parc_departement', 'label' => 'Département',          'name' => 'parc_departement', 'type' => 'text'],
                ['key' => 'field_parc_emoji',       'label' => 'Emoji',                'name' => 'parc_emoji',       'type' => 'text', 'maxlength' => 5, 'default_value' => '🌳'],
                ['key' => 'field_parc_address',     'label' => 'Adresse complète',     'name' => 'parc_address',     'type' => 'textarea', 'rows' => 2],
                ['key' => 'field_parc_lat',         'label' => 'Latitude',             'name' => 'parc_lat',         'type' => 'number', 'step' => 'any'],
                ['key' => 'field_parc_lng',         'label' => 'Longitude',            'name' => 'parc_lng',         'type' => 'number', 'step' => 'any'],
                ['key' => 'field_parc_image',       'label' => 'Image principale',     'name' => 'parc_image',       'type' => 'image', 'return_format' => 'url'],
                ['key' => 'field_parc_gallery',     'label' => 'Galerie',              'name' => 'parc_gallery',     'type' => 'gallery', 'return_format' => 'url'],
                ['key' => 'field_parc_activities',  'label' => 'Activités (virgules)', 'name' => 'parc_activities',  'type' => 'text', 'placeholder' => "Accrobranche, Tyrolienne, Paintball"],
                ['key' => 'field_parc_highlights',  'label' => 'Points forts (virgules)', 'name' => 'parc_highlights', 'type' => 'text'],
                ['key' => 'field_parc_difficulty',  'label' => 'Niveaux (virgules)',    'name' => 'parc_difficulty',  'type' => 'text', 'default_value' => 'Débutant, Intermédiaire'],
                ['key' => 'field_parc_capacity',    'label' => 'Capacité (personnes)', 'name' => 'parc_capacity',    'type' => 'number', 'default_value' => 100],
                ['key' => 'field_parc_min_age',     'label' => 'Âge minimum',          'name' => 'parc_min_age',     'type' => 'number', 'default_value' => 3],
                ['key' => 'field_parc_min_price',   'label' => 'Prix minimum (€)',     'name' => 'parc_min_price',   'type' => 'number', 'default_value' => 25],
                ['key' => 'field_parc_rating',      'label' => 'Note globale',         'name' => 'parc_rating',      'type' => 'number', 'step' => 0.1, 'default_value' => 4.5],
                ['key' => 'field_parc_review_count','label' => "Nombre d'avis",        'name' => 'parc_review_count','type' => 'number', 'default_value' => 0],
                ['key' => 'field_parc_phone',       'label' => 'Téléphone',            'name' => 'parc_phone',       'type' => 'text'],
                ['key' => 'field_parc_email',       'label' => 'Email',                'name' => 'parc_email',       'type' => 'email'],
                ['key' => 'field_parc_google_place_id', 'label' => 'Google Place ID',  'name' => 'parc_google_place_id', 'type' => 'text'],
                ['key' => 'field_parc_tripadvisor_url', 'label' => 'URL TripAdvisor',  'name' => 'parc_tripadvisor_url', 'type' => 'url'],
                ['key' => 'field_parc_cgv_url',         'label' => 'URL CGV (lien ou PDF)', 'name' => 'parc_cgv_url',     'type' => 'url', 'placeholder' => '/cgv/nolimit-chevry ou https://...pdf'],
                ['key' => 'field_parc_cgv_label',       'label' => 'Libellé CGV (optionnel)', 'name' => 'parc_cgv_label', 'type' => 'text', 'placeholder' => 'CGV – NoLimit Chevry', 'instructions' => 'Si vide : "CGV – {nom du parc}" sera utilisé automatiquement'],
                // NOTE: Les champs JSON (tarifs, services, accessibilité, transport, bon à savoir)
                // sont gérés par des metaboxes visuelles, PAS par ACF.
            ],
            'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_parc']]],
        ]);
    }

    // ═══════════════════════════════════════════════════════════
    // VISUAL METABOXES (replace ACF JSON textareas)
    // ═══════════════════════════════════════════════════════════

    public function add_visual_metaboxes(): void {
        add_meta_box('nl_parc_pricing',    '💰 Tarifs (Formules)',              [$this, 'mb_pricing'],       'nolimit_parc', 'normal', 'high');
        add_meta_box('nl_parc_services',   '🏪 Services sur place',            [$this, 'mb_services'],      'nolimit_parc', 'normal', 'default');
        add_meta_box('nl_parc_access',     '♿ Accessibilité',                  [$this, 'mb_accessibility'], 'nolimit_parc', 'normal', 'default');
        add_meta_box('nl_parc_transport',  '🚗 Accès / Transport',             [$this, 'mb_transport'],     'nolimit_parc', 'normal', 'default');
        add_meta_box('nl_parc_gtk',        'ℹ️ Bon à savoir',                  [$this, 'mb_gtk'],           'nolimit_parc', 'normal', 'default');
        add_meta_box('nl_parc_act_tarifs', '💰 Tarifs par activité (ce parc)', [$this, 'mb_act_tarifs'],    'nolimit_parc', 'normal', 'default');
    }

    /** Read JSON from post_meta (NOT via ACF get_field to avoid conflicts) */
    private function read_json_meta(int $post_id, string $meta_key): array {
        $raw = get_post_meta($post_id, $meta_key, true);
        if (empty($raw)) return [];
        if (is_string($raw)) {
            $d = json_decode($raw, true);
            return is_array($d) ? $d : [];
        }
        return is_array($raw) ? $raw : [];
    }

    /** Render a visual repeater inside a metabox */
    private function render_repeater(string $name, array $items, array $fields, string $add_label = '＋ Ajouter'): void {
        $fields_json = [];
        foreach ($fields as $f) $fields_json[] = implode('|', $f);
        ?>
        <style>
            .nl-mb-row { display:flex; align-items:center; gap:8px; padding:8px 0; border-bottom:1px solid #eee; flex-wrap:wrap; }
            .nl-mb-row:last-child { border-bottom:none; }
            .nl-mb-drag { cursor:grab; color:#aaa; user-select:none; }
            .nl-mb-del { color:#b32d2e !important; border-color:#b32d2e !important; padding:2px 8px !important; min-height:28px; line-height:1; }
            .nl-mb-del:hover { background:#b32d2e !important; color:#fff !important; }
            .nl-f-xs { width:60px !important; }
            .nl-f-sm { width:120px !important; }
            .nl-f-md { width:200px !important; }
            .nl-f-lg { flex:1; min-width:180px !important; }
            .nl-f-xl { flex:2; min-width:250px !important; }
        </style>
        <div class="nl-mb-repeater" data-name="<?php echo esc_attr($name); ?>">
            <?php foreach ($items as $i => $item): ?>
            <div class="nl-mb-row">
                <span class="nl-mb-drag">☰</span>
                <?php foreach ($fields as $f):
                    $key = $f[0]; $ph = $f[1]; $sz = $f[2] ?? 'md'; $type = $f[3] ?? 'text';
                    $val = is_bool($item[$key] ?? '') ? ($item[$key] ? '1' : '0') : ($item[$key] ?? '');
                ?>
                <input type="<?php echo esc_attr($type); ?>"
                       name="<?php echo esc_attr($name); ?>[<?php echo $i; ?>][<?php echo esc_attr($key); ?>]"
                       value="<?php echo esc_attr($val); ?>"
                       placeholder="<?php echo esc_attr($ph); ?>"
                       class="nl-f-<?php echo esc_attr($sz); ?>">
                <?php endforeach; ?>
                <button type="button" class="button nl-mb-del" onclick="this.closest('.nl-mb-row').remove()">✕</button>
            </div>
            <?php endforeach; ?>
        </div>
        <button type="button" class="button" style="margin-top:8px;" onclick="nlAddRow(this, '<?php echo esc_attr($name); ?>', <?php echo esc_attr(wp_json_encode($fields_json)); ?>)">
            <?php echo esc_html($add_label); ?>
        </button>
        <script>
        function nlAddRow(btn, name, fieldsDef) {
            var container = btn.previousElementSibling;
            var idx = container.querySelectorAll('.nl-mb-row').length;
            var html = '<div class="nl-mb-row"><span class="nl-mb-drag">☰</span>';
            fieldsDef.forEach(function(f) {
                var p = f.split('|'), key = p[0], ph = p[1]||'', sz = p[2]||'md', tp = p[3]||'text';
                html += '<input type="'+tp+'" name="'+name+'['+idx+']['+key+']" placeholder="'+ph+'" class="nl-f-'+sz+'">';
            });
            html += '<button type="button" class="button nl-mb-del" onclick="this.closest(\'.nl-mb-row\').remove()">✕</button></div>';
            container.insertAdjacentHTML('beforeend', html);
        }
        </script>
        <?php
    }

    // ─── Individual metabox renders ─────────────────

    public function mb_pricing($post): void {
        wp_nonce_field('nl_parc_mb_save', 'nl_parc_mb_nonce');
        $items = $this->read_json_meta($post->ID, 'parc_pricing_json');
        echo '<p class="description">Formules tarifaires affichées sur la fiche parc. Le champ « Avantages » accepte une liste séparée par des virgules.</p>';
        $this->render_repeater('nl_pricing', $items, [
            ['icon', 'Emoji', 'xs'], ['name', 'Nom formule', 'md'], ['price', 'Prix (€ ou texte)', 'sm'],
            ['description', 'Description courte', 'lg'], ['features', 'Avantages (virgules)', 'xl'],
        ], '＋ Ajouter une formule');
    }

    public function mb_services($post): void {
        $items = $this->read_json_meta($post->ID, 'parc_services_json');
        echo '<p class="description">Services disponibles dans le parc.</p>';
        $this->render_repeater('nl_services', $items, [
            ['icon', 'Icône (Shield, Utensils…)', 'sm'], ['label', 'Nom du service', 'md'], ['color', 'Couleur #hex', 'sm'],
        ], '＋ Ajouter un service');
    }

    public function mb_accessibility($post): void {
        $items = $this->read_json_meta($post->ID, 'parc_accessibility_json');
        echo '<p class="description">Options d\'accessibilité du parc.</p>';
        $this->render_repeater('nl_access', $items, [
            ['emoji', 'Emoji', 'xs'], ['label', 'Label', 'md'],
        ], '＋ Ajouter');
    }

    public function mb_transport($post): void {
        $items = $this->read_json_meta($post->ID, 'parc_transport_json');
        echo '<p class="description">Comment accéder au parc.</p>';
        $this->render_repeater('nl_transport', $items, [
            ['icon', 'Icône (Car, Bike…)', 'sm'], ['title', 'Titre', 'md'], ['desc', 'Description', 'lg'], ['color', 'Couleur', 'sm'],
        ], '＋ Ajouter');
    }

    public function mb_gtk($post): void {
        $items = $this->read_json_meta($post->ID, 'parc_good_to_know_json');
        echo '<p class="description">Informations pratiques pour les visiteurs.</p>';
        $this->render_repeater('nl_gtk', $items, [
            ['icon', 'Icône (Clock, Shield…)', 'sm'], ['title', 'Titre', 'md'], ['color', 'Couleur', 'sm'],
        ], '＋ Ajouter');
    }

    public function mb_act_tarifs($post): void {
        $raw = get_post_meta($post->ID, 'parc_activity_tarifs_json', true);
        echo '<p class="description">Tarifs spécifiques à CE parc, par activité. Si vide, les tarifs globaux des activités sont utilisés.<br><small>Ce champ reste en texte JSON car sa structure est très imbriquée.</small></p>';
        echo '<textarea name="nl_act_tarifs_raw" rows="8" class="large-text" style="font-family:monospace;font-size:12px;">';
        echo esc_textarea($raw ?: '');
        echo '</textarea>';
    }

    // ═══════════════════════════════════════════════════════════
    // SAVE — priority 99 to run AFTER ACF
    // ═══════════════════════════════════════════════════════════

    public function save_visual_metaboxes(int $post_id): void {
        if (!isset($_POST['nl_parc_mb_nonce'])) return;
        if (!wp_verify_nonce($_POST['nl_parc_mb_nonce'], 'nl_parc_mb_save')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $map = [
            'nl_pricing'   => 'parc_pricing_json',
            'nl_services'  => 'parc_services_json',
            'nl_access'    => 'parc_accessibility_json',
            'nl_transport' => 'parc_transport_json',
            'nl_gtk'       => 'parc_good_to_know_json',
        ];

        foreach ($map as $post_key => $meta_key) {
            $raw = $_POST[$post_key] ?? [];
            if (!is_array($raw)) { $raw = []; }
            $items = [];
            foreach ($raw as $row) {
                if (!is_array($row)) continue;
                $clean = []; $has = false;
                foreach ($row as $k => $v) {
                    $cv = sanitize_text_field(trim($v));
                    $clean[$k] = $cv;
                    if ($cv !== '') $has = true;
                }
                if ($meta_key === 'parc_accessibility_json' && $has) {
                    $clean['available'] = true;
                }
                if ($has) $items[] = $clean;
            }
            update_post_meta($post_id, $meta_key, wp_json_encode(array_values($items), JSON_UNESCAPED_UNICODE));
        }

        // Activity tarifs
        if (isset($_POST['nl_act_tarifs_raw'])) {
            $raw = stripslashes($_POST['nl_act_tarifs_raw']);
            if (empty(trim($raw))) {
                update_post_meta($post_id, 'parc_activity_tarifs_json', '');
            } else {
                $d = json_decode($raw, true);
                if (is_array($d)) {
                    update_post_meta($post_id, 'parc_activity_tarifs_json', wp_json_encode($d, JSON_UNESCAPED_UNICODE));
                } else {
                    // Invalid JSON — keep raw to not lose data
                    update_post_meta($post_id, 'parc_activity_tarifs_json', sanitize_textarea_field($raw));
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    // API ROUTES
    // ═══════════════════════════════════════════════════════════

    public function get_api_routes(): array {
        return [
            'parks' => ['methods' => 'GET', 'callback' => [$this, 'api_list']],
            'parks/(?P<id>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_single']],
        ];
    }

    public function api_list() {
        return rest_ensure_response($this->get_parks_full());
    }

    public function api_single($request) {
        $id = $request->get_param('id');
        foreach ($this->get_parks_full() as $park) {
            if ($park['id'] === $id) return rest_ensure_response($park);
        }
        return new WP_Error('not_found', 'Parc non trouvé', ['status' => 404]);
    }

    // ═══════════════════════════════════════════════════════════
    // DATA FORMATTING
    // ═══════════════════════════════════════════════════════════

    private function get_parks_full(): array {
        $posts = $this->query('nolimit_parc');
        $parks = [];

        foreach ($posts as $post) {
            $id = $post->ID;
            $slug = $this->acf('parc_slug', $id) ?: sanitize_title($post->post_title);

            $acts = $this->acf('parc_activities', $id);
            $highlights = $this->acf('parc_highlights', $id);
            $difficulty = $this->acf('parc_difficulty', $id);

            $activityTarifs = $this->parse_activity_tarifs($id);
            if (empty($activityTarifs)) $activityTarifs = (object) [];

            $parks[] = [
                'id'          => $slug,
                'name'        => $post->post_title,
                'description' => wp_strip_all_tags($post->post_content),
                'location'    => $this->acf('parc_location', $id, $post->post_title),
                'departement' => $this->acf('parc_departement', $id, ''),
                'emoji'       => $this->acf('parc_emoji', $id, '📍'),
                'address'     => $this->acf('parc_address', $id, ''),
                'coordinates' => [
                    'lat' => (float) ($this->acf('parc_lat', $id) ?: 0),
                    'lng' => (float) ($this->acf('parc_lng', $id) ?: 0),
                ],
                'image'       => $this->acf('parc_image', $id) ?: null,
                'gallery'     => $this->acf('parc_gallery', $id, []),
                'activities'  => $acts ? array_map('trim', explode(',', $acts)) : [],
                'highlights'  => $highlights ? array_map('trim', explode(',', $highlights)) : [],
                'difficulty'  => $difficulty ? array_map('trim', explode(',', $difficulty)) : ['Débutant'],
                'minAge'      => (int) ($this->acf('parc_min_age', $id) ?: 3),
                'minPrice'    => (int) ($this->acf('parc_min_price', $id) ?: 25),
                'rating'      => (float) ($this->acf('parc_rating', $id) ?: 4.5),
                'reviewCount' => (int) ($this->acf('parc_review_count', $id) ?: 0),
                'capacity'    => (int) ($this->acf('parc_capacity', $id) ?: 100),
                'contact'     => [
                    'phone' => $this->acf('parc_phone', $id) ?: get_option('nl_f_phone', ''),
                    'email' => $this->acf('parc_email', $id) ?: get_option('nl_f_email', ''),
                ],
                'googlePlaceId'      => $this->acf('parc_google_place_id', $id, ''),
                'tripadvisorUrl'     => $this->acf('parc_tripadvisor_url', $id, ''),
                // JSON fields — read directly from post_meta, NOT from ACF
                'pricingOptions'     => $this->parse_meta_json($id, 'parc_pricing_json'),
                'onSiteServices'     => $this->read_json_meta($id, 'parc_services_json'),
                'accessibilityItems' => $this->read_json_meta($id, 'parc_accessibility_json'),
                'transportOptions'   => $this->read_json_meta($id, 'parc_transport_json'),
                'goodToKnow'        => $this->read_json_meta($id, 'parc_good_to_know_json'),
                'activityTarifs'    => $activityTarifs,
            ];
        }
        return $parks;
    }

    /** Parse pricing JSON with features string→array conversion */
    private function parse_meta_json(int $post_id, string $meta_key): array {
        $data = $this->read_json_meta($post_id, $meta_key);
        foreach ($data as &$item) {
            if (isset($item['features']) && is_string($item['features'])) {
                $item['features'] = array_map('trim', explode(',', $item['features']));
            }
            if (isset($item['price']) && is_numeric($item['price'])) {
                $item['price'] = (int) $item['price'];
            }
        }
        return $data;
    }

    /** Parse activity tarifs from post_meta */
    private function parse_activity_tarifs(int $post_id): array {
        $raw = get_post_meta($post_id, 'parc_activity_tarifs_json', true);
        if (empty($raw)) return [];
        $data = json_decode($raw, true);
        if (!is_array($data)) return [];

        $result = [];
        foreach ($data as $slug => $tarifs) {
            if (!is_array($tarifs)) continue;
            $valid = [];
            foreach ($tarifs as $group) {
                if (empty($group['titre']) || !isset($group['lignes'])) continue;
                $lignes = [];
                foreach ((array) $group['lignes'] as $l) {
                    if (!empty($l['label']) && !empty($l['prix'])) {
                        $lignes[] = ['label' => $l['label'], 'prix' => $l['prix']];
                    }
                }
                if (!empty($lignes)) $valid[] = ['titre' => $group['titre'], 'lignes' => $lignes];
            }
            if (!empty($valid)) $result[$slug] = $valid;
        }
        return $result;
    }

    // ═══════════════════════════════════════════════════════════
    // DEFAULT DATA
    // ═══════════════════════════════════════════════════════════

    public function create_defaults(): void {
        if (get_posts(['post_type' => 'nolimit_parc', 'posts_per_page' => 1])) return;

        $default_pricing = json_encode([
            ['name' => 'Individuel', 'price' => 25, 'description' => 'Parfait pour une personne', 'features' => 'Accès à toutes les activités, Équipement inclus, Encadrement professionnel, Assurance comprise', 'popular' => false, 'icon' => '🧗', 'color' => '#357600'],
            ['name' => 'Groupe (5-10)', 'price' => 20, 'description' => 'Idéal entre amis', 'features' => 'Accès à toutes les activités, Équipement inclus, Réduction groupe, Photo souvenir offerte', 'popular' => true, 'icon' => '👥', 'color' => '#eb700f'],
            ['name' => 'Entreprise', 'price' => 'Sur devis', 'description' => 'Team building sur mesure', 'features' => 'Programme personnalisé, Encadrement dédié, Forfait restauration possible', 'popular' => false, 'icon' => '🏢', 'color' => '#357600'],
        ], JSON_UNESCAPED_UNICODE);

        $default_services = json_encode([
            ['icon' => 'Shield', 'label' => 'Vestiaires', 'color' => '#357600'],
            ['icon' => 'Utensils', 'label' => 'Restauration', 'color' => '#eb700f'],
            ['icon' => 'ShoppingBag', 'label' => 'Boutique', 'color' => '#357600'],
            ['icon' => 'Droplets', 'label' => 'Sanitaires', 'color' => '#eb700f'],
            ['icon' => 'Trees', 'label' => 'Ombragé', 'color' => '#357600'],
            ['icon' => 'Wifi', 'label' => 'WiFi', 'color' => '#eb700f'],
        ], JSON_UNESCAPED_UNICODE);

        $default_accessibility = json_encode([
            ['emoji' => '♿', 'label' => 'Accès PMR', 'available' => true],
            ['emoji' => '👁️', 'label' => 'Déf. visuelle', 'available' => true],
            ['emoji' => '🍼', 'label' => 'Poussettes', 'available' => true],
            ['emoji' => '🐕', 'label' => 'Animaux guide', 'available' => true],
        ], JSON_UNESCAPED_UNICODE);

        $default_transport = json_encode([
            ['icon' => 'Car', 'title' => 'Parking', 'desc' => 'Gratuit sur place', 'color' => '#357600'],
            ['icon' => 'Bike', 'title' => 'Vélo', 'desc' => 'Piste cyclable à proximité', 'color' => '#eb700f'],
            ['icon' => 'Users', 'title' => 'Covoiturage', 'desc' => 'BlaBlaCar recommandé', 'color' => '#357600'],
        ], JSON_UNESCAPED_UNICODE);

        $default_gtk = json_encode([
            ['icon' => 'Clock', 'title' => 'Annulation gratuite', 'color' => '#357600'],
            ['icon' => 'Users', 'title' => 'Tarifs dégressifs', 'color' => '#eb700f'],
            ['icon' => 'Shield', 'title' => 'Assurance incluse', 'color' => '#357600'],
            ['icon' => 'Calendar', 'title' => 'Réservation flexible', 'color' => '#eb700f'],
            ['icon' => 'Gift', 'title' => 'Carte cadeau', 'color' => '#357600'],
            ['icon' => 'Star', 'title' => 'Programme fidélité', 'color' => '#eb700f'],
        ], JSON_UNESCAPED_UNICODE);

        $parcs = [
            ['title' => 'NoLimit Aventure - Chevry', 'desc' => 'Le parc historique NoLimit Aventure à 30 minutes de Paris.', 'location' => 'Chevry, Essonne (91)', 'departement' => 'Essonne', 'emoji' => '🌳', 'slug' => 'nolimit-chevry', 'lat' => 48.5351, 'lng' => 2.2669, 'activities' => "Accrobranche, Tyrolienne, Parcours filet, Tir à l'arc", 'highlights' => "14 parcours, Parcours Kids, Proche de Paris", 'difficulty' => 'Débutant, Intermédiaire', 'min_age' => 3, 'rating' => 4.7, 'review_count' => 423, 'min_price' => 25, 'capacity' => 120],
            ['title' => 'NoLimit Aventure - Nemours', 'desc' => 'Le plus grand parc NoLimit avec 18 parcours.', 'location' => 'Nemours, Seine-et-Marne (77)', 'departement' => 'Seine-et-Marne', 'emoji' => '⚡', 'slug' => 'nolimit-nemours', 'lat' => 48.2802, 'lng' => 2.7121, 'activities' => 'Accrobranche, Tyrolienne 300m, Paintball, Archery Tag', 'highlights' => '18 parcours, Tyrolienne géante, Terrain Paintball', 'difficulty' => 'Débutant, Intermédiaire, Avancé', 'min_age' => 6, 'rating' => 4.8, 'review_count' => 512, 'min_price' => 28, 'capacity' => 180],
            ['title' => 'NoLimit Aventure - Montargis', 'desc' => 'Parc familial au cœur du Loiret.', 'location' => 'Montargis, Loiret (45)', 'departement' => 'Loiret', 'emoji' => '🏹', 'slug' => 'nolimit-montargis', 'lat' => 48.0, 'lng' => 2.7333, 'activities' => "Accrobranche, Parcours filet, Tir à l'arc, Escape Game", 'highlights' => 'Parcours familial, Escape Game, Cadre naturel', 'difficulty' => 'Débutant, Intermédiaire', 'min_age' => 5, 'rating' => 4.6, 'review_count' => 287, 'min_price' => 23, 'capacity' => 100],
            ['title' => 'NoLimit Aventure - Digny', 'desc' => "Parc au cœur de la forêt.", 'location' => 'Digny, Eure-et-Loir (28)', 'departement' => 'Eure-et-Loir', 'emoji' => '🎯', 'slug' => 'nolimit-digny', 'lat' => 48.5333, 'lng' => 1.15, 'activities' => 'Accrobranche, Paintball, Orientation, Chasse au trésor', 'highlights' => 'Forêt dense, Parcours techniques', 'difficulty' => 'Intermédiaire, Avancé', 'min_age' => 8, 'rating' => 4.5, 'review_count' => 198, 'min_price' => 24, 'capacity' => 90],
            ['title' => 'NoLimit Aventure - Le Coudray', 'desc' => 'Parc moderne avec des installations récentes.', 'location' => 'Le Coudray, Eure-et-Loir (28)', 'departement' => 'Eure-et-Loir', 'emoji' => '🧗', 'slug' => 'nolimit-coudray', 'lat' => 48.4333, 'lng' => 1.4833, 'activities' => "Accrobranche, Parcours Kids, Tir à l'arc", 'highlights' => 'Installations modernes, Pédagogique, Sorties scolaires', 'difficulty' => 'Débutant', 'min_age' => 3, 'rating' => 4.7, 'review_count' => 234, 'min_price' => 22, 'capacity' => 110],
        ];

        foreach ($parcs as $i => $p) {
            $pid = wp_insert_post(['post_title' => $p['title'], 'post_content' => $p['desc'], 'post_type' => 'nolimit_parc', 'post_status' => 'publish', 'menu_order' => $i]);
            if (!$pid) continue;
            // ACF simple fields
            update_field('parc_slug', $p['slug'], $pid);
            update_field('parc_location', $p['location'], $pid);
            update_field('parc_departement', $p['departement'], $pid);
            update_field('parc_emoji', $p['emoji'], $pid);
            update_field('parc_lat', $p['lat'], $pid);
            update_field('parc_lng', $p['lng'], $pid);
            update_field('parc_activities', $p['activities'], $pid);
            update_field('parc_highlights', $p['highlights'], $pid);
            update_field('parc_difficulty', $p['difficulty'], $pid);
            update_field('parc_min_age', $p['min_age'], $pid);
            update_field('parc_rating', $p['rating'], $pid);
            update_field('parc_review_count', $p['review_count'], $pid);
            update_field('parc_min_price', $p['min_price'], $pid);
            update_field('parc_capacity', $p['capacity'], $pid);
            // JSON fields — direct post_meta (not ACF)
            update_post_meta($pid, 'parc_pricing_json', $default_pricing);
            update_post_meta($pid, 'parc_services_json', $default_services);
            update_post_meta($pid, 'parc_accessibility_json', $default_accessibility);
            update_post_meta($pid, 'parc_transport_json', $default_transport);
            update_post_meta($pid, 'parc_good_to_know_json', $default_gtk);
        }
    }
}
