<?php
/**
 * Module : Header
 *
 * Route : GET /nolimit/v1/header
 * Retourne : logo, couleurs, CTA, menu, parcs (sélecteur)
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Module_Header extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'header' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_header'],
            ],
        ];
    }

    public function api_header(): WP_REST_Response {
        $logo_id = $this->opt('nl_logo_id', 0);
        $cta_page_id = $this->opt('nl_cta_page_id', 0);

        $data = [
            'logo' => [
                'url' => $logo_id ? wp_get_attachment_url($logo_id) : '',
                'alt' => 'NoLimit Aventure',
            ],
            'primaryColor'     => $this->opt('nl_primary', '#f97316'),
            'secondaryColor'   => $this->opt('nl_secondary', '#eb700f'),
            'greenColor'       => $this->opt('nl_green', '#357600'),
            'ctaText'          => $this->opt('nl_cta_text', 'Réserver'),
            'ctaUrl'           => $cta_page_id ? get_permalink($cta_page_id) : '/booking',
            'showParkSelector' => (bool) $this->opt('nl_show_parks', 1),
            'menuItems'        => $this->get_menu_items(),
            'parks'            => $this->get_parks_simple(),
        ];

        return rest_ensure_response($data);
    }

    private function get_menu_items(): array {
        $posts = $this->query('nolimit_menu');
        $items = [];

        foreach ($posts as $post) {
            $type = $this->acf('menu_type', $post->ID, 'simple');
            $items[] = [
                'id'           => $post->ID,
                'label'        => $post->post_title,
                'type'         => $type,
                'url'          => $type === 'simple' ? $this->acf('menu_url', $post->ID, '/') : null,
                'megaMenuType' => $type === 'megamenu' ? $this->acf('megamenu_type', $post->ID, 'discover') : null,
                'position'     => $post->menu_order,
            ];
        }

        return $items;
    }

    private function get_parks_simple(): array {
        $posts = $this->query('nolimit_parc');
        $parks = [];

        foreach ($posts as $post) {
            $parks[] = [
                'id'       => $this->acf('parc_slug', $post->ID) ?: sanitize_title($post->post_title),
                'name'     => $post->post_title,
                'location' => $this->acf('parc_location', $post->ID, $post->post_title),
                'emoji'    => $this->acf('parc_emoji', $post->ID, '📍'),
                'url'      => $this->acf('parc_url', $post->ID) ?: '/parks/' . sanitize_title($post->post_title),
            ];
        }

        return $parks;
    }
}
