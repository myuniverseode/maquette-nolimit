<?php
/**
 * Module : Groupes & Événements (complet)
 *
 * Routes :
 *   GET /groups              → page hub principale
 *   GET /groups/corporate    → page entreprises
 *   GET /groups/kids         → page enfants/ados
 *   GET /groups/adults       → page adultes/fêtes
 *   GET /groups/family       → page familles
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Groups extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'groups'           => ['methods' => 'GET', 'callback' => [$this, 'api_hub']],
            'groups/corporate' => ['methods' => 'GET', 'callback' => [$this, 'api_corporate']],
            'groups/kids'      => ['methods' => 'GET', 'callback' => [$this, 'api_kids']],
            'groups/adults'    => ['methods' => 'GET', 'callback' => [$this, 'api_adults']],
            'groups/family'    => ['methods' => 'GET', 'callback' => [$this, 'api_family']],
        ];
    }

    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) { $d = json_decode($raw, true); if (is_array($d) && !empty($d)) return $d; }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }

    /* ── Hub principal ─────────────────────────────────────── */
    public function api_hub() {
        $benefits = array_filter(array_map('trim', explode("\n", $this->opt('nl_groups_benefits', ''))));

        $categories = $this->get_json_option('nl_groups_categories', [
            ['id' => 'corporate', 'label' => 'Entreprises',      'icon' => 'Building2', 'description' => "Renforcez la cohésion de vos équipes avec des défis outdoor sur mesure.", 'link' => '/groups/corporate', 'minGroup' => 10, 'maxGroup' => 500, 'color' => '#357600'],
            ['id' => 'kids',      'label' => 'Enfants & Ados',   'icon' => 'GraduationCap', 'description' => "Des activités pensées pour les 5-17 ans.", 'link' => '/groups/kids',    'minGroup' => 8,  'maxGroup' => 200, 'color' => '#eb700f'],
            ['id' => 'adults',    'label' => 'Adultes & Fêtes',  'icon' => 'PartyPopper', 'description' => "EVG, EVJF, anniversaires, soirées privées.", 'link' => '/groups/adults',  'minGroup' => 6,  'maxGroup' => 100, 'color' => '#8b5cf6'],
            ['id' => 'family',    'label' => 'Familles',          'icon' => 'TreePine', 'description' => "Réunions de famille, multi-générations, week-ends.", 'link' => '/groups/family', 'minGroup' => 10, 'maxGroup' => 80,  'color' => '#22c55e'],
        ]);

        $stats = $this->get_json_option('nl_groups_stats', [
            ['value' => '500+',  'label' => 'Groupes / an'],
            ['value' => '98%',   'label' => 'Satisfaction'],
            ['value' => '24h',   'label' => 'Délai devis'],
            ['value' => '5',     'label' => 'Parcs dispo'],
        ]);

        $testimonials = $this->get_json_option('nl_groups_testimonials', []);

        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_groups_hero_title', "Groupes & Événements"),
                'subtitle' => $this->opt('nl_groups_hero_subtitle', "Anniversaires, team building, séminaires..."),
                'image'    => $this->opt('nl_groups_hero_image_id', 0) ? wp_get_attachment_url($this->opt('nl_groups_hero_image_id', 0)) : '',
            ],
            'categories'      => $categories,
            'stats'            => $stats,
            'testimonials'     => $testimonials,
            'benefitsSection' => [
                'title'       => $this->opt('nl_groups_benefits_title', "Pourquoi nous choisir ?"),
                'description' => $this->opt('nl_groups_benefits_desc', "Avec plus de 500 groupes accueillis chaque année..."),
            ],
            'benefits' => $benefits,
            'cse' => [
                'title'    => $this->opt('nl_groups_cse_title', "CSE & Comités d'entreprise"),
                'subtitle' => $this->opt('nl_groups_cse_subtitle', "Tarifs préférentiels, prise en charge simplifiée."),
            ],
            'cta' => [
                'title'      => $this->opt('nl_groups_cta_title', "Demandez votre devis"),
                'subtitle'   => $this->opt('nl_groups_cta_subtitle', "Réponse garantie sous 24h"),
                'buttonText' => $this->opt('nl_groups_cta_btn', "Demander un devis"),
                'buttonUrl'  => $this->opt('nl_groups_cta_url', '/contact'),
            ],
        ]);
    }

    /* ── Entreprises ───────────────────────────────────────── */
    public function api_corporate() {
        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_grp_corp_title', "Team Building & Séminaires"),
                'subtitle' => $this->opt('nl_grp_corp_subtitle', "Renforcez la cohésion de vos équipes"),
            ],
            'programTypes'  => $this->get_json_option('nl_grp_corp_program_types', [
                ['id' => 'cohesion',    'title' => 'Team Building Cohésion',   'desc' => "Renforcer les liens entre collaborateurs."],
                ['id' => 'challenge',   'title' => 'Challenge Performance',    'desc' => "Compétition saine et dépassement de soi."],
                ['id' => 'seminaire',   'title' => 'Séminaire Résidentiel',    'desc' => "Combiner réunion et activités outdoor."],
                ['id' => 'incentive',   'title' => 'Séjour Incentive',          'desc' => "Récompenser vos meilleurs éléments."],
            ]),
            'programs'      => $this->get_json_option('nl_grp_corp_programs', []),
            'sectors'       => $this->get_json_option('nl_grp_corp_sectors', []),
            'testimonials'  => $this->get_json_option('nl_grp_corp_testimonials', []),
        ]);
    }

    /* ── Enfants ───────────────────────────────────────────── */
    public function api_kids() {
        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_grp_kids_title', "Enfants, Ados & Écoles"),
                'subtitle' => $this->opt('nl_grp_kids_subtitle', "Anniversaires, sorties scolaires, centres de loisirs"),
            ],
            'ageGroups'    => $this->get_json_option('nl_grp_kids_age_groups', [
                ['id' => 'explorers',   'label' => 'Les explorateurs', 'ageRange' => '3-6 ans',   'desc' => "Parcours Kids sécurisés"],
                ['id' => 'adventurers', 'label' => 'Les aventuriers',  'ageRange' => '7-11 ans',  'desc' => "Premiers vrais défis"],
                ['id' => 'challengers', 'label' => 'Les challengers',  'ageRange' => '12-17 ans', 'desc' => "Sensations fortes"],
            ]),
            'bookingTypes' => $this->get_json_option('nl_grp_kids_booking_types', [
                ['id' => 'birthday', 'title' => 'Anniversaire',     'subtitle' => "Fête inoubliable de 3 à 17 ans"],
                ['id' => 'school',   'title' => 'Sortie scolaire',  'subtitle' => "Maternelle, primaire, collège, lycée"],
                ['id' => 'center',   'title' => 'Centre de loisirs','subtitle' => "Sorties encadrées"],
            ]),
            'testimonials' => $this->get_json_option('nl_grp_kids_testimonials', []),
        ]);
    }

    /* ── Adultes / Fêtes ───────────────────────────────────── */
    public function api_adults() {
        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_grp_adults_title', "EVG · EVJF · Anniversaires · Soirées"),
                'subtitle' => $this->opt('nl_grp_adults_subtitle', "Des événements qui marquent les esprits"),
            ],
            'eventTypes' => $this->get_json_option('nl_grp_adults_event_types', [
                ['id' => 'evg',       'label' => 'EVG',           'desc' => "Enterrement de vie de garçon"],
                ['id' => 'evjf',      'label' => 'EVJF',          'desc' => "Enterrement de vie de jeune fille"],
                ['id' => 'birthday',  'label' => 'Anniversaire',  'desc' => "Fêter un cap en pleine nature"],
                ['id' => 'private',   'label' => 'Soirée privée', 'desc' => "Privatisation possible en soirée"],
            ]),
            'addOns'       => $this->get_json_option('nl_grp_adults_addons', [
                ['icon' => 'Camera',   'label' => 'Photographe',   'desc' => 'Pro pendant 2h',           'price' => '+90€'],
                ['icon' => 'Utensils', 'label' => 'Traiteur',      'desc' => "Buffet sur place",          'price' => '+15€/pers'],
                ['icon' => 'Music',    'label' => 'Sono & ambiance','desc' => "Enceintes + playlist",     'price' => '+50€'],
            ]),
            'testimonials' => $this->get_json_option('nl_grp_adults_testimonials', []),
        ]);
    }

    /* ── Familles ───────────────────────────────────────────── */
    public function api_family() {
        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_grp_family_title', "Grandes Familles & Multi-générations"),
                'subtitle' => $this->opt('nl_grp_family_subtitle', "Réunions de famille, week-ends, retrouvailles"),
            ],
            'familyPacks' => $this->get_json_option('nl_grp_family_packs', [
                ['id' => 'reunion',  'title' => 'Réunion de famille', 'subtitle' => 'Retrouvailles annuelles',      'minPersons' => 15, 'maxPersons' => 80],
                ['id' => 'multi',    'title' => 'Multi-générations',  'subtitle' => 'De 3 à 80 ans',                'minPersons' => 10, 'maxPersons' => 50],
                ['id' => 'weekend',  'title' => 'Week-end famille',   'subtitle' => "2 jours d'aventure en famille", 'minPersons' => 8,  'maxPersons' => 40],
            ]),
            'generations'  => $this->get_json_option('nl_grp_family_generations', [
                ['age' => '3-6',   'label' => 'Petits explorateurs', 'activities' => 'Parcours Kids, Chasse au trésor'],
                ['age' => '7-14',  'label' => 'Aventuriers',         'activities' => 'Accrobranche, Tyrolienne'],
                ['age' => '15-30', 'label' => 'Challengers',         'activities' => 'Parcours extrême, Paintball'],
                ['age' => '30-60', 'label' => 'Parents aventuriers', 'activities' => 'Accrobranche, Via ferrata'],
                ['age' => '60+',   'label' => 'Seniors actifs',      'activities' => "Tir à l'arc, Balade nature"],
            ]),
            'testimonials' => $this->get_json_option('nl_grp_family_testimonials', []),
        ]);
    }
}
