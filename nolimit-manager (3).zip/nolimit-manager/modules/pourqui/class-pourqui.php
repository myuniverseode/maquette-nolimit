<?php

/**
 * Module : Pour Qui (complet — toutes les données éditables)
 *
 * Routes :
 *   GET /pour-qui              → page hub (cartes)
 *   GET /pour-qui/duo          → page duo
 *   GET /pour-qui/enfant       → page enfant
 *   GET /pour-qui/entreprise   → page entreprise
 *   GET /pour-qui/famille      → page famille
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Module_PourQui extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'pour-qui'              => ['methods' => 'GET', 'callback' => [$this, 'api_hub']],
            'pour-qui/duo'          => ['methods' => 'GET', 'callback' => [$this, 'api_duo']],
            'pour-qui/enfant'       => ['methods' => 'GET', 'callback' => [$this, 'api_enfant']],
            'pour-qui/entreprise'   => ['methods' => 'GET', 'callback' => [$this, 'api_entreprise']],
            'pour-qui/famille'      => ['methods' => 'GET', 'callback' => [$this, 'api_famille']],
        ];
    }

    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) { $d = json_decode($raw, true); if (is_array($d) && !empty($d)) return $d; }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }

    /** Récupère les vraies activités depuis le CPT nolimit_activity */
    private function get_real_activities(): array {
        if (!post_type_exists('nolimit_activity')) return [];
        $posts = get_posts(['post_type' => 'nolimit_activity', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']);
        $activities = [];
        foreach ($posts as $post) {
            $activities[] = [
                'id'          => $post->ID,
                'name'        => $post->post_title,
                'slug'        => $this->acf('activity_slug', $post->ID) ?: sanitize_title($post->post_title),
                'emoji'       => $this->acf('activity_emoji', $post->ID, '🎯'),
                'description' => $post->post_content,
                'image'       => $this->acf('activity_image', $post->ID),
                'duration'    => $this->acf('activity_duration', $post->ID),
                'minAge'      => (int) ($this->acf('activity_min_age', $post->ID) ?: 6),
                'participants'=> $this->acf('activity_participants', $post->ID),
                'difficulty'  => $this->acf('activity_difficulty', $post->ID, 'Intermédiaire'),
                'intensity'   => $this->acf('activity_intensity', $post->ID, 'medium'),
            ];
        }
        return $activities;
    }

    /** Récupère les vrais parcs depuis le CPT nolimit_parc */
    private function get_real_parks(): array {
        if (!post_type_exists('nolimit_parc')) return [];
        $posts = get_posts(['post_type' => 'nolimit_parc', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']);
        $parks = [];
        foreach ($posts as $post) {
            $parks[] = [
                'id'          => $post->ID,
                'name'        => $post->post_title,
                'slug'        => $this->acf('parc_slug', $post->ID) ?: sanitize_title($post->post_title),
                'emoji'       => $this->acf('parc_emoji', $post->ID, '🌳'),
                'location'    => $this->acf('parc_location', $post->ID),
                'departement' => $this->acf('parc_departement', $post->ID),
                'image'       => $this->acf('parc_image', $post->ID),
                'rating'      => floatval($this->acf('parc_rating', $post->ID, 4.5)),
                'reviewCount' => (int) $this->acf('parc_review_count', $post->ID, 0),
                'minPrice'    => (int) $this->acf('parc_min_price', $post->ID, 25),
                'minAge'      => (int) $this->acf('parc_min_age', $post->ID, 3),
            ];
        }
        return $parks;
    }

    /** Récupère les vrais avis depuis le CPT nolimit_review, avec filtre optionnel par tag */
    private function get_real_reviews(string $tag_filter = '', int $limit = 3): array {
        if (!post_type_exists('nolimit_review')) return [];
        $posts = get_posts(['post_type' => 'nolimit_review', 'posts_per_page' => ($tag_filter ? -1 : $limit), 'orderby' => 'date', 'order' => 'DESC']);
        $reviews = [];
        foreach ($posts as $post) {
            $tag = $this->acf('review_tag', $post->ID, '');
            if ($tag_filter && $tag !== $tag_filter) continue;
            $reviews[] = [
                'id'     => $post->ID,
                'author' => $this->acf('review_author', $post->ID) ?: $post->post_title,
                'avatar' => $this->acf('review_avatar', $post->ID, '⭐'),
                'rating' => (int) ($this->acf('review_rating', $post->ID) ?: 5),
                'date'   => $this->acf('review_date', $post->ID) ?: get_the_date('F Y', $post),
                'text'   => $post->post_content,
                'source' => $this->acf('review_source', $post->ID, 'manual'),
                'tag'    => $tag,
            ];
            if (count($reviews) >= $limit) break;
        }
        return $reviews;
    }

    /** Récupère les vrais articles de blog */
    private function get_real_blog_posts(int $limit = 3): array {
        if (!post_type_exists('nolimit_blog')) return [];
        $posts = get_posts(['post_type' => 'nolimit_blog', 'posts_per_page' => $limit, 'orderby' => 'date', 'order' => 'DESC']);
        $articles = [];
        foreach ($posts as $post) {
            $cats = wp_get_post_terms($post->ID, 'nolimit_blog_category', ['fields' => 'names']);
            $articles[] = [
                'id'       => $post->ID,
                'slug'     => $post->post_name,
                'title'    => $post->post_title,
                'excerpt'  => $post->post_excerpt ?: wp_trim_words($post->post_content, 20),
                'image'    => get_the_post_thumbnail_url($post->ID, 'medium') ?: '',
                'date'     => get_the_date('j F Y', $post),
                'category' => !empty($cats) ? $cats[0] : 'Conseil',
            ];
        }
        return $articles;
    }


    /* ── Hub ───────────────────────────────────────────────── */
    public function api_hub() {
        $cards = [];
        $card_ids = ['duo', 'famille', 'enfant', 'entreprise'];
        $card_defaults = [
            'duo'        => ['title' => 'En Duo',       'description' => "Vivez l'aventure à deux",             'iconName' => 'Heart',     'color' => '#eb700f', 'link' => '/pour-qui/duo'],
            'famille'    => ['title' => 'En Famille',    'description' => "Des aventures pour toute la famille", 'iconName' => 'Users',     'color' => '#357600', 'link' => '/pour-qui/famille'],
            'enfant'     => ['title' => 'Enfants',       'description' => "Anniversaires et sorties scolaires", 'iconName' => 'Cake',      'color' => '#eb700f', 'link' => '/pour-qui/enfant'],
            'entreprise' => ['title' => 'Entreprises',   'description' => "Team building et séminaires",        'iconName' => 'Briefcase', 'color' => '#357600', 'link' => '/pour-qui/entreprise'],
        ];
        foreach ($card_ids as $id) {
            $d = $card_defaults[$id];
            $img_id = $this->opt("nl_pq_{$id}_image_id", 0);
            $cards[] = [
                'id' => $id, 'title' => $this->opt("nl_pq_{$id}_title", $d['title']),
                'description' => $this->opt("nl_pq_{$id}_desc", $d['description']),
                'image' => $img_id ? wp_get_attachment_url($img_id) : '',
                'link' => $this->opt("nl_pq_{$id}_link", $d['link']),
                'iconName' => $this->opt("nl_pq_{$id}_icon", $d['iconName']),
                'color' => $this->opt("nl_pq_{$id}_color", $d['color']),
            ];
        }
        return rest_ensure_response([
            'title' => $this->opt('nl_home_pourqui_title', "Pour Qui ?"),
            'subtitle' => $this->opt('nl_home_pourqui_subtitle', "Que vous soyez en duo, en famille, avec des enfants ou en équipe"),
            'cards' => $cards,
        ]);
    }


    /* ── Duo ───────────────────────────────────────────────── */
    public function api_duo() {
        $duo_activities = $this->get_json_option('nl_pq_duo_activities', []);
        $reviews = $this->get_real_reviews('Couple', 3);
        if (empty($reviews)) $reviews = $this->get_real_reviews('', 3);
        $admin_testimonials = $this->get_json_option('nl_pq_duo_testimonials', []);
        $testimonials = !empty($admin_testimonials) ? $admin_testimonials : $reviews;

        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_pq_duo_hero_title', "À deux, tout change."),
                'subtitle' => $this->opt('nl_pq_duo_hero_subtitle', "Parce que les meilleurs souvenirs se créent avec quelqu'un."),
                'badge'    => $this->opt('nl_pq_duo_hero_badge', 'Pour les duos'),
            ],
            'intro' => [
                'title'    => $this->opt('nl_pq_duo_intro_title', "L'aventure en duo, c'est magique"),
                'text'     => $this->opt('nl_pq_duo_intro_text', "Que ce soit pour un anniversaire de mariage, un EVJF entre meilleures amies, ou simplement pour partager un moment fort, nos activités sont pensées pour deux."),
            ],
            'activities'       => $duo_activities,
            'realActivities'   => $this->get_real_activities(),
            'moments'          => $this->get_json_option('nl_pq_duo_moments', [
                ['icon' => '🎂', 'title' => 'Anniversaire à deux',  'desc' => "Une journée mémorable, en dehors du commun."],
                ['icon' => '💍', 'title' => 'EVJF / EVG',            'desc' => "L'aventure avant la grande journée."],
                ['icon' => '🎁', 'title' => 'Cadeau original',       'desc' => "Offrez une expérience plutôt qu'un objet."],
                ['icon' => '💡', 'title' => 'Premier rendez-vous',   'desc' => "Sortez des sentiers battus."],
            ]),
            'pack' => [
                'title'       => $this->opt('nl_pq_duo_pack_title', 'Pack Duo'),
                'discount'    => $this->opt('nl_pq_duo_pack_discount', '-15%'),
                'description' => $this->opt('nl_pq_duo_pack_desc', "Réservez 2 places sur la même activité et profitez d'une réduction immédiate."),
                'features'    => $this->get_json_option('nl_pq_duo_pack_features', [
                    '2 places au tarif réduit', 'Même activité, même créneau', 'Photo souvenir offerte', 'Annulation gratuite 48h avant'
                ]),
                'stats' => $this->get_json_option('nl_pq_duo_pack_stats', [
                    ['val' => '-15%', 'label' => 'sur 2 places'],
                    ['val' => '2h', 'label' => 'en moyenne'],
                    ['val' => '6', 'label' => 'activités dispo'],
                    ['val' => '4.9★', 'label' => 'note duo'],
                ]),
            ],
            'testimonials'     => $testimonials,
            'blogPosts'        => $this->get_real_blog_posts(3),
            'blog' => [
                'title'    => $this->opt('nl_pq_duo_blog_title', 'Idées & actualités'),
                'subtitle' => $this->opt('nl_pq_duo_blog_subtitle', "Inspirez-vous pour votre prochaine aventure à deux."),
            ],
            'cta' => [
                'title'    => $this->opt('nl_pq_duo_cta_title', "Prêts pour l'aventure ?"),
                'subtitle' => $this->opt('nl_pq_duo_cta_subtitle', "Choisissez votre parc et réservez vos deux places en 2 minutes."),
            ],
            'parks' => $this->get_real_parks(),
        ]);
    }


    /* ── Enfant ────────────────────────────────────────────── */
    public function api_enfant() {
        $reviews = $this->get_real_reviews('Famille', 3);
        if (empty($reviews)) $reviews = $this->get_real_reviews('Anniversaire', 3);
        if (empty($reviews)) $reviews = $this->get_real_reviews('', 3);
        $admin_testimonials = $this->get_json_option('nl_pq_enfant_testimonials', []);
        $testimonials = !empty($admin_testimonials) ? $admin_testimonials : $reviews;

        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_pq_enfant_hero_title', "Leur première grande aventure."),
                'subtitle' => $this->opt('nl_pq_enfant_hero_subtitle', "Des activités pensées et adaptées pour chaque âge, de 4 à 15 ans."),
                'badge'    => $this->opt('nl_pq_enfant_hero_badge', 'Pour les enfants'),
            ],
            'intro' => [
                'title'    => $this->opt('nl_pq_enfant_intro_title', "Pour les enfants en famille"),
                'text'     => $this->opt('nl_pq_enfant_intro_text', "Nos activités sont conçues pour que les enfants vivent leur aventure en toute sécurité."),
            ],
            'activities'       => $this->get_json_option('nl_pq_enfant_activities', []),
            'realActivities'   => $this->get_real_activities(),
            'safetyPoints'     => $this->get_json_option('nl_pq_enfant_safety', [
                ['icon' => '🛡️',   'title' => 'Harnais sur mesure',     'desc' => "Équipements dimensionnés pour les enfants, certifiés EN."],
                ['icon' => '👨‍🏫', 'title' => 'Moniteurs spécialisés',  'desc' => "Diplômés BPJEPS ou BAFA."],
                ['icon' => '🚑',   'title' => 'Secouriste sur place',    'desc' => "Un secouriste qualifié est présent en permanence."],
                ['icon' => '📏',   'title' => 'Tailles et poids',        'desc' => "Critères stricts vérifiés à l'accueil."],
            ]),
            'birthday' => [
                'title'       => $this->opt('nl_pq_enfant_birthday_title', 'Anniversaire inoubliable.'),
                'description' => $this->opt('nl_pq_enfant_birthday_desc', "Offrez à votre enfant un anniversaire qui sort vraiment de l'ordinaire."),
                'price'       => $this->opt('nl_pq_enfant_birthday_price', 'À partir de 199€'),
                'capacity'    => $this->opt('nl_pq_enfant_birthday_capacity', "jusqu'à 12 enfants"),
                'features'    => $this->get_json_option('nl_pq_enfant_birthday_features', [
                    'Invitation personnalisée offerte', 'Zone pique-nique réservée', 'Animation dédiée 1h30',
                    'Goûter + boissons inclus', 'Photo de groupe imprimée', "Coffret souvenir pour l'anniversaire",
                ]),
            ],
            'testimonials'     => $testimonials,
            'cta' => [
                'title'    => $this->opt('nl_pq_enfant_cta_title', "Leur prochaine aventure commence ici."),
                'subtitle' => $this->opt('nl_pq_enfant_cta_subtitle', "Réservez en 2 minutes, souvenirs pour la vie."),
            ],
            'parks' => $this->get_real_parks(),
        ]);
    }


    /* ── Entreprise ────────────────────────────────────────── */
    public function api_entreprise() {
        $reviews = $this->get_real_reviews('Entreprise', 3);
        if (empty($reviews)) $reviews = $this->get_real_reviews('Team Building', 3);
        if (empty($reviews)) $reviews = $this->get_real_reviews('', 3);
        $admin_testimonials = $this->get_json_option('nl_pq_entreprise_testimonials', []);
        $testimonials = !empty($admin_testimonials) ? $admin_testimonials : $reviews;

        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_pq_entreprise_hero_title', "La nature transforme vos équipes."),
                'subtitle' => $this->opt('nl_pq_entreprise_hero_subtitle', "Team building, séminaires, incentives — des formats outdoor sur mesure."),
                'badge'    => $this->opt('nl_pq_entreprise_hero_badge', 'Pour les entreprises'),
            ],
            'kpis' => $this->get_json_option('nl_pq_entreprise_kpis', [
                ['val' => '500+', 'label' => 'événements réalisés'],
                ['val' => '98%',  'label' => 'de satisfaction'],
                ['val' => '24h',  'label' => 'délai de réponse'],
                ['val' => '10–300', 'label' => 'participants'],
            ]),
            'formats'    => $this->get_json_option('nl_pq_entreprise_formats', [
                ['id' => 'team',      'title' => 'Team Building',          'desc' => "Activités collaboratives.", 'duration' => 'Demi-journée', 'minPersons' => 10],
                ['id' => 'seminaire', 'title' => 'Séminaire Outdoor',      'desc' => "Réunion + activités nature.", 'duration' => '1-2 jours', 'minPersons' => 15],
                ['id' => 'challenge', 'title' => 'Challenge Inter-équipes','desc' => "Compétition amicale.", 'duration' => 'Journée', 'minPersons' => 20],
                ['id' => 'event',     'title' => 'Événement Corporate',     'desc' => "Sur mesure.", 'duration' => 'Sur mesure', 'minPersons' => 30],
            ]),
            'advantages' => $this->get_json_option('nl_pq_entreprise_advantages', [
                ['icon' => '⚡', 'title' => 'Réponse en 24h',         'desc' => "Devis personnalisé sous 24h ouvrées."],
                ['icon' => '🎨', 'title' => '100% sur mesure',        'desc' => "Programme adapté à vos objectifs."],
                ['icon' => '🌿', 'title' => 'Cadre naturel unique',   'desc' => "5 parcs forestiers."],
                ['icon' => '👨‍🏫', 'title' => 'Facilitateurs experts', 'desc' => "Animateurs expérimentés."],
                ['icon' => '📸', 'title' => 'Livrables inclus',       'desc' => "Photos HD, galerie en ligne."],
                ['icon' => '💳', 'title' => 'Facturation pro',        'desc' => "Facture TVA, paiement 30j."],
            ]),
            'clientLogos'  => $this->get_json_option('nl_pq_entreprise_logos', []),
            'testimonials' => $testimonials,
            'contact' => [
                'phone' => $this->opt('nl_pq_entreprise_phone', '01 23 45 67 89'),
                'email' => $this->opt('nl_pq_entreprise_email', 'entreprise@nolimit.fr'),
            ],
            'form' => [
                'title'    => $this->opt('nl_pq_entreprise_form_title', 'Obtenez votre devis.'),
                'subtitle' => $this->opt('nl_pq_entreprise_form_subtitle', 'Réponse garantie sous 24h ouvrées.'),
            ],
            'parks' => $this->get_real_parks(),
        ]);
    }


    /* ── Famille ───────────────────────────────────────────── */
    public function api_famille() {
        $reviews = $this->get_real_reviews('Famille', 3);
        if (empty($reviews)) $reviews = $this->get_real_reviews('', 3);
        $admin_testimonials = $this->get_json_option('nl_pq_famille_testimonials', []);
        $testimonials = !empty($admin_testimonials) ? $admin_testimonials : $reviews;

        return rest_ensure_response([
            'hero' => [
                'title'    => $this->opt('nl_pq_famille_hero_title', "La forêt pour tous."),
                'subtitle' => $this->opt('nl_pq_famille_hero_subtitle', "De 5 à 75 ans, chaque membre trouve son aventure."),
                'badge'    => $this->opt('nl_pq_famille_hero_badge', 'Pour les familles'),
            ],
            'intro' => [
                'title'    => $this->opt('nl_pq_famille_intro_title', "Des moments en famille"),
                'text'     => $this->opt('nl_pq_famille_intro_text', "Chez NoLimit Aventure, chaque famille est unique. Activités adaptées, espaces pique‑nique, tarifs avantageux."),
            ],
            'ageGroups'     => $this->get_json_option('nl_pq_famille_age_groups', [
                ['age' => '5–7 ans',  'emoji' => '🐣', 'color' => '#f59e0b', 'bg' => '#fffbeb', 'activities' => ['Parcours découverte', "Tir à l'arc initiation", 'Balades nature'], 'note' => 'Accompagné obligatoire'],
                ['age' => '8–11 ans', 'emoji' => '🌱', 'color' => '#357600', 'bg' => '#f0fdf4', 'activities' => ['Accrobranche junior', 'Tyrolienne courte', 'Orientation boussole'], 'note' => 'Moniteur dédié'],
                ['age' => '12–17 ans','emoji' => '🚀', 'color' => '#eb700f', 'bg' => '#fef3ea', 'activities' => ['Accrobranche expert', 'Via ferrata', 'Canoë rapide'], 'note' => 'Avec ou sans parent'],
                ['age' => 'Adultes',  'emoji' => '🏔️', 'color' => '#6366f1', 'bg' => '#f0f0ff', 'activities' => ['Tous les parcours', 'Via ferrata complète', 'Tyrolienne longue'], 'note' => 'Liberté totale'],
            ]),
            'familyPacks'   => $this->get_json_option('nl_pq_famille_packs', []),
            'event' => [
                'title'       => $this->opt('nl_pq_famille_event_title', "Vous avez un événement à fêter en famille ?"),
                'description' => $this->opt('nl_pq_famille_event_desc', "Anniversaire, retrouvailles… On s'occupe de tout."),
                'tags'        => $this->get_json_option('nl_pq_famille_event_tags', [
                    'Anniversaire enfant', "Fête de fin d'année", 'Grands-parents & petits-enfants'
                ]),
            ],
            'practicalInfo' => $this->get_json_option('nl_pq_famille_practical', [
                ['icon' => '👟', 'title' => 'Tenue requise', 'desc' => "Chaussures fermées et vêtements sportifs."],
                ['icon' => '☀️', 'title' => 'Météo',          'desc' => "Certaines activités suspendues par mauvais temps."],
                ['icon' => '🍱', 'title' => 'Pique-nique',    'desc' => "Espaces dédiés disponibles."],
                ['icon' => '🅿️', 'title' => 'Parking',        'desc' => "Parking familial gratuit."],
                ['icon' => '🍼', 'title' => 'Tout-petits',    'desc' => "Aire de jeux et espace détente."],
                ['icon' => '🏥', 'title' => 'Sécurité',       'desc' => "Infirmier ou secouriste présent."],
            ]),
            'testimonials'     => $testimonials,
            'blogPosts'        => $this->get_real_blog_posts(3),
            'blog' => [
                'title'    => $this->opt('nl_pq_famille_blog_title', 'Actualités & conseils famille'),
                'subtitle' => $this->opt('nl_pq_famille_blog_subtitle', "Des idées pour la nature en famille."),
            ],
            'cta' => [
                'title'    => $this->opt('nl_pq_famille_cta_title', "La forêt vous attend."),
                'subtitle' => $this->opt('nl_pq_famille_cta_subtitle', "Réservez votre journée famille."),
            ],
            'parks' => $this->get_real_parks(),
            'realActivities' => $this->get_real_activities(),
        ]);
    }
}
