<?php
/**
 * Module : Activités
 * CPT : nolimit_activity | Routes : GET /activities, GET /activities/{id}
 *
 * Les grilles tarifaires sont gérées par une metabox visuelle
 * et stockées en JSON dans post_meta (pas via ACF).
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Activities extends NoLimit_Module {

    public function register_post_types(): void {
        register_post_type('nolimit_activity', [
            'labels' => ['name' => 'Activités', 'singular_name' => 'Activité', 'add_new' => 'Ajouter', 'all_items' => 'Activités'],
            'public' => false, 'show_ui' => true, 'show_in_menu' => false,
            'supports' => ['title', 'editor', 'thumbnail', 'page-attributes'],
        ]);

        add_action('add_meta_boxes', [$this, 'add_tarifs_metabox']);
        add_action('save_post_nolimit_activity', [$this, 'save_tarifs_metabox'], 99);
    }

    public function register_acf_fields(): void {
        acf_add_local_field_group([
            'key' => 'group_activity', 'title' => 'Informations Activité',
            'fields' => [
                ['key' => 'field_act_emoji',        'label' => 'Emoji',        'name' => 'activity_emoji',        'type' => 'text', 'default_value' => '🎯'],
                ['key' => 'field_act_slug',         'label' => 'Slug',         'name' => 'activity_slug',         'type' => 'text'],
                ['key' => 'field_act_image',        'label' => 'Image',        'name' => 'activity_image',        'type' => 'image', 'return_format' => 'url'],
                ['key' => 'field_act_duration',     'label' => 'Durée',        'name' => 'activity_duration',     'type' => 'text', 'placeholder' => '2h'],
                ['key' => 'field_act_min_age',      'label' => 'Âge minimum',  'name' => 'activity_min_age',      'type' => 'number', 'default_value' => 6],
                ['key' => 'field_act_participants', 'label' => 'Participants', 'name' => 'activity_participants', 'type' => 'text'],
                ['key' => 'field_act_difficulty',   'label' => 'Difficulté',   'name' => 'activity_difficulty',   'type' => 'select',
                    'choices' => ['Facile' => 'Facile', 'Intermédiaire' => 'Intermédiaire', 'Difficile' => 'Difficile', 'Expert' => 'Expert'], 'default_value' => 'Intermédiaire'],
                ['key' => 'field_act_intensity',    'label' => 'Intensité',    'name' => 'activity_intensity',    'type' => 'select',
                    'choices' => ['easy' => 'Facile', 'medium' => 'Modéré', 'hard' => 'Sportif', 'extreme' => 'Extrême']],
                ['key' => 'field_act_parks',        'label' => 'Parcs associés', 'name' => 'activity_parks', 'type' => 'post_object', 'post_type' => ['nolimit_parc'], 'multiple' => 1, 'allow_null' => 1, 'return_format' => 'id'],
                // NOTE: Tarifs gérés par metabox visuelle, PAS par ACF
            ],
            'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_activity']]],
        ]);
    }

    // ═══════════════════════════════════════════════════════════
    // TARIFS METABOX
    // ═══════════════════════════════════════════════════════════

    public function add_tarifs_metabox(): void {
        add_meta_box('nl_act_tarifs', '💰 Grilles tarifaires', [$this, 'render_tarifs_metabox'], 'nolimit_activity', 'normal', 'high');
    }

    public function render_tarifs_metabox($post): void {
        wp_nonce_field('nl_act_tarifs_save', 'nl_act_tarifs_nonce');

        $raw = get_post_meta($post->ID, 'activity_tarifs_json', true);
        $grids = [];
        if ($raw && is_string($raw)) { $d = json_decode($raw, true); if (is_array($d)) $grids = $d; }

        echo '<p class="description">Tarifs globaux de cette activité (utilisés si le parc ne définit pas ses propres tarifs).</p>';
        echo '<div id="nl-tarifs-grids">';

        foreach ($grids as $gi => $grid):
            $lines = $grid['lignes'] ?? [];
        ?>
        <div class="nl-tarif-grid" style="border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0;background:#fafafa;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
                <strong>Grille :</strong>
                <input type="text" name="nl_tarifs[<?php echo $gi; ?>][titre]" value="<?php echo esc_attr($grid['titre'] ?? ''); ?>" placeholder="Titre de la grille (ex: Tarifs Matin)" class="regular-text" style="flex:1;">
                <button type="button" class="button" style="color:#b32d2e;border-color:#b32d2e;" onclick="if(confirm('Supprimer cette grille ?'))this.closest('.nl-tarif-grid').remove()">✕ Supprimer</button>
            </div>
            <div class="nl-tarif-lines">
                <?php foreach ($lines as $li => $line): ?>
                <div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #eee;">
                    <span style="color:#aaa;">•</span>
                    <input type="text" name="nl_tarifs[<?php echo $gi; ?>][lignes][<?php echo $li; ?>][label]" value="<?php echo esc_attr($line['label'] ?? ''); ?>" placeholder="Label (ex: Adulte)" style="width:220px;">
                    <input type="text" name="nl_tarifs[<?php echo $gi; ?>][lignes][<?php echo $li; ?>][prix]" value="<?php echo esc_attr($line['prix'] ?? ''); ?>" placeholder="Prix (ex: 22,00 €)" style="width:140px;">
                    <button type="button" class="button" style="color:#b32d2e;border-color:#b32d2e;padding:2px 8px;min-height:28px;" onclick="this.closest('div').remove()">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button" style="margin-top:6px;" onclick="nlActAddLine(this, <?php echo $gi; ?>)">＋ Ajouter une ligne</button>
        </div>
        <?php endforeach;

        echo '</div>';
        echo '<button type="button" class="button button-primary" style="margin-top:12px;" onclick="nlActAddGrid()">＋ Ajouter une grille tarifaire</button>';
        ?>
        <script>
        var nlActGridIdx = <?php echo count($grids); ?>;
        function nlActAddGrid() {
            var idx = nlActGridIdx++;
            var html = '<div class="nl-tarif-grid" style="border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0;background:#fafafa;">'
                + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">'
                + '<strong>Grille :</strong>'
                + '<input type="text" name="nl_tarifs['+idx+'][titre]" placeholder="Titre de la grille" class="regular-text" style="flex:1;">'
                + '<button type="button" class="button" style="color:#b32d2e;border-color:#b32d2e;" onclick="if(confirm(\'Supprimer ?\'))this.closest(\'.nl-tarif-grid\').remove()">✕ Supprimer</button>'
                + '</div><div class="nl-tarif-lines"></div>'
                + '<button type="button" class="button" style="margin-top:6px;" onclick="nlActAddLine(this,'+idx+')">＋ Ajouter une ligne</button>'
                + '</div>';
            document.getElementById('nl-tarifs-grids').insertAdjacentHTML('beforeend', html);
        }
        var nlActLineCounts = {};
        function nlActAddLine(btn, gridIdx) {
            var container = btn.closest('.nl-tarif-grid').querySelector('.nl-tarif-lines');
            if (!nlActLineCounts[gridIdx]) nlActLineCounts[gridIdx] = container.querySelectorAll('div').length;
            var li = nlActLineCounts[gridIdx]++;
            var html = '<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #eee;">'
                + '<span style="color:#aaa;">•</span>'
                + '<input type="text" name="nl_tarifs['+gridIdx+'][lignes]['+li+'][label]" placeholder="Label (ex: Adulte)" style="width:220px;">'
                + '<input type="text" name="nl_tarifs['+gridIdx+'][lignes]['+li+'][prix]" placeholder="Prix (ex: 22,00 €)" style="width:140px;">'
                + '<button type="button" class="button" style="color:#b32d2e;border-color:#b32d2e;padding:2px 8px;min-height:28px;" onclick="this.closest(\'div\').remove()">✕</button>'
                + '</div>';
            container.insertAdjacentHTML('beforeend', html);
        }
        </script>
        <?php
    }

    public function save_tarifs_metabox(int $post_id): void {
        if (!isset($_POST['nl_act_tarifs_nonce']) || !wp_verify_nonce($_POST['nl_act_tarifs_nonce'], 'nl_act_tarifs_save')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $raw = $_POST['nl_tarifs'] ?? [];
        if (!is_array($raw) || empty($raw)) {
            update_post_meta($post_id, 'activity_tarifs_json', '[]');
            return;
        }

        $grids = [];
        foreach ($raw as $grid) {
            $titre = sanitize_text_field(trim($grid['titre'] ?? ''));
            if (empty($titre)) continue;
            $lignes = [];
            if (!empty($grid['lignes']) && is_array($grid['lignes'])) {
                foreach ($grid['lignes'] as $line) {
                    $label = sanitize_text_field(trim($line['label'] ?? ''));
                    $prix  = sanitize_text_field(trim($line['prix'] ?? ''));
                    if ($label !== '' && $prix !== '') $lignes[] = ['label' => $label, 'prix' => $prix];
                }
            }
            if (!empty($lignes)) $grids[] = ['titre' => $titre, 'lignes' => $lignes];
        }

        update_post_meta($post_id, 'activity_tarifs_json', wp_json_encode($grids, JSON_UNESCAPED_UNICODE));
    }

    // ═══════════════════════════════════════════════════════════
    // API
    // ═══════════════════════════════════════════════════════════

    public function get_api_routes(): array {
        return [
            'activities' => ['methods' => 'GET', 'callback' => [$this, 'api_list']],
            'activities/(?P<id>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_single']],
        ];
    }

    public function api_list($request = null) {
        $park_filter = $request ? $request->get_param('park') : null;
        $items = [];
        foreach ($this->query('nolimit_activity') as $post) {
            $formatted = $this->format($post);
            if ($park_filter && !empty($formatted['parks']) && !in_array($park_filter, $formatted['parks'])) continue;
            $items[] = $formatted;
        }
        return rest_ensure_response($items);
    }

    public function api_single($request) {
        $id = $request->get_param('id');
        foreach ($this->query('nolimit_activity') as $post) {
            $slug = $this->acf('activity_slug', $post->ID) ?: sanitize_title($post->post_title);
            if ($slug === $id || $post->ID == $id) return rest_ensure_response($this->format($post));
        }
        return new WP_Error('not_found', 'Activité non trouvée', ['status' => 404]);
    }

    private function format($post): array {
        return [
            'id'           => $post->ID,
            'name'         => $post->post_title,
            'slug'         => $this->acf('activity_slug', $post->ID) ?: sanitize_title($post->post_title),
            'emoji'        => $this->acf('activity_emoji', $post->ID, '🎯'),
            'description'  => $post->post_content,
            'image'        => $this->acf('activity_image', $post->ID),
            'duration'     => $this->acf('activity_duration', $post->ID),
            'minAge'       => (int) ($this->acf('activity_min_age', $post->ID) ?: 6),
            'participants' => $this->acf('activity_participants', $post->ID),
            'difficulty'   => $this->acf('activity_difficulty', $post->ID, 'Intermédiaire'),
            'intensity'    => $this->acf('activity_intensity', $post->ID, 'medium'),
            'tarifs'       => $this->parse_tarifs($post->ID),
            'parks'        => $this->get_park_slugs($post->ID),
        ];
    }

    /** Read tarifs from post_meta directly (NOT ACF) */
    private function parse_tarifs(int $post_id): array {
        $raw = get_post_meta($post_id, 'activity_tarifs_json', true);
        if (empty($raw)) return [];
        $data = json_decode($raw, true);
        if (!is_array($data)) return [];
        $tarifs = [];
        foreach ($data as $group) {
            if (empty($group['titre']) || !isset($group['lignes'])) continue;
            $lignes = [];
            foreach ((array) $group['lignes'] as $l) {
                if (!empty($l['label']) && !empty($l['prix'])) $lignes[] = ['label' => $l['label'], 'prix' => $l['prix']];
            }
            if (!empty($lignes)) $tarifs[] = ['titre' => $group['titre'], 'lignes' => $lignes];
        }
        return $tarifs;
    }

    private function get_park_slugs(int $post_id): array {
        $ids = get_field('activity_parks', $post_id);
        if (!is_array($ids) || empty($ids)) return [];
        $slugs = [];
        foreach ($ids as $pid) {
            $park_id = is_object($pid) ? $pid->ID : (int) $pid;
            $s = $this->acf('parc_slug', $park_id) ?: sanitize_title(get_the_title($park_id));
            if ($s) $slugs[] = $s;
        }
        return $slugs;
    }

    public function create_defaults(): void {
        if (get_posts(['post_type' => 'nolimit_activity', 'posts_per_page' => 1])) return;
        $items = [
            ['title' => 'Accrobranche', 'emoji' => '🌳', 'slug' => 'accrobranche', 'desc' => "Évoluez d'arbre en arbre sur nos parcours sécurisés.", 'duration' => '2h-3h', 'min_age' => 3, 'intensity' => 'medium', 'difficulty' => 'Intermédiaire',
             'tarifs' => '[{"titre":"Tarifs internet — Matin","lignes":[{"label":"Pitchoun (- 1m20)","prix":"10,00 €"},{"label":"Enfant (1m20 à 1m40)","prix":"14,00 €"},{"label":"Ado (+1m40, - 18 ans)","prix":"18,00 €"},{"label":"Adulte","prix":"22,00 €"}]},{"titre":"Tarifs internet — Après-midi","lignes":[{"label":"Pitchoun (- 1m20)","prix":"12,00 €"},{"label":"Enfant (1m20 à 1m40)","prix":"16,00 €"},{"label":"Ado (+1m40, - 18 ans)","prix":"20,00 €"},{"label":"Adulte","prix":"25,00 €"}]}]'],
            ['title' => 'Paintball', 'emoji' => '🎯', 'slug' => 'paintball', 'desc' => 'Affrontez-vous en équipe.', 'duration' => '2h', 'min_age' => 12, 'intensity' => 'hard', 'difficulty' => 'Intermédiaire',
             'tarifs' => '[{"titre":"Tarifs internet","lignes":[{"label":"Pack 100 billes","prix":"15,00 €"},{"label":"Pack 200 billes","prix":"25,00 €"},{"label":"Pack 300 billes","prix":"32,00 €"}]}]'],
            ['title' => 'Tyrolienne', 'emoji' => '⚡', 'slug' => 'tyrolienne', 'desc' => 'Sensations fortes garanties.', 'duration' => '30min', 'min_age' => 8, 'intensity' => 'hard', 'difficulty' => 'Difficile',
             'tarifs' => '[{"titre":"Tarifs internet","lignes":[{"label":"Enfant (- 12 ans)","prix":"12,00 €"},{"label":"Ado / Adulte","prix":"16,00 €"}]}]'],
            ['title' => "Tir à l'arc", 'emoji' => '🏹', 'slug' => 'tir-arc', 'desc' => "Initiez-vous au tir à l'arc.", 'duration' => '1h', 'min_age' => 6, 'intensity' => 'easy', 'difficulty' => 'Facile',
             'tarifs' => '[{"titre":"Tarifs internet","lignes":[{"label":"Enfant (- 12 ans)","prix":"10,00 €"},{"label":"Ado / Adulte","prix":"14,00 €"},{"label":"Initiation 30 min","prix":"8,00 €"}]}]'],
            ['title' => 'Escape Game Outdoor', 'emoji' => '🔐', 'slug' => 'escape-game', 'desc' => 'Résolvez les énigmes en pleine nature.', 'duration' => '1h', 'min_age' => 10, 'intensity' => 'medium', 'difficulty' => 'Intermédiaire',
             'tarifs' => '[{"titre":"Tarifs internet","lignes":[{"label":"2 personnes","prix":"20,00 €/pers"},{"label":"3-4 personnes","prix":"16,00 €/pers"},{"label":"5-6 personnes","prix":"14,00 €/pers"}]}]'],
            ['title' => 'Parcours Filet', 'emoji' => '🕸️', 'slug' => 'parcours-filet', 'desc' => 'Parcours suspendu sur filets.', 'duration' => '1h', 'min_age' => 3, 'intensity' => 'easy', 'difficulty' => 'Facile',
             'tarifs' => '[{"titre":"Tarifs internet","lignes":[{"label":"Enfant (3-12 ans)","prix":"8,00 €"},{"label":"Ado / Adulte","prix":"12,00 €"}]}]'],
        ];
        foreach ($items as $i => $act) {
            $id = wp_insert_post(['post_title' => $act['title'], 'post_content' => $act['desc'], 'post_type' => 'nolimit_activity', 'post_status' => 'publish', 'menu_order' => $i]);
            if (!$id) continue;
            update_field('activity_emoji', $act['emoji'], $id);
            update_field('activity_slug', $act['slug'], $id);
            update_field('activity_duration', $act['duration'], $id);
            update_field('activity_min_age', $act['min_age'], $id);
            update_field('activity_intensity', $act['intensity'], $id);
            update_field('activity_difficulty', $act['difficulty'], $id);
            // Store tarifs in post_meta directly (not ACF)
            update_post_meta($id, 'activity_tarifs_json', $act['tarifs']);
        }
    }
}
