<?php
/**
 * Module : Hero / Carousel
 *
 * Gère les slides du hero, badge, titre principal et vidéo.
 * Route : GET /nolimit/v1/hero
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Hero extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'hero' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_hero'],
            ],
        ];
    }

    public function api_hero(): WP_REST_Response {
        // Slides
        $slides_raw = $this->opt('nl_hero_slides', '[]');
        $slides = json_decode($slides_raw, true) ?: [];

        // Si aucun slide configuré, construire à partir des images
        if (empty($slides)) {
            for ($i = 1; $i <= 5; $i++) {
                $img_id = $this->opt("nl_hero_slide_{$i}_image_id", 0);
                $title   = $this->opt("nl_hero_slide_{$i}_title", '');
                $sub     = $this->opt("nl_hero_slide_{$i}_subtitle", '');
                if ($img_id || $title) {
                    $slides[] = [
                        'id'       => (string) $i,
                        'url'      => $img_id ? wp_get_attachment_url($img_id) : '',
                        'title'    => $title,
                        'subtitle' => $sub,
                    ];
                }
            }
        }

        $data = [
            'slides' => $slides,
            'badge' => [
                'text' => $this->opt('nl_hero_badge_text', "L'aventure commence ici"),
                'icon' => $this->opt('nl_hero_badge_icon', 'Sparkles'),
            ],
            'mainTitle' => [
                'line1'     => $this->opt('nl_hero_main_line1', "L'aventure vous"),
                'highlight' => $this->opt('nl_hero_main_highlight', 'appelle'),
            ],
            'video' => [
                'url'         => $this->opt('nl_hero_video_url', ''),
                'thumbnail'   => $this->opt('nl_hero_video_thumb_id', 0) ? wp_get_attachment_url($this->opt('nl_hero_video_thumb_id', 0)) : '',
                'buttonText'  => $this->opt('nl_hero_video_btn', 'Voir la vidéo'),
                'description' => $this->opt('nl_hero_video_desc', "Découvrez l'expérience"),
            ],
        ];

        return rest_ensure_response($data);
    }

    public function create_defaults(): void {
        if (get_option('nl_hero_badge_text')) return;

        $defaults = [
            'nl_hero_badge_text'       => "L'aventure commence ici",
            'nl_hero_badge_icon'       => 'Sparkles',
            'nl_hero_main_line1'       => "L'aventure vous",
            'nl_hero_main_highlight'   => 'appelle',
            'nl_hero_video_btn'        => 'Voir la vidéo',
            'nl_hero_video_desc'       => "Découvrez l'expérience",
            'nl_hero_slide_1_title'    => 'Tyrolienne géante',
            'nl_hero_slide_1_subtitle' => 'Sensation de vol garantie',
            'nl_hero_slide_2_title'    => 'Accrobranche extrême',
            'nl_hero_slide_2_subtitle' => 'Défis à la hauteur',
            'nl_hero_slide_3_title'    => 'Paintball stratégique',
            'nl_hero_slide_3_subtitle' => "Adrénaline et esprit d'équipe",
        ];

        foreach ($defaults as $key => $value) {
            update_option($key, $value);
        }
    }
}
