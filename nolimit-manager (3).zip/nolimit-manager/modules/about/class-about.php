<?php
/**
 * Module : About (À propos) — Version complète
 * Routes API : /about, /about/history, /about/values, /about/jobs, /about/partners
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_About extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'about'           => ['methods' => 'GET', 'callback' => [$this, 'api_main']],
            'about/history'   => ['methods' => 'GET', 'callback' => [$this, 'api_history']],
            'about/values'    => ['methods' => 'GET', 'callback' => [$this, 'api_values']],
            'about/jobs'      => ['methods' => 'GET', 'callback' => [$this, 'api_jobs']],
            'about/partners'  => ['methods' => 'GET', 'callback' => [$this, 'api_partners']],
        ];
    }

    public function api_main() {
        $navCards = $this->get_json_option('nl_about_nav_cards', [
            ['id' => 'history',    'title' => 'Notre Histoire',  'desc' => "De Chevry en 2016 à 5 parcs aujourd'hui.", 'icon' => 'History',   'emoji' => '🏔️', 'link' => '/about/histoire',    'color' => '#357600', 'bg' => '#f0f7e8'],
            ['id' => 'values',     'title' => 'Notre ADN',       'desc' => 'Sécurité, nature, plaisir, excellence.',   'icon' => 'Target',    'emoji' => '💚', 'link' => '/about/valeurs',     'color' => '#eb700f', 'bg' => '#fef3ea'],
            ['id' => 'parks',      'title' => 'Nos Parcs',       'desc' => '5 destinations à travers la France.',      'icon' => 'MapPin',    'emoji' => '📍', 'link' => '/about/parcs',       'color' => '#357600', 'bg' => '#f0f7e8'],
            ['id' => 'jobs',       'title' => 'Nos Emplois',     'desc' => "Rejoignez l'aventure NoLimit.",            'icon' => 'Briefcase', 'emoji' => '🧗', 'link' => '/about/emplois',     'color' => '#eb700f', 'bg' => '#fef3ea'],
            ['id' => 'news',       'title' => 'Actualités',      'desc' => 'Les dernières news NoLimit.',              'icon' => 'Newspaper', 'emoji' => '🗞️', 'link' => '/about/actualites',  'color' => '#357600', 'bg' => '#f0f7e8'],
            ['id' => 'partners',   'title' => 'Partenaires',     'desc' => 'Les orgas qui partagent nos valeurs.',     'icon' => 'Users',     'emoji' => '🤝', 'link' => '/about/partenaires', 'color' => '#eb700f', 'bg' => '#fef3ea'],
        ]);

        $stats = $this->get_json_option('nl_about_stats', [
            ['value' => '2016',  'label' => 'Année de création',   'icon' => '🌲'],
            ['value' => '5',     'label' => 'Parcs en France',     'icon' => '🏆'],
            ['value' => '120+',  'label' => 'Collaborateurs',      'icon' => '🧗'],
            ['value' => '50k+',  'label' => 'Visiteurs / an',      'icon' => '⭐'],
        ]);

        return rest_ensure_response([
            'hero' => [
                'badge'     => $this->opt('nl_about_hero_badge',    'Depuis 2015 · Leader français du parc aventure'),
                'title'     => $this->opt('nl_about_hero_title',    "On est NoLimit."),
                'subtitle'  => $this->opt('nl_about_hero_subtitle', "Une équipe de passionnés qui croit dur comme fer que l'aventure, ça change la vie."),
                'cta1Text'  => $this->opt('nl_about_cta1_text',     'Notre histoire'),
                'cta1Link'  => $this->opt('nl_about_cta1_link',     '/about/histoire'),
                'cta2Text'  => $this->opt('nl_about_cta2_text',     'Découvrir nos parcs'),
                'cta2Link'  => $this->opt('nl_about_cta2_link',     '/parcs'),
            ],
            'hub' => [
                'badge' => $this->opt('nl_about_hub_badge', 'Tout sur NoLimit Aventure'),
                'title' => $this->opt('nl_about_hub_title', 'Explorez notre univers'),
            ],
            'navCards' => $navCards,
            'stats'    => $stats,
        ]);
    }

    public function api_history() {
        $timeline = $this->get_json_option('nl_about_timeline', [
            ['year' => '2015', 'emoji' => '🌲', 'title' => 'Naissance à Chevry',              'desc' => "Trois amis passionnés ouvrent le premier parc.", 'icon' => 'Leaf',   'color' => '#357600'],
            ['year' => '2017', 'emoji' => '📍', 'title' => 'Nemours nous appelle',            'desc' => "Deuxième parc en Seine-et-Marne.",    'icon' => 'Zap',    'color' => '#eb700f'],
            ['year' => '2019', 'emoji' => '🏆', 'title' => 'Montargis & la croissance',       'desc' => "Troisième parc, équipe de +30 personnes.",  'icon' => 'Target', 'color' => '#357600'],
            ['year' => '2021', 'emoji' => '🌿', 'title' => 'Digny : renaissance post-Covid',  'desc' => "Inauguration après la pandémie.",   'icon' => 'Sun',    'color' => '#eb700f'],
            ['year' => '2022', 'emoji' => '🚀', 'title' => "Le Coudray & l'ambition nationale",'desc' => "Cinquième parc, label ONF.",    'icon' => 'Rocket', 'color' => '#357600'],
            ['year' => '2025', 'emoji' => '✨', 'title' => "Aujourd'hui & demain",             'desc' => "5 parcs, cap sur 2027.", 'icon' => 'Star',  'color' => '#eb700f'],
        ]);

        $stats = $this->get_json_option('nl_about_history_stats', [
            ['value' => '5',    'label' => 'Parcs ouverts',     'icon' => '🌲'],
            ['value' => '120+', 'label' => 'Emplois créés',     'icon' => '🏆'],
            ['value' => '75k+', 'label' => 'Aventuriers / an', 'icon' => '🧗'],
            ['value' => '98%',  'label' => 'Satisfaits',       'icon' => '⭐'],
        ]);

        $visionMetrics = $this->get_json_option('nl_about_vision_metrics', [
            ['icon' => '🌍', 'title' => '15 parcs', 'sub' => 'objectif 2027'],
            ['icon' => '🧗', 'title' => '150k+',    'sub' => 'aventuriers / an'],
            ['icon' => '🌿', 'title' => '100%',     'sub' => 'écoresponsable'],
            ['icon' => '💼', 'title' => '500+',     'sub' => 'emplois créés'],
        ]);

        return rest_ensure_response([
            'hero' => [
                'badge'    => $this->opt('nl_hist_hero_badge',    '🏔️ Notre Histoire'),
                'h1'       => $this->opt('nl_hist_hero_h1',       '10 ans'),
                'h1accent' => $this->opt('nl_hist_hero_h1accent', "d'aventure."),
                'intro'    => $this->opt('nl_hist_hero_intro',    "De trois amis et une idée folle à un réseau de parcs."),
            ],
            'sections' => [
                'timelineTitle'    => $this->opt('nl_hist_timeline_title',    'Notre timeline'),
                'timelineSubtitle' => $this->opt('nl_hist_timeline_subtitle', 'Une étape à la fois.'),
                'visionBadge'      => $this->opt('nl_hist_vision_badge',      'Notre vision 2027'),
                'visionTitle'      => $this->opt('nl_hist_vision_title',      'Leader national du parc aventure.'),
                'visionSubtitle'   => $this->opt('nl_hist_vision_subtitle',   "Créer le réseau de parcs le plus qualitatif de France."),
                'visionCtaText'    => $this->opt('nl_hist_vision_cta_text',   'Voir nos parcs'),
                'visionCtaLink'    => $this->opt('nl_hist_vision_cta_link',   '/about/parcs'),
            ],
            'title'         => $this->opt('nl_about_history_title',    'Notre Histoire'),
            'subtitle'      => $this->opt('nl_about_history_subtitle', 'Une étape à la fois.'),
            'timeline'      => $timeline,
            'stats'         => $stats,
            'vision'        => $this->opt('nl_about_vision', "Devenir le leader français des parcs aventure nature d'ici 2027."),
            'visionMetrics' => $visionMetrics,
        ]);
    }

    public function api_values() {
        $values = $this->get_json_option('nl_about_values', [
            ['icon' => 'Shield',    'emoji' => '🛡️', 'title' => 'Sécurité avant tout',   'desc' => "Normes EN 15567, double ligne de vie.", 'details' => ['Certification CE/EN', 'Contrôle quotidien', 'Moniteurs diplômés'], 'color' => '#3b82f6', 'bg' => '#eff6ff', 'num' => '01'],
            ['icon' => 'Leaf',      'emoji' => '🌿', 'title' => 'Respect de la nature',  'desc' => "Zéro béton, 3 arbres replantés pour 1 touché.", 'details' => ['Partenaire ONF', 'Zéro produit chimique', 'Matériaux biosourcés'], 'color' => '#357600', 'bg' => '#f0fdf4', 'num' => '02'],
            ['icon' => 'Heart',     'emoji' => '❤️', 'title' => 'Plaisir partagé',       'desc' => "Activités de 3 à 99 ans.", 'details' => ['Multi-niveaux', 'Espaces familles', 'Photos offertes'], 'color' => '#ec4899', 'bg' => '#fdf2f8', 'num' => '03'],
            ['icon' => 'Award',     'emoji' => '⭐', 'title' => 'Excellence du service', 'desc' => "98% de satisfaction.", 'details' => ['NPS > 70', 'Réponse sous 24h', 'Formation continue'], 'color' => '#f59e0b', 'bg' => '#fffbeb', 'num' => '04'],
            ['icon' => 'Lightbulb', 'emoji' => '💡', 'title' => 'Innovation continue',   'desc' => "Nouveautés chaque saison.", 'details' => ['1 nouveauté / saison', 'R&D interne', 'Veille'], 'color' => '#8b5cf6', 'bg' => '#f5f3ff', 'num' => '05'],
        ]);

        $manifesto = $this->get_json_option('nl_about_manifesto', [
            "L'aventure n'est pas réservée aux experts.",
            "La nature mérite mieux que d'être un décor.",
            "Chaque défi relevé transforme celui qui l'affronte.",
        ]);

        return rest_ensure_response([
            'hero' => [
                'badge'    => $this->opt('nl_val_hero_badge',    '💚 Notre ADN'),
                'h1'       => $this->opt('nl_val_hero_h1',       'Ce qui nous'),
                'h1accent' => $this->opt('nl_val_hero_h1accent', 'définit.'),
                'intro'    => $this->opt('nl_val_hero_intro',    "5 valeurs. Des engagements concrets."),
            ],
            'sections' => [
                'valuesTitle'     => $this->opt('nl_val_values_title',      'Nos valeurs en détail'),
                'manifestoTitle'  => $this->opt('nl_val_manifesto_title',   "Ce qu'on croit."),
                'manifestoSubtitle' => $this->opt('nl_val_manifesto_subtitle', "Des convictions qu'on ne négocie pas."),
            ],
            'title'     => $this->opt('nl_about_values_title',    'Notre ADN'),
            'subtitle'  => $this->opt('nl_about_values_subtitle', '5 valeurs qui guident nos décisions.'),
            'values'    => $values,
            'manifesto' => $manifesto,
        ]);
    }

    public function api_jobs() {
        $perks = $this->get_json_option('nl_about_perks', [
            ['icon' => '🌲', 'title' => 'Bureau en forêt',   'desc' => "Ton poste de travail, c'est la nature."],
            ['icon' => '🎯', 'title' => 'Formation complète', 'desc' => "On te forme de A à Z."],
            ['icon' => '🚀', 'title' => 'Évolution rapide',   'desc' => "Moniteur → Responsable en 2 saisons."],
            ['icon' => '🤝', 'title' => 'Ambiance famille',   'desc' => "Une team soudée."],
            ['icon' => '💰', 'title' => 'Salaire juste',      'desc' => "Grille transparente + primes."],
            ['icon' => '🌍', 'title' => 'Mobilité réseau',    'desc' => "Évolue partout en France."],
        ]);

        $positions = $this->get_json_option('nl_about_positions', [
            ['title' => 'Moniteur Accrobranche', 'location' => 'Chevry (91)',    'type' => 'Saisonnier', 'level' => 'Débutant', 'urgent' => true,  'color' => '#357600', 'desc' => "Encadrement des visiteurs."],
            ['title' => 'Responsable de Parc',   'location' => 'Nemours (77)',   'type' => 'CDI',        'level' => '2 ans exp.', 'urgent' => false, 'color' => '#eb700f', 'desc' => "Gestion opérationnelle."],
        ]);

        return rest_ensure_response([
            'hero' => [
                'badge'    => $this->opt('nl_jobs_hero_badge',    '🧗 Nos Emplois'),
                'h1'       => $this->opt('nl_jobs_hero_h1',       'Ta passion,'),
                'h1accent' => $this->opt('nl_jobs_hero_h1accent', 'ton métier.'),
                'intro'    => $this->opt('nl_jobs_hero_intro',    "On cherche des passionnés."),
            ],
            'sections' => [
                'perksTitle'         => $this->opt('nl_jobs_perks_title',    'Pourquoi nous rejoindre ?'),
                'perksSubtitle'      => $this->opt('nl_jobs_perks_subtitle', 'Des raisons concrètes.'),
                'positionsTitle'     => $this->opt('nl_jobs_positions_title', 'Postes à pourvoir'),
                'spontaneousTitle'   => $this->opt('nl_jobs_spont_title',    "Pas votre poste ici ? Écrivez-nous."),
                'spontaneousSubtitle'=> $this->opt('nl_jobs_spont_subtitle', "On étudie toutes les candidatures."),
                'ctaButton'          => $this->opt('nl_jobs_cta_button',     'Envoyer ma candidature'),
                'confirmedTitle'     => $this->opt('nl_jobs_confirmed_title', 'Candidature reçue !'),
                'confirmedText'      => $this->opt('nl_jobs_confirmed_text', 'On revient vers vous sous 5 jours.'),
            ],
            'title'       => $this->opt('nl_about_jobs_title',    'Rejoignez NoLimit'),
            'subtitle'    => $this->opt('nl_about_jobs_subtitle', "L'aventure, c'est aussi un métier."),
            'perks'       => $perks,
            'positions'   => $positions,
            'spontaneous' => [
                'enabled' => (bool) $this->opt('nl_about_jobs_spontaneous', 1),
                'email'   => $this->opt('nl_about_jobs_email',             'jobs@nolimit-aventure.fr'),
                'text'    => $this->opt('nl_about_jobs_spontaneous_text',  "Candidatures spontanées bienvenues."),
            ],
        ]);
    }

    public function api_partners() {
        $partners = $this->get_json_option('nl_about_partners', [
            ['name' => 'ONF',       'full' => 'Office National des Forêts',           'emoji' => '🌲', 'type' => 'Institutionnel', 'desc' => 'Gestion durable.'],
            ['name' => 'UNAT',      'full' => 'Union Nat. des Ass. de Tourisme',       'emoji' => '🏕️', 'type' => 'Associatif',     'desc' => 'Label tourisme responsable.'],
            ['name' => 'La Ligue',  'full' => "Ligue de l'Enseignement",               'emoji' => '🎓', 'type' => 'Éducatif',       'desc' => 'Sorties scolaires.'],
        ]);

        $rse = $this->get_json_option('nl_about_rse', [
            ['icon' => '🌳', 'title' => 'Zéro artificialisation nette', 'desc' => '3 arbres plantés pour 1 touché.'],
            ['icon' => '♻️', 'title' => 'Matériaux biosourcés',         'desc' => 'Bois local, cordages recyclés.'],
            ['icon' => '🚗', 'title' => 'Mobilité douce',               'desc' => 'Navettes, parking vélos.'],
        ]);

        return rest_ensure_response([
            'hero' => [
                'badge'    => $this->opt('nl_part_hero_badge',    '🤝 Nos Partenaires'),
                'h1'       => $this->opt('nl_part_hero_h1',       'Ensemble,'),
                'h1accent' => $this->opt('nl_part_hero_h1accent', 'on va plus loin.'),
                'intro'    => $this->opt('nl_part_hero_intro',    "On ne croit pas au succès solitaire."),
            ],
            'sections' => [
                'partnersTitle'    => $this->opt('nl_part_section_title',     'Ils nous font confiance'),
                'partnersSubtitle' => $this->opt('nl_part_section_subtitle',  'Des partenaires stratégiques.'),
                'becomeTitle'      => $this->opt('nl_part_become_title',      'Devenir partenaire.'),
                'becomeSubtitle'   => $this->opt('nl_part_become_subtitle',   "Ouverts à tous types de partenariats."),
                'becomeCta'        => $this->opt('nl_part_become_cta',        'Envoyer ma demande'),
                'confirmedTitle'   => $this->opt('nl_part_confirmed_title',   'Demande reçue !'),
                'confirmedText'    => $this->opt('nl_part_confirmed_text',    'Notre responsable vous contactera sous 48h.'),
            ],
            'title'       => $this->opt('nl_about_partners_title',    'Nos Partenaires'),
            'subtitle'    => $this->opt('nl_about_partners_subtitle', 'Des valeurs communes.'),
            'partners'    => $partners,
            'rseTitle'    => $this->opt('nl_about_rse_title',    'Nos Engagements RSE'),
            'rseSubtitle' => $this->opt('nl_about_rse_subtitle', 'Des mesures concrètes.'),
            'rse'         => $rse,
        ]);
    }

    private function get_json_option(string $key, array $default): array {
        $raw = get_option($key, '');
        if ($raw && is_string($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && !empty($decoded)) return $decoded;
        }
        if (is_array($raw) && !empty($raw)) return $raw;
        return $default;
    }
}