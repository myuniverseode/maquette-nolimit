<?php
/**
 * Module : Home
 *
 * Routes : GET /nolimit/v1/home
 *          GET /nolimit/v1/home-config
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Module_Home extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'home' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_home'],
            ],
            'home-config' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_home_config'],
            ],
        ];
    }

    public function api_home(): WP_REST_Response {
        $hero_image_id = $this->opt('nl_home_hero_image_id', 0);
        $benefits = array_filter(explode("\n", $this->opt('nl_home_groups_benefits', '')));

        $data = [
            'hero' => [
                'title'           => $this->opt('nl_home_hero_title', "L'aventure commence ici"),
                'subtitle'        => $this->opt('nl_home_hero_subtitle', 'Accrobranche, Paintball & Sensations fortes'),
                'description'     => $this->opt('nl_home_hero_desc', "5 parcs multi-activités en France..."),
                'ctaText'         => $this->opt('nl_home_hero_cta', "Réserver maintenant"),
                'ctaUrl'          => '/booking',
                'backgroundVideo' => $this->opt('nl_home_hero_video', ''),
                'backgroundImage' => $hero_image_id ? wp_get_attachment_url($hero_image_id) : '',
            ],
            'features' => [
                ['icon' => 'shield', 'title' => 'Sécurité maximale', 'description' => "Équipement aux normes et encadrement professionnel"],
                ['icon' => 'users', 'title' => 'Pour tous', 'description' => "Activités adaptées de 3 à 99 ans"],
                ['icon' => 'leaf', 'title' => 'Nature préservée', 'description' => "Dans le respect de l'environnement"],
            ],
            'parksSection' => [
                'title'    => $this->opt('nl_home_parcs_title', 'Nos 5 parcs en France'),
                'subtitle' => $this->opt('nl_home_parcs_subtitle', "Choisissez votre destination..."),
            ],
            'ctaSection' => [
                'title'    => $this->opt('nl_home_cta_title', "Prêt pour l'aventure ?"),
                'subtitle' => $this->opt('nl_home_cta_subtitle', "Réservez dès maintenant..."),
            ],
            'reviewsSection' => [
                'title'    => $this->opt('nl_home_reviews_title', 'Ils nous font confiance'),
                'subtitle' => $this->opt('nl_home_reviews_subtitle', "Découvrez les avis de nos visiteurs"),
            ],
            'groupsSection' => [
                'title'       => $this->opt('nl_home_groups_title', "Groupes & Événements"),
                'description' => $this->opt('nl_home_groups_desc', "Anniversaires, team building..."),
                'benefits'    => array_map('trim', $benefits),
            ],
        ];

        return rest_ensure_response($data);
    }

    public function api_home_config(): WP_REST_Response {
        $data = [
            'hero' => [
                'enabled'         => true,
                'title'           => $this->opt('nl_home_hero_title', "L'aventure commence ici"),
                'subtitle'        => $this->opt('nl_home_hero_subtitle', 'Accrobranche, Paintball & Sensations fortes'),
                'description'     => $this->opt('nl_home_hero_desc', "5 parcs multi-activités en France pour vivre des expériences uniques en pleine nature"),
                'ctaText'         => $this->opt('nl_home_hero_cta', "Réserver maintenant"),
                'ctaUrl'          => '/booking',
                'backgroundVideo' => $this->opt('nl_home_hero_video', ''),
                'backgroundImage' => $this->opt('nl_home_hero_image_id', 0) ? wp_get_attachment_url($this->opt('nl_home_hero_image_id', 0)) : '',
            ],
            'parcs' => [
                'enabled'  => (bool) $this->opt('nl_home_enable_parcs', 1),
                'title'    => $this->opt('nl_home_parcs_title', 'Nos 5 parcs en France'),
                'subtitle' => $this->opt('nl_home_parcs_subtitle', "Choisissez votre destination et vivez une aventure inoubliable"),
                'maxItems' => intval($this->opt('nl_home_parcs_max_items', 3)),
            ],
            'activities' => [
                'enabled'  => (bool) $this->opt('nl_home_enable_activities', 1),
                'title'    => $this->opt('nl_home_activities_title', "Quelle activité vous tente ?"),
                'subtitle' => $this->opt('nl_home_activities_subtitle', "Explorez nos activités et trouvez celle qui correspond à votre niveau d'aventure"),
                'maxItems' => intval($this->opt('nl_home_activities_max_items', 6)),
            ],
            'pourqui' => [
                'enabled'  => (bool) $this->opt('nl_home_enable_pourqui', 1),
                'title'    => $this->opt('nl_home_pourqui_title', "Pour qui ?"),
                'subtitle' => $this->opt('nl_home_pourqui_subtitle', "Des aventures adaptées à tous les publics"),
            ],
            'actualites' => [
                'enabled'  => (bool) $this->opt('nl_home_enable_actualites', 1),
                'title'    => $this->opt('nl_home_actualites_title', "Actualités & Événements"),
                'subtitle' => $this->opt('nl_home_actualites_subtitle', "Restez informés de nos nouveautés et événements"),
                'maxItems' => intval($this->opt('nl_home_actualites_max_items', 3)),
            ],
            'newsletter' => [
                'enabled'  => (bool) $this->opt('nl_home_enable_newsletter', 1),
                'title'    => $this->opt('nl_home_newsletter_title', "Restez connecté"),
                'subtitle' => $this->opt('nl_home_newsletter_subtitle', "Recevez nos offres exclusives et actualités"),
            ],
            'reviews' => [
                'enabled'  => (bool) $this->opt('nl_home_enable_reviews', 1),
                'title'    => $this->opt('nl_home_reviews_title', 'Ils nous font confiance'),
                'subtitle' => $this->opt('nl_home_reviews_subtitle', "Découvrez les avis de nos visiteurs"),
            ],
            'groups' => [
                'enabled'     => (bool) $this->opt('nl_home_enable_groups', 1),
                'title'       => $this->opt('nl_home_groups_title', "Groupes & Événements"),
                'description' => $this->opt('nl_home_groups_desc', "Anniversaires, team building, séminaires... Nous organisons votre événement sur mesure dans nos parcs."),
                'benefits'    => array_map('trim', explode("\n", $this->opt('nl_home_groups_benefits', ''))),
            ],
            'cta' => [
                'title'    => $this->opt('nl_home_cta_title', "Prêt pour l'aventure ?"),
                'subtitle' => $this->opt('nl_home_cta_subtitle', "Réservez dès maintenant et vivez une expérience inoubliable"),
            ],
        ];

        return rest_ensure_response($data);
    }

    public function create_defaults(): void {
        if (get_option('nl_home_hero_title')) return;

        $defaults = [
            'nl_home_hero_title' => "L'aventure commence ici",
            'nl_home_hero_subtitle' => 'Accrobranche, Paintball & Sensations fortes',
            'nl_home_hero_desc' => "5 parcs multi-activités en France pour vivre des expériences uniques en pleine nature",
            'nl_home_hero_cta' => "Réserver maintenant",
            'nl_home_enable_parcs' => 1,
            'nl_home_parcs_title' => 'Nos 5 parcs en France',
            'nl_home_parcs_subtitle' => "Choisissez votre destination et vivez une aventure inoubliable",
            'nl_home_parcs_max_items' => 3,
            'nl_home_enable_activities' => 1,
            'nl_home_activities_title' => "Quelle activité vous tente ?",
            'nl_home_activities_subtitle' => "Explorez nos activités et trouvez celle qui correspond à votre niveau d'aventure",
            'nl_home_activities_max_items' => 6,
            'nl_home_enable_pourqui' => 1,
            'nl_home_pourqui_title' => "Pour qui ?",
            'nl_home_pourqui_subtitle' => "Des aventures adaptées à tous les publics",
            'nl_home_enable_actualites' => 1,
            'nl_home_actualites_title' => "Actualités & Événements",
            'nl_home_actualites_subtitle' => "Restez informés de nos nouveautés et événements",
            'nl_home_actualites_max_items' => 3,
            'nl_home_enable_newsletter' => 1,
            'nl_home_newsletter_title' => "Restez connecté",
            'nl_home_newsletter_subtitle' => "Recevez nos offres exclusives et actualités",
            'nl_home_enable_reviews' => 1,
            'nl_home_reviews_title' => 'Ils nous font confiance',
            'nl_home_reviews_subtitle' => "Découvrez les avis de nos visiteurs",
            'nl_home_enable_groups' => 1,
            'nl_home_groups_title' => "Groupes & Événements",
            'nl_home_groups_desc' => "Anniversaires, team building, séminaires... Nous organisons votre événement sur mesure dans nos parcs.",
            'nl_home_groups_benefits' => "Devis gratuit en 24h\nCoordinateur dédié\nEspaces privatifs\nTarifs préférentiels",
            'nl_home_cta_title' => "Prêt pour l'aventure ?",
            'nl_home_cta_subtitle' => "Réservez dès maintenant et vivez une expérience inoubliable",
        ];

        foreach ($defaults as $key => $value) {
            update_option($key, $value);
        }
    }
}
