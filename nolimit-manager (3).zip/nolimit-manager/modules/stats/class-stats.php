<?php
/**
 * Module : Stats & Features
 *
 * Gère les statistiques affichées sur le hero et les features de la homepage.
 * Route : GET /nolimit/v1/stats
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Stats extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'stats' => [
                'methods'  => 'GET',
                'callback' => [$this, 'api_stats'],
            ],
        ];
    }

    public function api_stats(): WP_REST_Response {
        // Stats grid (hero)
        $stats = [];
        for ($i = 1; $i <= 4; $i++) {
            $value = $this->opt("nl_stat_{$i}_value", '');
            $label = $this->opt("nl_stat_{$i}_label", '');
            if ($value || $label) {
                $stats[] = [
                    'value'      => $value,
                    'label'      => $label,
                    'sublabel'   => $this->opt("nl_stat_{$i}_sublabel", ''),
                    'icon'       => $this->opt("nl_stat_{$i}_icon", 'Star'),
                    'trendValue' => $this->opt("nl_stat_{$i}_trend", ''),
                    'color'      => $this->opt("nl_stat_{$i}_color", 'green'),
                ];
            }
        }

        // Fallback
        if (empty($stats)) {
            $stats = [
                ['value' => '5',   'label' => 'Parcs',        'sublabel' => 'en France',  'icon' => 'MapPin', 'trendValue' => '+1 cette année',      'color' => 'green'],
                ['value' => '98%', 'label' => 'Satisfaction',  'sublabel' => 'clients',    'icon' => 'Star',   'trendValue' => '4.8/5 avis',          'color' => 'orange'],
                ['value' => '50k+','label' => 'Aventuriers',   'sublabel' => 'par an',     'icon' => 'Users',  'trendValue' => '+15% vs 2023',        'color' => 'blue'],
                ['value' => '20+', 'label' => 'Activités',     'sublabel' => 'uniques',    'icon' => 'Award',  'trendValue' => 'Nouveautés régulières','color' => 'purple'],
            ];
        }

        // Features (shield/users/leaf section)
        $features = [];
        for ($i = 1; $i <= 3; $i++) {
            $title = $this->opt("nl_feature_{$i}_title", '');
            if ($title) {
                $features[] = [
                    'icon'        => $this->opt("nl_feature_{$i}_icon", 'shield'),
                    'title'       => $title,
                    'description' => $this->opt("nl_feature_{$i}_desc", ''),
                ];
            }
        }

        if (empty($features)) {
            $features = [
                ['icon' => 'shield', 'title' => 'Sécurité maximale',  'description' => 'Équipement aux normes et encadrement professionnel'],
                ['icon' => 'users',  'title' => 'Pour tous',          'description' => 'Activités adaptées de 3 à 99 ans'],
                ['icon' => 'leaf',   'title' => 'Nature préservée',   'description' => "Dans le respect de l'environnement"],
            ];
        }

        $data = [
            'stats'    => $stats,
            'features' => $features,
        ];

        return rest_ensure_response($data);
    }

    public function create_defaults(): void {
        if (get_option('nl_stat_1_value')) return;

        $defaults = [
            'nl_stat_1_value'    => '5',
            'nl_stat_1_label'    => 'Parcs',
            'nl_stat_1_sublabel' => 'en France',
            'nl_stat_1_icon'     => 'MapPin',
            'nl_stat_1_trend'    => '+1 cette année',
            'nl_stat_1_color'    => 'green',
            'nl_stat_2_value'    => '98%',
            'nl_stat_2_label'    => 'Satisfaction',
            'nl_stat_2_sublabel' => 'clients',
            'nl_stat_2_icon'     => 'Star',
            'nl_stat_2_trend'    => '4.8/5 avis',
            'nl_stat_2_color'    => 'orange',
            'nl_stat_3_value'    => '50k+',
            'nl_stat_3_label'    => 'Aventuriers',
            'nl_stat_3_sublabel' => 'par an',
            'nl_stat_3_icon'     => 'Users',
            'nl_stat_3_trend'    => '+15% vs 2023',
            'nl_stat_3_color'    => 'blue',
            'nl_stat_4_value'    => '20+',
            'nl_stat_4_label'    => 'Activités',
            'nl_stat_4_sublabel' => 'uniques',
            'nl_stat_4_icon'     => 'Award',
            'nl_stat_4_trend'    => 'Nouveautés régulières',
            'nl_stat_4_color'    => 'purple',
            'nl_feature_1_icon'  => 'shield',
            'nl_feature_1_title' => 'Sécurité maximale',
            'nl_feature_1_desc'  => 'Équipement aux normes et encadrement professionnel',
            'nl_feature_2_icon'  => 'users',
            'nl_feature_2_title' => 'Pour tous',
            'nl_feature_2_desc'  => 'Activités adaptées de 3 à 99 ans',
            'nl_feature_3_icon'  => 'leaf',
            'nl_feature_3_title' => 'Nature préservée',
            'nl_feature_3_desc'  => "Dans le respect de l'environnement",
        ];

        foreach ($defaults as $key => $value) {
            update_option($key, $value);
        }
    }
}
