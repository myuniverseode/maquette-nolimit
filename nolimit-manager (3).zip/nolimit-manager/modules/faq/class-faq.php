<?php
/**
 * Module : FAQ
 * CPT : nolimit_faq | Route : GET /faqs
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_FAQ extends NoLimit_Module {
    public function register_post_types(): void {
        register_post_type('nolimit_faq', ['labels' => ['name' => 'FAQ', 'singular_name' => 'Question', 'add_new' => 'Ajouter', 'all_items' => 'FAQ'], 'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'supports' => ['title', 'editor', 'page-attributes']]);
    }

    public function register_taxonomies(): void {
        register_taxonomy('nolimit_faq_category', 'nolimit_faq', ['labels' => ['name' => 'Catégories FAQ', 'singular_name' => 'Catégorie'], 'hierarchical' => true, 'show_ui' => true, 'show_admin_column' => true]);
    }

    public function register_acf_fields(): void {
        acf_add_local_field_group(['key' => 'group_faq', 'title' => 'FAQ', 'fields' => [
            ['key' => 'field_faq_park', 'label' => 'Parc associé (vide = global)', 'name' => 'faq_park', 'type' => 'post_object', 'post_type' => ['nolimit_parc'], 'allow_null' => 1, 'return_format' => 'id'],
            ['key' => 'field_faq_category', 'label' => 'Catégorie', 'name' => 'faq_category', 'type' => 'select', 'choices' => ['general' => 'Général', 'booking' => 'Réservation', 'activities' => 'Activités', 'safety' => 'Sécurité', 'practical' => 'Pratique']],
        ], 'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'nolimit_faq']]]]);
    }

    public function get_api_routes(): array {
        return [
            'faqs' => ['methods' => 'GET', 'callback' => [$this, 'api_list']],
            'faqs/park/(?P<park>[a-zA-Z0-9-]+)' => ['methods' => 'GET', 'callback' => [$this, 'api_park_faqs']],
        ];
    }

    public function api_list($request = null) {
        $park_filter = $request ? $request->get_param('park') : null;
        // Catégories éditables depuis WP
        $cat_labels_raw = $this->opt('nl_faq_categories', '');
        if ($cat_labels_raw) {
            $lines = array_filter(array_map('trim', explode("\n", $cat_labels_raw)));
            $categories = [['id' => 'all', 'label' => 'Toutes']];
            foreach ($lines as $line) {
                $parts = array_map('trim', explode('|', $line));
                if (count($parts) >= 2) {
                    $categories[] = ['id' => $parts[0], 'label' => $parts[1]];
                }
            }
        } else {
            $categories = [
                ['id' => 'all', 'label' => 'Toutes'],
                ['id' => 'general', 'label' => 'Général'],
                ['id' => 'booking', 'label' => 'Réservation'],
                ['id' => 'activities', 'label' => 'Activités'],
                ['id' => 'safety', 'label' => 'Sécurité'],
                ['id' => 'practical', 'label' => 'Pratique'],
            ];
        }

        $faqs = [];
        foreach ($this->query('nolimit_faq') as $post) {
            $faq_park_id = $this->acf('faq_park', $post->ID);
            $faq_park_slug = null;
            if ($faq_park_id) {
                $faq_park_slug = $this->acf('parc_slug', $faq_park_id) ?: sanitize_title(get_the_title($faq_park_id));
            }
            // Filtrage : si ?park=slug, ne retourner que les FAQ de ce parc + les globales
            if ($park_filter && $faq_park_slug && $faq_park_slug !== $park_filter) continue;
            $faqs[] = [
                'id' => $post->ID,
                'question' => $post->post_title,
                'answer' => $post->post_content,
                'category' => $this->acf('faq_category', $post->ID, 'general'),
                'parkId' => $faq_park_slug,
            ];
        }

        return rest_ensure_response([
            'title'      => $this->opt('nl_faq_title', 'Foire Aux Questions'),
            'subtitle'   => $this->opt('nl_faq_subtitle', 'Retrouvez les réponses aux questions les plus fréquentes'),
            'categories' => $categories,
            'faqs'       => $faqs,
        ]);
    }

    public function api_park_faqs($request) {
        $request->set_param('park', $request->get_param('park'));
        return $this->api_list($request);
    }

    public function create_defaults(): void {
        if (get_posts(['post_type' => 'nolimit_faq', 'posts_per_page' => 1])) return;
        $faqs = [
            ['q' => "À partir de quel âge peut-on faire de l'accrobranche ?", 'a' => 'Nos parcours sont accessibles dès 3 ans avec des parcours adaptés.', 'cat' => 'activities'],
            ['q' => 'Les activités sont-elles sécurisées ?', 'a' => "Toutes nos activités respectent les normes de sécurité les plus strictes.", 'cat' => 'safety'],
            ['q' => 'Comment réserver ?', 'a' => 'Vous pouvez réserver en ligne sur notre site ou par téléphone.', 'cat' => 'booking'],
            ['q' => 'Que se passe-t-il en cas de mauvais temps ?', 'a' => 'En cas de conditions météo dangereuses, nous vous proposons un report gratuit.', 'cat' => 'general'],
            ['q' => 'Puis-je venir avec mon chien ?', 'a' => "Les animaux ne sont pas autorisés sur les parcours pour des raisons de sécurité.", 'cat' => 'general'],
        ];
        foreach ($faqs as $i => $faq) {
            $id = wp_insert_post(['post_title' => $faq['q'], 'post_content' => $faq['a'], 'post_type' => 'nolimit_faq', 'post_status' => 'publish', 'menu_order' => $i]);
            if ($id) update_field('faq_category', $faq['cat'], $id);
        }
        update_option('nl_faq_title', 'Foire Aux Questions');
        update_option('nl_faq_subtitle', 'Retrouvez les réponses aux questions les plus fréquentes');
    }
}
