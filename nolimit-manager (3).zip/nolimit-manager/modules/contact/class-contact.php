<?php
/**
 * Module : Contact
 * Routes : GET /contact (config), POST /contact (submit)
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Module_Contact extends NoLimit_Module {

    public function get_api_routes(): array {
        return [
            'contact' => [
                [
                    'methods'  => 'GET',
                    'callback' => [$this, 'api_config'],
                ],
                [
                    'methods'  => 'POST',
                    'callback' => [$this, 'api_contact'],
                ],
            ],
        ];
    }

    public function api_config(): WP_REST_Response {
        $data = [
            'title'    => $this->opt('nl_contact_title', 'Contactez-nous'),
            'subtitle' => $this->opt('nl_contact_subtitle', "Une question ? N'hésitez pas à nous écrire"),
            'phone'    => $this->opt('nl_f_phone', '01 23 45 67 89'),
            'email'    => $this->opt('nl_f_email', 'contact@nolimit-aventure.fr'),
            'address'  => $this->opt('nl_contact_address', ''),
            'mapUrl'   => $this->opt('nl_contact_map_url', ''),
            'openingHours' => $this->opt('nl_contact_hours', 'Du lundi au dimanche, 9h-19h (haute saison)'),
            'subjects' => array_filter(array_map('trim', explode("\n", $this->opt('nl_contact_subjects', "Information générale\nRéservation\nGroupe / Événement\nRéclamation\nPartenariat\nAutre")))),
        ];

        return rest_ensure_response($data);
    }

    public function api_contact($request) {
        $data = $request->get_json_params();

        $to = $this->opt('nl_f_email', get_option('admin_email'));
        $subject = 'Contact NoLimit: ' . sanitize_text_field($data['subject'] ?? 'Sans sujet');
        $message = "Nom: " . sanitize_text_field($data['name'] ?? '') . "\n";
        $message .= "Email: " . sanitize_email($data['email'] ?? '') . "\n";
        $message .= "Téléphone: " . sanitize_text_field($data['phone'] ?? '') . "\n";
        if (!empty($data['park'])) {
            $message .= "Parc: " . sanitize_text_field($data['park']) . "\n";
        }
        $message .= "\nMessage:\n" . sanitize_textarea_field($data['message'] ?? '');

        $sent = wp_mail($to, $subject, $message);

        if ($sent) {
            return rest_ensure_response(['success' => true, 'message' => $this->opt('nl_contact_success_msg', 'Message envoyé avec succès !')]);
        }
        return new WP_Error('mail_error', "Erreur d'envoi", ['status' => 500]);
    }

    public function create_defaults(): void {
        if (get_option('nl_contact_title')) return;
        $defaults = [
            'nl_contact_title'       => 'Contactez-nous',
            'nl_contact_subtitle'    => "Une question ? N'hésitez pas à nous écrire",
            'nl_contact_address'     => '',
            'nl_contact_hours'       => 'Du lundi au dimanche, 9h-19h (haute saison)',
            'nl_contact_subjects'    => "Information générale\nRéservation\nGroupe / Événement\nRéclamation\nPartenariat\nAutre",
            'nl_contact_success_msg' => 'Message envoyé avec succès !',
        ];
        foreach ($defaults as $key => $value) update_option($key, $value);
    }
}
