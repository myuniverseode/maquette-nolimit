/**
 * NoLimit Manager — Shared Admin JavaScript
 * Tabs, Repeaters, Media Pickers
 */
jQuery(document).ready(function($) {

    // ─── Tabs ───────────────────────────────
    $(document).on('click', '.nl-tabs .nl-tab', function(e) {
        e.preventDefault();
        var wrapper = $(this).closest('.nolimit-admin, .wrap');
        wrapper.find('.nl-tab').removeClass('active');
        $(this).addClass('active');
        wrapper.find('.nl-tab-pane').removeClass('active');
        $($(this).attr('href')).addClass('active');
    });

    // ─── Media picker (universal) ───────────
    $(document).on('click', '.nl-media-btn, [onclick*="selectImage"]', function(e) {
        e.preventDefault();
        var target = $(this).data('target') || $(this).attr('onclick')?.match(/'([^']+)'/)?.[1];
        if (!target) return;
        var frame = wp.media({ title: 'Choisir une image', multiple: false, library: { type: 'image' }});
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            $('#' + target).val(attachment.id);
            // Update preview if exists
            var preview = $('#' + target).siblings('img, .nl-img-preview');
            if (preview.length) {
                preview.attr('src', attachment.url).show();
            }
        });
        frame.open();
    });

    // ─── Remove repeater row ────────────────
    $(document).on('click', '.nl-remove-row', function() {
        if (confirm('Supprimer cette ligne ?')) {
            $(this).closest('.nl-repeater-row').slideUp(200, function() { $(this).remove(); });
        }
    });

    // ─── Add repeater row (structured) ──────
    $(document).on('click', '.nl-add-row', function() {
        var target = $(this).data('target');
        var fieldsStr = $(this).attr('data-fields');
        if (!fieldsStr) return;

        var fields;
        try { fields = JSON.parse(fieldsStr); } catch(e) { return; }

        var container = $('.nl-repeater[data-name="' + target + '"]');
        var idx = container.find('.nl-repeater-row').length;

        var html = '<div class="nl-repeater-row" style="display:none"><span class="nl-drag">☰</span>';
        fields.forEach(function(f) {
            var parts = f.split('|');
            var key = parts[0];
            var placeholder = parts[1] || '';
            var sizeInfo = (parts[2] || 'md').split(':');
            var sizeClass = 'nl-field-' + sizeInfo[0];
            var inputType = sizeInfo[1] || 'text';

            if (inputType === 'select') {
                // For select fields, placeholder contains options as "opt1,opt2,opt3"
                var options = placeholder.split(',');
                html += '<select name="' + target + '[' + idx + '][' + key + ']" class="' + sizeClass + '">';
                options.forEach(function(o) { html += '<option value="' + o.trim() + '">' + o.trim() + '</option>'; });
                html += '</select>';
            } else {
                html += '<input type="' + inputType + '" name="' + target + '[' + idx + '][' + key + ']" placeholder="' + placeholder + '" class="' + sizeClass + '">';
            }
        });
        html += '<button type="button" class="button nl-remove-row">✕</button></div>';

        container.append(html);
        container.find('.nl-repeater-row:last').slideDown(200);
    });

    // ─── Add repeater row (simple: single value) ──
    $(document).on('click', '.nl-add-row-simple', function() {
        var target = $(this).data('target');
        var placeholder = $(this).data('placeholder') || '';
        var container = $('.nl-repeater-simple[data-name="' + target + '"], .nl-repeater[data-name="' + target + '"]');
        var idx = container.find('.nl-repeater-row').length;

        var html = '<div class="nl-repeater-row" style="display:none"><span class="nl-drag">☰</span>';
        html += '<input type="text" name="' + target + '[' + idx + ']" placeholder="' + placeholder + '" class="nl-field-lg">';
        html += '<button type="button" class="button nl-remove-row">✕</button></div>';

        container.append(html);
        container.find('.nl-repeater-row:last').slideDown(200);
    });

});
