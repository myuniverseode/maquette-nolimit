<?php if (!defined('ABSPATH')) exit;
$hero_title = get_option('nl_groups_hero_title', 'Groupes & Événements');
$hero_subtitle = get_option('nl_groups_hero_subtitle', 'Anniversaires, team building, séminaires...');
$benefits_title = get_option('nl_groups_benefits_title', 'Pourquoi nous choisir ?');
$benefits_desc = get_option('nl_groups_benefits_desc', 'Avec plus de 500 groupes accueillis...');
$benefits = get_option('nl_groups_benefits', "Devis gratuit en 24h\nCoordinateur dédié\nEspaces privatifs\nTarifs préférentiels");

$type_ids = ['corporate', 'kids', 'schools', 'cse'];
$type_labels = ['corporate' => '🏢 Entreprises', 'kids' => '🎂 Anniversaires', 'schools' => '🎓 Scolaires', 'cse' => '👥 CSE / CE'];
?>
<div class="wrap">
    <h1>👥 Configuration Page Groupes</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_groups', 'groups_nonce'); ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🦸 Section Hero</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="hero_title" value="<?php echo esc_attr($hero_title); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><textarea name="hero_subtitle" rows="2" class="large-text"><?php echo esc_textarea($hero_subtitle); ?></textarea></td></tr>
                <tr><th>Image Hero</th><td>
                    <input type="hidden" name="hero_image_id" id="hero_image_id" value="<?php echo esc_attr(get_option('nl_groups_hero_image_id', 0)); ?>">
                    <button type="button" class="button" onclick="selectImage('hero_image_id')">📁 Choisir</button>
                </td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>📦 Types de Groupes</h2>
            <?php foreach ($type_ids as $id):
                $img_id = get_option("nl_grp_type_{$id}_image_id", 0);
            ?>
            <div style="border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0;background:#fafafa;">
                <h3><?php echo $type_labels[$id]; ?></h3>
                <table class="form-table" style="margin:0;">
                    <tr><th>Titre</th><td><input type="text" name="grp_<?php echo $id; ?>_title" value="<?php echo esc_attr(get_option("nl_grp_type_{$id}_title", '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="grp_<?php echo $id; ?>_subtitle" value="<?php echo esc_attr(get_option("nl_grp_type_{$id}_subtitle", '')); ?>" class="large-text"></td></tr>
                    <tr><th>Icône</th><td><input type="text" name="grp_<?php echo $id; ?>_icon" value="<?php echo esc_attr(get_option("nl_grp_type_{$id}_icon", '')); ?>" class="regular-text" placeholder="building, gift, graduation, users"></td></tr>
                    <tr><th>Description</th><td><textarea name="grp_<?php echo $id; ?>_desc" rows="2" class="large-text"><?php echo esc_textarea(get_option("nl_grp_type_{$id}_desc", '')); ?></textarea></td></tr>
                    <tr><th>Lien</th><td><input type="text" name="grp_<?php echo $id; ?>_link" value="<?php echo esc_attr(get_option("nl_grp_type_{$id}_link", '')); ?>" class="regular-text"></td></tr>
                    <tr><th>Image</th><td>
                        <input type="hidden" name="grp_<?php echo $id; ?>_image_id" id="grp_<?php echo $id; ?>_image_id" value="<?php echo esc_attr($img_id); ?>">
                        <button type="button" class="button" onclick="selectImage('grp_<?php echo $id; ?>_image_id')">📁 Choisir</button>
                    </td></tr>
                </table>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>✅ Section Avantages</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="benefits_title" value="<?php echo esc_attr($benefits_title); ?>" class="large-text"></td></tr>
                <tr><th>Description</th><td><textarea name="benefits_desc" rows="2" class="large-text"><?php echo esc_textarea($benefits_desc); ?></textarea></td></tr>
                <tr><th>Avantages (1/ligne)</th><td><textarea name="benefits" rows="6" class="large-text"><?php echo esc_textarea($benefits); ?></textarea></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🚀 CTA</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="cta_title" value="<?php echo esc_attr(get_option('nl_groups_cta_title', 'Demandez votre devis')); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="cta_subtitle" value="<?php echo esc_attr(get_option('nl_groups_cta_subtitle', '')); ?>" class="large-text"></td></tr>
                <tr><th>Texte bouton</th><td><input type="text" name="cta_btn" value="<?php echo esc_attr(get_option('nl_groups_cta_btn', 'Demander un devis')); ?>" class="regular-text"></td></tr>
                <tr><th>URL bouton</th><td><input type="text" name="cta_url" value="<?php echo esc_attr(get_option('nl_groups_cta_url', '/contact')); ?>" class="regular-text"></td></tr>
            </table>
        </div>

        <p><button type="submit" name="save_groups_page" class="button button-primary">💾 Sauvegarder</button></p>
    </form>
</div>
<script>
function selectImage(fieldId) {
    var frame = wp.media({ title: 'Choisir une image', multiple: false, library: { type: 'image' }});
    frame.on('select', function() { document.getElementById(fieldId).value = frame.state().get('selection').first().toJSON().id; });
    frame.open();
}
</script>
