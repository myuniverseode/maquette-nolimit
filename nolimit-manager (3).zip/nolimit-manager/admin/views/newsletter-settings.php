<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap nolimit-admin">
    <h1>✉️ Newsletter</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_newsletter', 'newsletter_nonce'); ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>📝 Textes</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="nl_title" value="<?php echo esc_attr(get_option('nl_nl_title', 'Restez informé de nos aventures')); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><textarea name="nl_subtitle" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_nl_subtitle', '')); ?></textarea></td></tr>
                <tr><th>Placeholder email</th><td><input type="text" name="nl_placeholder" value="<?php echo esc_attr(get_option('nl_nl_placeholder', 'Votre adresse email')); ?>" class="regular-text"></td></tr>
                <tr><th>Texte bouton</th><td><input type="text" name="nl_button" value="<?php echo esc_attr(get_option('nl_nl_button', "S'inscrire")); ?>" class="regular-text"></td></tr>
                <tr><th>Mention légale</th><td><textarea name="nl_privacy" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_nl_privacy', '')); ?></textarea></td></tr>
                <tr><th>Message de succès</th><td><input type="text" name="nl_success" value="<?php echo esc_attr(get_option('nl_nl_success', '')); ?>" class="large-text"></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>✨ Avantages (3 max)</h2>
            <?php for ($i = 1; $i <= 3; $i++): ?>
            <div style="border:1px solid #ddd;border-radius:8px;padding:12px;margin:8px 0;background:#fafafa;display:grid;grid-template-columns:80px 1fr 1fr;gap:12px;">
                <div><label><strong>Emoji</strong><br><input type="text" name="benefit_<?php echo $i; ?>_icon" value="<?php echo esc_attr(get_option("nl_nl_benefit_{$i}_icon", '')); ?>" style="width:60px;font-size:20px;text-align:center;"></label></div>
                <div><label><strong>Titre</strong><br><input type="text" name="benefit_<?php echo $i; ?>_title" value="<?php echo esc_attr(get_option("nl_nl_benefit_{$i}_title", '')); ?>" class="large-text"></label></div>
                <div><label><strong>Description</strong><br><input type="text" name="benefit_<?php echo $i; ?>_desc" value="<?php echo esc_attr(get_option("nl_nl_benefit_{$i}_desc", '')); ?>" class="large-text"></label></div>
            </div>
            <?php endfor; ?>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🔧 Brevo (Sendinblue)</h2>
            <table class="form-table">
                <tr><th>Clé API Brevo</th><td><input type="password" name="nl_brevo_api_key" value="<?php echo esc_attr(get_option('nl_nl_brevo_api_key', '')); ?>" class="large-text" placeholder="xkeysib-..."></td></tr>
                <tr><th>ID Liste</th><td><input type="number" name="nl_brevo_list_id" value="<?php echo esc_attr(get_option('nl_nl_brevo_list_id', '')); ?>" class="regular-text" placeholder="Ex: 3"></td></tr>
            </table>
        </div>

        <p><button type="submit" name="save_newsletter" class="button button-primary button-large">💾 Sauvegarder</button></p>
    </form>
</div>
