<?php
/**
 * Vue admin : Horaires & Calendrier des parcs.
 *
 * Accessible via NoLimit → Horaires des parcs
 */

if (!defined('ABSPATH')) exit;

// ─── Récupération des slugs de parcs ────────────────────────
$park_posts = get_posts(['post_type' => 'nolimit_parc', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']);
$park_options = [];
foreach ($park_posts as $pp) {
    $slug = function_exists('get_field') ? (get_field('parc_slug', $pp->ID) ?: sanitize_title($pp->post_title)) : sanitize_title($pp->post_title);
    $park_options[$slug] = $pp->post_title;
}
if (empty($park_options)) {
    $park_options = [
        'nolimit-chevry'    => 'NoLimit Chevry',
        'nolimit-nemours'   => 'NoLimit Nemours',
        'nolimit-montargis' => 'NoLimit Montargis',
        'nolimit-digny'     => 'NoLimit Digny',
        'nolimit-coudray'   => 'NoLimit Coudray',
    ];
}

// ─── Parc sélectionné (onglet actif) ────────────────────────
$active_slug = sanitize_key($_GET['park'] ?? array_key_first($park_options));
if (!array_key_exists($active_slug, $park_options)) {
    $active_slug = array_key_first($park_options);
}
$p = 'nl_hor_' . $active_slug . '_';

// ─── Lecture valeurs actuelles ──────────────────────────────
$hs_start  = (int) get_option($p . 'hs_start',  3);
$hs_end    = (int) get_option($p . 'hs_end',    8);
$hs_open   = (int) get_option($p . 'hs_open',   9);
$hs_close  = (int) get_option($p . 'hs_close',  19);
$bs_open   = (int) get_option($p . 'bs_open',   10);
$bs_close  = (int) get_option($p . 'bs_close',  17);
$message   = get_option($p . 'message', '');

$closed_days   = json_decode(get_option($p . 'closed_days', '["monday"]'), true) ?: ['monday'];
$except_closed = json_decode(get_option($p . 'except_closed', '[]'), true) ?: [];
$except_open   = json_decode(get_option($p . 'except_open',   '[]'), true) ?: [];

// ─── Helpers ────────────────────────────────────────────────
$days_fr = [
    'monday'    => 'Lundi',
    'tuesday'   => 'Mardi',
    'wednesday' => 'Mercredi',
    'thursday'  => 'Jeudi',
    'friday'    => 'Vendredi',
    'saturday'  => 'Samedi',
    'sunday'    => 'Dimanche',
];
$months_fr = [
    0 => 'Janvier', 1 => 'Février', 2 => 'Mars', 3 => 'Avril',
    4 => 'Mai', 5 => 'Juin', 6 => 'Juillet', 7 => 'Août',
    8 => 'Septembre', 9 => 'Octobre', 10 => 'Novembre', 11 => 'Décembre',
];
$hours = range(6, 23);
?>

<div class="wrap nolimit-admin">
    <h1>🗓️ Horaires & Calendrier</h1>
    <p class="description" style="font-size:14px;margin-bottom:16px;">
        Configurez les jours et horaires d'ouverture pour chaque parc. Le site se met à jour automatiquement.
    </p>

    <?php if (isset($_GET['saved'])): ?>
        <div class="notice notice-success is-dismissible"><p>✅ Horaires sauvegardés pour <strong><?php echo esc_html($park_options[$active_slug]); ?></strong> !</p></div>
    <?php endif; ?>

    <?php if (count($park_options) > 1): ?>
    <!-- Onglets parcs -->
    <nav class="nav-tab-wrapper" style="margin-bottom:24px;">
        <?php foreach ($park_options as $slug => $name): ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=nolimit-horaires&park=' . $slug)); ?>"
               class="nav-tab <?php echo $slug === $active_slug ? 'nav-tab-active' : ''; ?>">
                <?php echo esc_html($name); ?>
            </a>
        <?php endforeach; ?>
    </nav>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=nolimit-horaires&park=' . $active_slug)); ?>">
        <?php wp_nonce_field('nolimit_save_horaires_' . $active_slug, 'horaires_nonce'); ?>
        <input type="hidden" name="save_horaires" value="1">
        <input type="hidden" name="park_slug" value="<?php echo esc_attr($active_slug); ?>">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;max-width:1100px;">

            <!-- ── Haute saison ─────────────────────────────── -->
            <div class="card" style="padding:20px;">
                <h2>🌞 Haute saison</h2>
                <table class="form-table">
                    <tr>
                        <th>Période</th>
                        <td>
                            <label>Du mois de&nbsp;
                                <select name="hs_start">
                                    <?php foreach ($months_fr as $i => $m): ?>
                                        <option value="<?php echo $i; ?>" <?php selected($hs_start, $i); ?>><?php echo $m; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            &nbsp;au mois de&nbsp;
                            <label>
                                <select name="hs_end">
                                    <?php foreach ($months_fr as $i => $m): ?>
                                        <option value="<?php echo $i; ?>" <?php selected($hs_end, $i); ?>><?php echo $m; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <p class="description">Inclus (ex : Avril → Septembre)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Ouverture</th>
                        <td>
                            <select name="hs_open">
                                <?php foreach ($hours as $h): ?>
                                    <option value="<?php echo $h; ?>" <?php selected($hs_open, $h); ?>><?php echo $h; ?>h00</option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Fermeture</th>
                        <td>
                            <select name="hs_close">
                                <?php foreach ($hours as $h): ?>
                                    <option value="<?php echo $h; ?>" <?php selected($hs_close, $h); ?>><?php echo $h; ?>h00</option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- ── Basse saison ─────────────────────────────── -->
            <div class="card" style="padding:20px;">
                <h2>🍂 Basse saison</h2>
                <p class="description" style="margin-bottom:12px;">Tous les mois hors haute saison</p>
                <table class="form-table">
                    <tr>
                        <th>Ouverture</th>
                        <td>
                            <select name="bs_open">
                                <?php foreach ($hours as $h): ?>
                                    <option value="<?php echo $h; ?>" <?php selected($bs_open, $h); ?>><?php echo $h; ?>h00</option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Fermeture</th>
                        <td>
                            <select name="bs_close">
                                <?php foreach ($hours as $h): ?>
                                    <option value="<?php echo $h; ?>" <?php selected($bs_close, $h); ?>><?php echo $h; ?>h00</option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- ── Jours de fermeture hebdomadaires ─────────── -->
            <div class="card" style="padding:20px;">
                <h2>📅 Fermeture hebdomadaire</h2>
                <p class="description" style="margin-bottom:12px;">Cochez les jours où le parc est systématiquement fermé (hors exceptions)</p>
                <div style="display:flex;flex-wrap:wrap;gap:12px;margin-top:8px;">
                    <?php foreach ($days_fr as $key => $label): ?>
                        <label style="display:flex;align-items:center;gap:6px;font-size:14px;cursor:pointer;
                                      background:<?php echo in_array($key, $closed_days) ? '#fef2f2' : '#f0fdf4'; ?>;
                                      border:1.5px solid <?php echo in_array($key, $closed_days) ? '#fca5a5' : '#86efac'; ?>;
                                      padding:8px 14px;border-radius:8px;">
                            <input type="checkbox" name="closed_days[]" value="<?php echo $key; ?>"
                                   <?php checked(in_array($key, $closed_days)); ?>>
                            <?php echo $label; ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ── Message libre ────────────────────────────── -->
            <div class="card" style="padding:20px;">
                <h2>💬 Message d'information</h2>
                <p class="description" style="margin-bottom:12px;">Affiché en bannière sur le site (ex : "Fermé pour travaux du 1 au 5 août"). Laisser vide pour ne rien afficher.</p>
                <textarea name="message" rows="3" class="large-text" placeholder="Ex : Fermé exceptionnellement ce week-end pour événement privé."><?php echo esc_textarea($message); ?></textarea>
            </div>

        </div><!-- /grid -->

        <!-- ── Fermetures exceptionnelles ──────────────────── -->
        <div class="card" style="padding:20px;max-width:1100px;margin-top:24px;">
            <h2>🔴 Fermetures exceptionnelles</h2>
            <p class="description" style="margin-bottom:16px;">Jours fériés, travaux, événements privés... Le parc sera affiché comme <strong>fermé</strong> ces jours-là, quelle que soit la saison.</p>

            <table id="except-closed-table" class="widefat striped" style="margin-bottom:12px;">
                <thead>
                    <tr>
                        <th style="width:160px;">📅 Date</th>
                        <th>📝 Motif affiché aux visiteurs</th>
                        <th style="width:50px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($except_closed)): ?>
                        <tr class="no-items"><td colspan="3" style="color:#888;font-style:italic;padding:16px;">Aucune fermeture exceptionnelle</td></tr>
                    <?php else: ?>
                        <?php foreach ($except_closed as $i => $item): ?>
                            <tr>
                                <td><input type="date" name="excl_date[]" value="<?php echo esc_attr($item['date'] ?? ''); ?>" class="regular-text" required></td>
                                <td><input type="text"  name="excl_motif[]" value="<?php echo esc_attr($item['motif'] ?? ''); ?>" class="large-text" placeholder="Ex : Jour férié, Fermeture annuelle..."></td>
                                <td><button type="button" class="button button-small remove-row" style="color:#dc3545;">✕</button></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="button" class="button" onclick="addRow('except-closed-table', 'excl')">➕ Ajouter une fermeture</button>
        </div>

        <!-- ── Ouvertures exceptionnelles ──────────────────── -->
        <div class="card" style="padding:20px;max-width:1100px;margin-top:24px;">
            <h2>🟢 Ouvertures exceptionnelles</h2>
            <p class="description" style="margin-bottom:16px;">Nocturnes, événements spéciaux... Le parc sera ouvert ces jours-là avec des horaires personnalisés, même si c'est un jour normalement fermé.</p>

            <table id="except-open-table" class="widefat striped" style="margin-bottom:12px;">
                <thead>
                    <tr>
                        <th style="width:160px;">📅 Date</th>
                        <th style="width:110px;">🕘 Ouverture</th>
                        <th style="width:110px;">🕔 Fermeture</th>
                        <th>🏷️ Label affiché</th>
                        <th style="width:50px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($except_open)): ?>
                        <tr class="no-items"><td colspan="5" style="color:#888;font-style:italic;padding:16px;">Aucune ouverture exceptionnelle</td></tr>
                    <?php else: ?>
                        <?php foreach ($except_open as $i => $item): ?>
                            <tr>
                                <td><input type="date" name="exop_date[]"  value="<?php echo esc_attr($item['date'] ?? ''); ?>" class="regular-text" required></td>
                                <td>
                                    <select name="exop_open[]">
                                        <?php foreach ($hours as $h): ?>
                                            <option value="<?php echo $h; ?>" <?php selected((int)($item['ouverture'] ?? 9), $h); ?>><?php echo $h; ?>h00</option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="exop_close[]">
                                        <?php foreach ($hours as $h): ?>
                                            <option value="<?php echo $h; ?>" <?php selected((int)($item['fermeture'] ?? 22), $h); ?>><?php echo $h; ?>h00</option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td><input type="text" name="exop_label[]" value="<?php echo esc_attr($item['label'] ?? ''); ?>" class="large-text" placeholder="Ex : Soirée nocturne, Ouverture spéciale..."></td>
                                <td><button type="button" class="button button-small remove-row" style="color:#dc3545;">✕</button></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="button" class="button" onclick="addRow('except-open-table', 'exop')">➕ Ajouter une ouverture</button>
        </div>

        <p style="margin-top:24px;">
            <button type="submit" class="button button-primary button-large">💾 Sauvegarder les horaires</button>
        </p>
    </form>
</div>

<script>
function addRow(tableId, type) {
    const tbody = document.querySelector('#' + tableId + ' tbody');
    // Supprimer le message "aucun élément"
    const noItems = tbody.querySelector('.no-items');
    if (noItems) noItems.remove();

    const tr = document.createElement('tr');

    if (type === 'excl') {
        tr.innerHTML = `
            <td><input type="date" name="excl_date[]" class="regular-text" required></td>
            <td><input type="text" name="excl_motif[]" class="large-text" placeholder="Ex : Jour férié, Fermeture annuelle..."></td>
            <td><button type="button" class="button button-small remove-row" style="color:#dc3545;">✕</button></td>`;
    } else {
        const hours = <?php echo json_encode($hours); ?>;
        let openOpts = hours.map(h => `<option value="${h}"${h===9?' selected':''}>${h}h00</option>`).join('');
        let closeOpts = hours.map(h => `<option value="${h}"${h===22?' selected':''}>${h}h00</option>`).join('');
        tr.innerHTML = `
            <td><input type="date" name="exop_date[]" class="regular-text" required></td>
            <td><select name="exop_open[]">${openOpts}</select></td>
            <td><select name="exop_close[]">${closeOpts}</select></td>
            <td><input type="text" name="exop_label[]" class="large-text" placeholder="Ex : Soirée nocturne..."></td>
            <td><button type="button" class="button button-small remove-row" style="color:#dc3545;">✕</button></td>`;
    }

    tbody.appendChild(tr);
    tr.querySelector('.remove-row').addEventListener('click', () => tr.remove());
}

// Attacher les listeners aux boutons remove existants
document.querySelectorAll('.remove-row').forEach(btn => {
    btn.addEventListener('click', () => btn.closest('tr').remove());
});
</script>
<?php
