<?php
/**
 * Vue admin : Configuration Page Accueil.
 */

if (!defined('ABSPATH')) exit;

$hero_title = get_option('nl_home_hero_title', "L'aventure commence ici");
$hero_subtitle = get_option('nl_home_hero_subtitle', 'Accrobranche, Paintball & Sensations fortes');
$hero_desc = get_option('nl_home_hero_desc', '5 parcs multi-activités en France pour vivre des expériences uniques en pleine nature');
$hero_cta = get_option('nl_home_hero_cta', 'Réserver maintenant');
$hero_video = get_option('nl_home_hero_video', '');
$hero_image_id = get_option('nl_home_hero_image_id', 0);

$enable_parcs = get_option('nl_home_enable_parcs', 1);
$parcs_title = get_option('nl_home_parcs_title', 'Nos 5 parcs en France');
$parcs_subtitle = get_option('nl_home_parcs_subtitle', 'Choisissez votre destination et vivez une aventure inoubliable');
$parcs_max_items = get_option('nl_home_parcs_max_items', 3);

$enable_activities = get_option('nl_home_enable_activities', 1);
$activities_title = get_option('nl_home_activities_title', 'Quelle activité vous tente ?');
$activities_subtitle = get_option('nl_home_activities_subtitle', "Explorez nos activités et trouvez celle qui correspond à votre niveau d'aventure");
$activities_max_items = get_option('nl_home_activities_max_items', 6);

$enable_pourqui = get_option('nl_home_enable_pourqui', 1);
$pourqui_title = get_option('nl_home_pourqui_title', 'Pour qui ?');
$pourqui_subtitle = get_option('nl_home_pourqui_subtitle', 'Des aventures adaptées à tous les publics');

$enable_actualites = get_option('nl_home_enable_actualites', 1);
$actualites_title = get_option('nl_home_actualites_title', 'Actualités & Événements');
$actualites_subtitle = get_option('nl_home_actualites_subtitle', 'Restez informés de nos nouveautés et événements');
$actualites_max_items = get_option('nl_home_actualites_max_items', 3);

$enable_newsletter = get_option('nl_home_enable_newsletter', 1);
$newsletter_title = get_option('nl_home_newsletter_title', 'Restez connecté');
$newsletter_subtitle = get_option('nl_home_newsletter_subtitle', 'Recevez nos offres exclusives et actualités');

$enable_reviews = get_option('nl_home_enable_reviews', 1);
$reviews_title = get_option('nl_home_reviews_title', 'Ils nous font confiance');
$reviews_subtitle = get_option('nl_home_reviews_subtitle', 'Découvrez les avis de nos visiteurs');

$enable_groups = get_option('nl_home_enable_groups', 1);
$groups_title = get_option('nl_home_groups_title', 'Groupes & Événements');
$groups_desc = get_option('nl_home_groups_desc', 'Anniversaires, team building, séminaires... Nous organisons votre événement sur mesure dans nos parcs.');
$groups_benefits = get_option('nl_home_groups_benefits', "Devis gratuit en 24h\nCoordinateur dédié\nEspaces privatifs\nTarifs préférentiels");

$cta_title = get_option('nl_home_cta_title', "Prêt pour l'aventure ?");
$cta_subtitle = get_option('nl_home_cta_subtitle', 'Réservez dès maintenant et vivez une expérience inoubliable');
?>
<div class="wrap">
    <h1>🏠 Configuration Page Accueil</h1>

    <form method="post">
        <?php wp_nonce_field('nolimit_save_home', 'home_nonce'); ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🦸 Section Hero</h2>
            <table class="form-table">
                <tr><th>Titre principal</th><td><input type="text" name="hero_title" value="<?php echo esc_attr($hero_title); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="hero_subtitle" value="<?php echo esc_attr($hero_subtitle); ?>" class="large-text"></td></tr>
                <tr><th>Description</th><td><textarea name="hero_desc" rows="2" class="large-text"><?php echo esc_textarea($hero_desc); ?></textarea></td></tr>
                <tr><th>Texte CTA</th><td><input type="text" name="hero_cta" value="<?php echo esc_attr($hero_cta); ?>" class="regular-text"></td></tr>
                <tr><th>URL Vidéo fond</th><td><input type="url" name="hero_video" value="<?php echo esc_attr($hero_video); ?>" class="large-text" placeholder="https://..."></td></tr>
                <tr><th>Image fond (si pas vidéo)</th><td>
                    <input type="hidden" name="hero_image_id" id="hero_image_id" value="<?php echo esc_attr($hero_image_id); ?>">
                    <button type="button" class="button" onclick="selectImage('hero_image_id')">Choisir</button>
                    <?php if ($hero_image_id): ?><br><small>Image sélectionnée</small><?php endif; ?>
                </td></tr>
            </table>
        </div>

        <?php
        // Sections configurables avec pattern répétitif
        $sections = [
            ['key' => 'parcs', 'icon' => '🏞️', 'label' => 'Parcs', 'has_max' => true, 'max_options' => [2 => '2 parcs', 3 => '3 parcs', 4 => '4 parcs', 5 => '5 parcs', -1 => 'Tous les parcs']],
            ['key' => 'activities', 'icon' => '🎯', 'label' => 'Activités', 'has_max' => true, 'max_options' => [3 => '3 activités', 6 => '6 activités', 9 => '9 activités', -1 => 'Toutes les activités']],
            ['key' => 'pourqui', 'icon' => '👥', 'label' => '"Pour qui ?"', 'has_max' => false],
            ['key' => 'actualites', 'icon' => '📰', 'label' => 'Actualités', 'has_max' => true, 'max_options' => [1 => '1 article', 2 => '2 articles', 3 => '3 articles', 4 => '4 articles']],
            ['key' => 'newsletter', 'icon' => '✉️', 'label' => 'Newsletter', 'has_max' => false],
            ['key' => 'reviews', 'icon' => '⭐', 'label' => 'Avis', 'has_max' => false],
        ];

        foreach ($sections as $s):
            $enable_var = ${"enable_{$s['key']}"};
            $title_var = ${"{$s['key']}_title"};
            $subtitle_var = ${"{$s['key']}_subtitle"};
        ?>
        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2><?php echo $s['icon']; ?> Section <?php echo $s['label']; ?></h2>
            <table class="form-table">
                <tr><th>Activer cette section</th><td><input type="checkbox" name="enable_<?php echo $s['key']; ?>" value="1" <?php checked($enable_var, 1); ?>></td></tr>
                <tr><th>Titre</th><td><input type="text" name="<?php echo $s['key']; ?>_title" value="<?php echo esc_attr($title_var); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="<?php echo $s['key']; ?>_subtitle" value="<?php echo esc_attr($subtitle_var); ?>" class="large-text"></td></tr>
                <?php if (!empty($s['has_max']) && !empty($s['max_options'])): ?>
                <tr><th>Nombre max à afficher</th>
                    <td>
                        <select name="<?php echo $s['key']; ?>_max_items">
                            <?php foreach ($s['max_options'] as $val => $label): ?>
                                <option value="<?php echo $val; ?>" <?php selected(${"{$s['key']}_max_items"}, $val); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
        <?php endforeach; ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>👥 Section Groupes</h2>
            <table class="form-table">
                <tr><th>Activer cette section</th><td><input type="checkbox" name="enable_groups" value="1" <?php checked($enable_groups, 1); ?>></td></tr>
                <tr><th>Titre</th><td><input type="text" name="groups_title" value="<?php echo esc_attr($groups_title); ?>" class="large-text"></td></tr>
                <tr><th>Description</th><td><textarea name="groups_desc" rows="2" class="large-text"><?php echo esc_textarea($groups_desc); ?></textarea></td></tr>
                <tr><th>Avantages (1 par ligne)</th><td><textarea name="groups_benefits" rows="4" class="large-text"><?php echo esc_textarea($groups_benefits); ?></textarea></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🚀 Section CTA Final</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="cta_title" value="<?php echo esc_attr($cta_title); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="cta_subtitle" value="<?php echo esc_attr($cta_subtitle); ?>" class="large-text"></td></tr>
            </table>
        </div>

        <p><button type="submit" name="save_home" class="button button-primary">💾 Sauvegarder</button></p>
    </form>
</div>

<script>
function selectImage(fieldId) {
    var frame = wp.media({ title: 'Choisir une image', multiple: false, library: { type: 'image' }});
    frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        document.getElementById(fieldId).value = attachment.id;
    });
    frame.open();
}
</script>
