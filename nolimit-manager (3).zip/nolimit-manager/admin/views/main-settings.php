<?php
/**
 * Vue admin : Paramètres principaux (Header + Footer).
 */

if (!defined('ABSPATH')) exit;

$pages = get_pages(['post_status' => 'publish', 'sort_column' => 'post_title']);

$logo_id = get_option('nl_logo_id', 0);
$logo_url = $logo_id ? wp_get_attachment_url($logo_id) : '';

$primary = get_option('nl_primary', '#f97316');
$secondary = get_option('nl_secondary', '#eb700f');
$green = get_option('nl_green', '#357600');
$cta_text = get_option('nl_cta_text', 'Réserver');
$cta_page_id = get_option('nl_cta_page_id', 0);
$show_parks = get_option('nl_show_parks', 1);

$f_bg = get_option('nl_f_bg', '#111111');
$f_phone = get_option('nl_f_phone', '01 23 45 67 89');
$f_email = get_option('nl_f_email', 'contact@nolimit-aventure.fr');
$f_desc = get_option('nl_f_desc', '5 parcs multi-activités en France pour vivre des sensations fortes en pleine nature.');
$f_stat1 = get_option('nl_f_stat1', '5');
$f_stat2 = get_option('nl_f_stat2', '20+');
$f_stat3 = get_option('nl_f_stat3', '∞');
$f_cta_title = get_option('nl_f_cta_title', 'Rejoignez l\'aventure');
$f_cta_sub = get_option('nl_f_cta_sub', "Réservez dès maintenant et vivez une expérience inoubliable dans l'un de nos 5 parcs");
$f_show_back = get_option('nl_f_show_back', 1);

$quick = get_option('nl_f_quick', ['Nos Parcs', 'Activités', 'Réserver', 'Groupes', 'FAQ', 'Contact']);
$quick_page_ids = get_option('nl_f_quick_page_ids', [0, 0, 0, 0, 0, 0]);
$legal = get_option('nl_f_legal', ['Mentions légales', 'Confidentialité', 'CGV', 'Règlement']);
$legal_page_ids = get_option('nl_f_legal_page_ids', [0, 0, 0, 0]);

$social_facebook = get_option('nl_social_facebook', '');
$social_instagram = get_option('nl_social_instagram', '');
$social_youtube = get_option('nl_social_youtube', '');
$social_twitter = get_option('nl_social_twitter', '');
?>
<div class="wrap nolimit-admin">
    <h1>🚀 NoLimit Manager</h1>

    <form method="post" id="nolimit-form">
        <?php wp_nonce_field('nolimit_save', 'nolimit_nonce'); ?>

        <!-- HEADER -->
        <div class="card" style="max-width:1200px;margin:20px 0">
            <h2>📋 Header</h2>

            <div class="form-section">
                <h3>🏞️ Logo</h3>
                <div class="logo-upload-container">
                    <div class="logo-preview">
                        <?php if ($logo_url): ?>
                            <img src="<?php echo esc_url($logo_url); ?>" id="logo-preview" style="max-width: 200px; max-height: 100px;">
                        <?php else: ?>
                            <div id="logo-preview" class="logo-placeholder">Aucun logo</div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="logo_id" id="logo_id" value="<?php echo esc_attr($logo_id); ?>">
                    <button type="button" class="button" id="upload-logo-btn" onclick="uploadLogo()">📁 Choisir</button>
                    <button type="button" class="button" onclick="removeLogo()">🗑️ Supprimer</button>
                </div>
            </div>

            <div class="form-section">
                <h3>🎨 Couleurs</h3>
                <table class="form-table">
                    <tr><th>Principale (orange)</th><td><input type="color" name="primary" value="<?php echo esc_attr($primary); ?>"></td></tr>
                    <tr><th>Secondaire</th><td><input type="color" name="secondary" value="<?php echo esc_attr($secondary); ?>"></td></tr>
                    <tr><th>Verte (boutons)</th><td><input type="color" name="green" value="<?php echo esc_attr($green); ?>"></td></tr>
                </table>
            </div>

            <div class="form-section">
                <h3>🔘 Bouton CTA</h3>
                <table class="form-table">
                    <tr><th>Texte</th><td><input type="text" name="cta_text" value="<?php echo esc_attr($cta_text); ?>" class="regular-text"></td></tr>
                    <tr><th>Page</th>
                        <td>
                            <select name="cta_page_id" class="regular-text">
                                <option value="0">-- Sélectionner --</option>
                                <?php foreach ($pages as $page): ?>
                                    <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($cta_page_id, $page->ID); ?>>
                                        <?php echo esc_html($page->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr><th>Sélecteur parcs</th><td><input type="checkbox" name="show_parks" value="1" <?php checked($show_parks, 1); ?>></td></tr>
                </table>
            </div>
        </div>

        <!-- FOOTER -->
        <div class="card" style="max-width:1200px;margin:20px 0">
            <h2>📄 Footer</h2>

            <div class="form-section">
                <h3>🎨 Apparence</h3>
                <table class="form-table">
                    <tr><th>Fond</th><td><input type="color" name="f_bg" value="<?php echo esc_attr($f_bg); ?>"></td></tr>
                </table>
            </div>

            <div class="form-section">
                <h3>📞 Contact</h3>
                <table class="form-table">
                    <tr><th>Téléphone</th><td><input type="text" name="f_phone" value="<?php echo esc_attr($f_phone); ?>" class="regular-text"></td></tr>
                    <tr><th>Email</th><td><input type="email" name="f_email" value="<?php echo esc_attr($f_email); ?>" class="regular-text"></td></tr>
                    <tr><th>Description</th><td><textarea name="f_desc" rows="3" class="large-text"><?php echo esc_textarea($f_desc); ?></textarea></td></tr>
                </table>
            </div>

            <div class="form-section">
                <h3>📊 Statistiques</h3>
                <table class="form-table">
                    <tr><th>Parcs</th><td><input type="text" name="f_stat1" value="<?php echo esc_attr($f_stat1); ?>" style="width:80px"></td></tr>
                    <tr><th>Activités</th><td><input type="text" name="f_stat2" value="<?php echo esc_attr($f_stat2); ?>" style="width:80px"></td></tr>
                    <tr><th>Souvenirs</th><td><input type="text" name="f_stat3" value="<?php echo esc_attr($f_stat3); ?>" style="width:80px"></td></tr>
                </table>
            </div>

            <div class="form-section">
                <h3>📱 Réseaux sociaux</h3>
                <table class="form-table">
                    <tr><th>Facebook</th><td><input type="url" name="social_facebook" value="<?php echo esc_attr($social_facebook); ?>" class="regular-text" placeholder="https://facebook.com/..."></td></tr>
                    <tr><th>Instagram</th><td><input type="url" name="social_instagram" value="<?php echo esc_attr($social_instagram); ?>" class="regular-text" placeholder="https://instagram.com/..."></td></tr>
                    <tr><th>YouTube</th><td><input type="url" name="social_youtube" value="<?php echo esc_attr($social_youtube); ?>" class="regular-text" placeholder="https://youtube.com/..."></td></tr>
                    <tr><th>Twitter/X</th><td><input type="url" name="social_twitter" value="<?php echo esc_attr($social_twitter); ?>" class="regular-text" placeholder="https://twitter.com/..."></td></tr>
                </table>
            </div>

            <div class="form-section">
                <h3>🔗 Liens Rapides</h3>
                <table class="form-table">
                    <?php for($i=0; $i<6; $i++): ?>
                    <tr>
                        <th>Lien <?php echo $i+1; ?></th>
                        <td>
                            <input type="text" name="quick[]" value="<?php echo esc_attr($quick[$i] ?? ''); ?>" placeholder="Label" style="width:150px">
                            <select name="quick_page_id[]">
                                <option value="0">-- Page --</option>
                                <?php foreach ($pages as $page): ?>
                                    <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($quick_page_ids[$i] ?? 0, $page->ID); ?>>
                                        <?php echo esc_html($page->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <?php endfor; ?>
                </table>
            </div>

            <div class="form-section">
                <h3>⚖️ Liens Légaux</h3>
                <table class="form-table">
                    <?php for($i=0; $i<4; $i++): ?>
                    <tr>
                        <th>Lien <?php echo $i+1; ?></th>
                        <td>
                            <input type="text" name="legal[]" value="<?php echo esc_attr($legal[$i] ?? ''); ?>" placeholder="Label" style="width:150px">
                            <select name="legal_page_id[]">
                                <option value="0">-- Page --</option>
                                <?php foreach ($pages as $page): ?>
                                    <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($legal_page_ids[$i] ?? 0, $page->ID); ?>>
                                        <?php echo esc_html($page->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <?php endfor; ?>
                </table>
            </div>

            <div class="form-section">
                <h3>💫 CTA Footer</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="f_cta_title" value="<?php echo esc_attr($f_cta_title); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre</th><td><textarea name="f_cta_sub" rows="2" class="large-text"><?php echo esc_textarea($f_cta_sub); ?></textarea></td></tr>
                    <tr><th>Bouton retour haut</th><td><input type="checkbox" name="f_show_back" value="1" <?php checked($f_show_back, 1); ?>></td></tr>
                </table>
            </div>
        </div>

        <p><button type="submit" name="save_settings" class="button button-primary button-large">💾 Sauvegarder</button></p>
    </form>

    <!-- Actions Rapides -->
    <div class="card" style="max-width:1200px;margin:20px 0">
        <h2>⚡ Actions Rapides</h2>
        <form method="post" style="display:inline-block;margin-right:10px;">
            <?php wp_nonce_field('nolimit_create_defaults', 'create_defaults_nonce'); ?>
            <button type="submit" name="create_defaults" class="button">🔄 Créer données par défaut</button>
        </form>
    </div>

    <!-- APIs -->
    <div class="card" style="max-width:1200px;margin:20px 0">
        <h2>🔌 APIs REST</h2>
        <table class="widefat">
            <thead><tr><th>Endpoint</th><th>URL</th><th>Action</th></tr></thead>
            <tbody>
                <?php
                $endpoints = [
                    'Header' => 'header', 'Footer' => 'footer', 'Home' => 'home',
                    'Home Config' => 'home-config', 'Hero' => 'hero', 'Stats' => 'stats',
                    'Pour Qui' => 'pour-qui', 'Newsletter' => 'newsletter',
                    'Actualités' => 'actualites', 'Parks' => 'parks', 'Activities' => 'activities',
                    'FAQs' => 'faqs', 'Reviews' => 'reviews', 'Groups' => 'groups',
                    'Contact (GET+POST)' => 'contact',
                ];
                foreach ($endpoints as $label => $route): ?>
                <tr>
                    <td><?php echo esc_html($label); ?></td>
                    <td><code>/wp-json/nolimit/v1/<?php echo esc_html($route); ?></code></td>
                    <td><a href="<?php echo home_url('/wp-json/nolimit/v1/' . $route); ?>" target="_blank" class="button button-small">Tester</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function uploadLogo() {
    var frame = wp.media({ title: 'Choisir un logo', button: { text: 'Utiliser' }, multiple: false, library: { type: 'image' }});
    frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        document.getElementById('logo_id').value = attachment.id;
        document.getElementById('logo-preview').outerHTML = '<img src="' + attachment.url + '" id="logo-preview" style="max-width: 200px; max-height: 100px;">';
    });
    frame.open();
}
function removeLogo() {
    document.getElementById('logo_id').value = '';
    document.getElementById('logo-preview').outerHTML = '<div id="logo-preview" class="logo-placeholder">Aucun logo</div>';
}
</script>
