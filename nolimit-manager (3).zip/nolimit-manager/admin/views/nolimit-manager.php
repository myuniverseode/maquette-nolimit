<?php
/**
 * Vue admin : Dashboard NoLimit - Guide d'édition complet
 * Accessible via NoLimit > Paramètres (page principale)
 */
if (!defined('ABSPATH')) exit;
?>
<div class="wrap nolimit-admin">
    <h1>🚀 NoLimit Manager — Tableau de bord</h1>
    <p style="font-size:14px;color:#666;">Voici <strong>où modifier chaque élément</strong> de votre site. Cliquez sur les liens pour accéder directement aux pages d'édition.</p>

    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:20px;margin:20px 0;">

        <!-- PARCS -->
        <div class="card" style="padding:20px;">
            <h2>🏞️ Parcs</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('edit.php?post_type=nolimit_parc'); ?>">NoLimit › Parcs</a></p>
            <p>Cliquez sur un parc pour modifier :</p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Nom, description, localisation, coordonnées GPS</li>
                <li>Image principale + galerie</li>
                <li>Activités proposées, points forts, niveaux</li>
                <li>Note, nombre d'avis, prix minimum</li>
                <li>Téléphone, email du parc</li>
                <li><strong>🆕 Tarifs (formules)</strong> : Individuel / Groupe / Entreprise — nom, prix, avantages, "populaire"</li>
                <li><strong>🆕 Services sur place</strong> : Vestiaires, Restauration, WiFi...</li>
                <li><strong>🆕 Accessibilité</strong> : PMR, poussettes, animaux guide...</li>
                <li><strong>🆕 Accès / Transport</strong> : Parking, vélo, covoiturage...</li>
                <li><strong>🆕 Bon à savoir</strong> : Annulation, assurance, carte cadeau...</li>
                <li><strong>🆕 Google Place ID</strong> : pour les avis Google</li>
                <li><strong>🆕 URL TripAdvisor</strong> : pour les avis TripAdvisor</li>
            </ul>
            <?php
            $parcs = get_posts(['post_type' => 'nolimit_parc', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']);
            if ($parcs): ?>
            <p style="margin-top:10px;"><strong>Parcs existants :</strong></p>
            <ul style="list-style:none;margin:5px 0;">
                <?php foreach ($parcs as $p): ?>
                <li>→ <a href="<?php echo get_edit_post_link($p->ID); ?>"><?php echo esc_html($p->post_title); ?></a></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>

        <!-- ACTIVITÉS -->
        <div class="card" style="padding:20px;">
            <h2>🧗 Activités</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('edit.php?post_type=nolimit_activity'); ?>">NoLimit › Activités</a></p>
            <p>Cliquez sur une activité pour modifier :</p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Nom, description, image</li>
                <li>Emoji, durée, âge minimum</li>
                <li>Difficulté, intensité</li>
                <li><strong>Grilles tarifaires</strong> : Matin / Après-midi avec prix par catégorie</li>
                <li><strong>🆕 Parcs associés</strong> : sélectionner quels parcs proposent cette activité</li>
            </ul>
        </div>

        <!-- AVIS -->
        <div class="card" style="padding:20px;">
            <h2>⭐ Avis clients</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('edit.php?post_type=nolimit_review'); ?>">NoLimit › Avis</a></p>
            <p>Cliquez sur un avis pour modifier :</p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Auteur, note (1-5), date</li>
                <li>Commentaire (dans le contenu du post)</li>
                <li><strong>Source</strong> : Google / TripAdvisor / Manuel</li>
                <li><strong>Tag</strong> : Famille, Entreprise, Anniversaire, EVJF, etc.</li>
                <li><strong>Avatar</strong> : emoji (ex: 🧗) ou URL d'image</li>
                <li><strong>Parc associé</strong> : associer l'avis à un parc spécifique</li>
            </ul>
            <p style="margin-top:10px;font-style:italic;color:#666;">💡 Les avis sans parc associé s'affichent sur la page globale. Les avis avec un parc s'affichent sur la page du parc.</p>
        </div>

        <!-- FAQ -->
        <div class="card" style="padding:20px;">
            <h2>❓ FAQ</h2>
            <p><strong>Où modifier les questions :</strong> <a href="<?php echo admin_url('edit.php?post_type=nolimit_faq'); ?>">NoLimit › FAQ</a></p>
            <p><strong>Où modifier les catégories :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-faq-config'); ?>">NoLimit › FAQ Config</a></p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Question = titre du post</li>
                <li>Réponse = contenu du post</li>
                <li>Catégorie : Général, Réservation, Activités, Sécurité, Pratique</li>
                <li><strong>🆕 Parc associé</strong> : si rempli, la question apparaît uniquement sur la page de ce parc (+ page FAQ globale)</li>
            </ul>
        </div>

        <!-- BLOG -->
        <div class="card" style="padding:20px;">
            <h2>📝 Blog / Conseils</h2>
            <p><strong>Où modifier les articles :</strong> <a href="<?php echo admin_url('edit.php?post_type=nolimit_blog'); ?>">NoLimit › Blog</a></p>
            <p><strong>Où modifier le titre/config :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-blog-config'); ?>">NoLimit › Blog Config</a></p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Titre, sous-titre, contenu, image à la une</li>
                <li>Auteur, rôle auteur, temps de lecture</li>
                <li>Catégorie (taxonomie), tags</li>
                <li>Niveau : Débutant / Intermédiaire / Avancé</li>
                <li>Mis en avant (oui/non)</li>
                <li>Parc associé (optionnel)</li>
            </ul>
        </div>

        <!-- ACTUALITÉS -->
        <div class="card" style="padding:20px;">
            <h2>📰 Actualités</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('edit.php?post_type=nolimit_news'); ?>">NoLimit › Actualités</a></p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Titre, contenu, image à la une</li>
                <li>Parc associé (optionnel)</li>
                <li>Date de publication</li>
            </ul>
        </div>

        <!-- HEADER & FOOTER -->
        <div class="card" style="padding:20px;">
            <h2>📋 Header & Footer</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-manager'); ?>">NoLimit › Paramètres</a></p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Logo (header + footer)</li>
                <li>Couleurs principales</li>
                <li>Bouton CTA (texte + page)</li>
                <li>Footer : contact, stats, liens rapides, liens légaux, réseaux sociaux, CTA</li>
            </ul>
        </div>

        <!-- HERO -->
        <div class="card" style="padding:20px;">
            <h2>🎬 Hero / Carousel</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-hero'); ?>">NoLimit › Hero / Carousel</a></p>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Images du carousel (jusqu'à 5)</li>
                <li>Badge texte, titre principal</li>
                <li>URL + miniature vidéo</li>
            </ul>
        </div>

        <!-- MENUS D'ANCRAGE -->
        <div class="card" style="padding:20px;">
            <h2>📌 Menus d'ancrage</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-siteconfig'); ?>">NoLimit › Config Globale</a></p>
            <ul style="list-style:disc;margin-left:20px;">
                <li><strong>Menu accueil</strong> : modifiable dans le champ "Menu d'ancrage" (JSON)</li>
                <li><strong>Menu par parc</strong> : modifiable via option <code>nl_park_{slug}_anchor_menu</code></li>
            </ul>
            <p style="margin-top:10px;font-style:italic;color:#666;">💡 Format JSON : <code>[{"id":"parcs","label":"Parcs","section":"parcs","icon":"MapPin"}]</code></p>
        </div>

        <!-- POUR QUI -->
        <div class="card" style="padding:20px;">
            <h2>👥 Pour Qui</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-pourqui'); ?>">NoLimit › Pour Qui</a></p>
        </div>

        <!-- STATS -->
        <div class="card" style="padding:20px;">
            <h2>📊 Stats & Features</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-stats'); ?>">NoLimit › Stats & Features</a></p>
        </div>

        <!-- NEWSLETTER -->
        <div class="card" style="padding:20px;">
            <h2>📧 Newsletter</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-newsletter'); ?>">NoLimit › Newsletter</a></p>
        </div>

        <!-- CONTACT -->
        <div class="card" style="padding:20px;">
            <h2>📞 Contact</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-contact'); ?>">NoLimit › Contact</a></p>
        </div>

        <!-- RÉSERVATION -->
        <div class="card" style="padding:20px;">
            <h2>📅 Réservation</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-booking'); ?>">NoLimit › Réservation</a></p>
        </div>

        <!-- GROUPES -->
        <div class="card" style="padding:20px;">
            <h2>🎉 Groupes</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-groups'); ?>">NoLimit › Groupes (pages)</a></p>
        </div>

        <!-- À PROPOS -->
        <div class="card" style="padding:20px;">
            <h2>ℹ️ À Propos</h2>
            <p><strong>Où modifier :</strong> <a href="<?php echo admin_url('admin.php?page=nolimit-about'); ?>">NoLimit › À Propos</a></p>
        </div>
    </div>

    <!-- ACTIONS RAPIDES -->
    <div class="card" style="max-width:1200px;margin:20px 0;padding:20px;">
        <h2>⚡ Actions Rapides</h2>
        <form method="post" style="display:inline-block;margin-right:10px;">
            <?php wp_nonce_field('nolimit_create_defaults', 'create_defaults_nonce'); ?>
            <button type="submit" name="create_defaults" class="button button-primary">🔄 Créer les données par défaut (parcs, activités, FAQ, avis...)</button>
        </form>
        <p style="margin-top:10px;color:#666;font-style:italic;">Crée des exemples dans chaque CPT si aucune donnée n'existe encore.</p>
    </div>

    <!-- APIs -->
    <div class="card" style="max-width:1200px;margin:20px 0;padding:20px;">
        <h2>🔌 APIs REST</h2>
        <table class="widefat">
            <thead><tr><th>Endpoint</th><th>URL</th><th>Action</th></tr></thead>
            <tbody>
                <?php
                $endpoints = [
                    'Header' => 'header', 'Footer' => 'footer', 'Hero' => 'hero',
                    'Stats' => 'stats', 'Pour Qui' => 'pour-qui', 'Newsletter' => 'newsletter',
                    'Parcs (liste)' => 'parks', 'Parc (détail)' => 'parks/{slug}',
                    'Activités' => 'activities', 'Activités (par parc)' => 'activities?park={slug}',
                    'FAQs' => 'faqs', 'FAQs (par parc)' => 'faqs/park/{slug}',
                    'Avis' => 'reviews', 'Avis (par parc)' => 'reviews?park={slug}',
                    'Blog' => 'blog', 'Blog (article)' => 'blog/{slug}',
                    'Actualités' => 'actualites', 'Groupes' => 'groups',
                    'Contact' => 'contact', 'Config Globale' => 'site-config',
                    'Config Parc' => 'site-config/park/{slug}',
                ];
                foreach ($endpoints as $label => $route):
                    $testable = !str_contains($route, '{');
                ?>
                <tr>
                    <td><?php echo esc_html($label); ?></td>
                    <td><code>/wp-json/nolimit/v1/<?php echo esc_html($route); ?></code></td>
                    <td>
                        <?php if ($testable): ?>
                        <a href="<?php echo home_url('/wp-json/nolimit/v1/' . $route); ?>" target="_blank" class="button button-small">Tester</a>
                        <?php else: ?>
                        <span class="description">Remplacer {slug}</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
