<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap nolimit-admin">
    <h1>📝 Blog & Conseils</h1>
    <p class="description">Les articles de blog sont gérés via le CPT "Blog / Conseils" dans le menu NoLimit.<br>
    Ici vous configurez les textes de la page d'index du blog.</p>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_blog', 'blog_nonce'); ?>
        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>📋 Textes de la page</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="blog_title" value="<?php echo esc_attr(get_option('nl_blog_title', 'Blog & Conseils')); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="blog_subtitle" value="<?php echo esc_attr(get_option('nl_blog_subtitle', '')); ?>" class="large-text"></td></tr>
            </table>
        </div>
        <p><button type="submit" name="save_blog_config" class="button button-primary">💾 Sauvegarder</button></p>
    </form>
    <div class="card" style="max-width:1000px;margin:20px 0">
        <h2>📌 Pour ajouter des articles</h2>
        <p>Allez dans <strong>NoLimit → Blog</strong> pour créer et gérer les articles.</p>
        <p>Les catégories se gèrent dans <strong>NoLimit → Blog → Catégories Blog</strong>.</p>
    </div>
</div>
