<?php if (!defined('ABSPATH')) exit;

/**
 * Helper: decode JSON option into PHP array
 */
function nl_pq_get_items(string $key, array $default = []): array {
    $raw = get_option($key, '');
    if ($raw && is_string($raw)) {
        $d = json_decode($raw, true);
        if (is_array($d) && !empty($d)) return $d;
    }
    if (is_array($raw) && !empty($raw)) return $raw;
    return $default;
}

$card_ids = ['duo', 'famille', 'enfant', 'entreprise'];
$card_labels = ['duo' => '💑 En Duo', 'famille' => '👨‍👩‍👧‍👦 En Famille', 'enfant' => '🧒 Enfants', 'entreprise' => '💼 Entreprises'];
?>

<div class="wrap nolimit-admin nolimit-pourqui-admin">
    <h1>👥 Section "Pour Qui ?" — Gestion visuelle</h1>
    <p class="description" style="margin-bottom:20px">Gérez les contenus des 4 pages Pour Qui. Chaque section est modifiable avec des champs simples — pas besoin de code.</p>

    <!-- TABS -->
    <ul class="nl-tabs">
        <li><a href="#tab-hub" class="nl-tab active">📋 Hub</a></li>
        <li><a href="#tab-duo" class="nl-tab">💑 Duo</a></li>
        <li><a href="#tab-enfant" class="nl-tab">🧒 Enfant</a></li>
        <li><a href="#tab-entreprise" class="nl-tab">💼 Entreprise</a></li>
        <li><a href="#tab-famille" class="nl-tab">👨‍👩‍👧‍👦 Famille</a></li>
    </ul>

    <form method="post">
        <?php wp_nonce_field('nolimit_save_pourqui', 'pourqui_nonce'); ?>

        <!-- ═══════════════════════════════════════ -->
        <!-- TAB: HUB -->
        <!-- ═══════════════════════════════════════ -->
        <div id="tab-hub" class="nl-tab-pane active">
            <h2>📋 Cartes du Hub "Pour Qui"</h2>
            <p class="description">Ces cartes apparaissent sur la page principale pour orienter les visiteurs.</p>

            <?php foreach ($card_ids as $id):
                $img_id = get_option("nl_pq_{$id}_image_id", 0);
                $img_url = $img_id ? wp_get_attachment_url($img_id) : '';
            ?>
            <div class="nl-card">
                <h3><?php echo $card_labels[$id]; ?></h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_<?php echo $id; ?>_title" value="<?php echo esc_attr(get_option("nl_pq_{$id}_title", '')); ?>" class="large-text"></td></tr>
                    <tr><th>Description</th><td><input type="text" name="pq_<?php echo $id; ?>_desc" value="<?php echo esc_attr(get_option("nl_pq_{$id}_desc", '')); ?>" class="large-text"></td></tr>
                    <tr><th>Icône Lucide</th><td><input type="text" name="pq_<?php echo $id; ?>_icon" value="<?php echo esc_attr(get_option("nl_pq_{$id}_icon", '')); ?>" class="regular-text" placeholder="Heart, Users, Cake…"></td></tr>
                    <tr><th>Couleur</th><td><input type="color" name="pq_<?php echo $id; ?>_color" value="<?php echo esc_attr(get_option("nl_pq_{$id}_color", '#eb700f')); ?>"></td></tr>
                    <tr><th>Lien</th><td><input type="text" name="pq_<?php echo $id; ?>_link" value="<?php echo esc_attr(get_option("nl_pq_{$id}_link", '')); ?>" class="regular-text" placeholder="/pour-qui/duo"></td></tr>
                    <tr><th>Image</th><td>
                        <input type="hidden" name="pq_<?php echo $id; ?>_image_id" id="pq_<?php echo $id; ?>_image_id" value="<?php echo esc_attr($img_id); ?>">
                        <button type="button" class="button nl-media-btn" data-target="pq_<?php echo $id; ?>_image_id">📁 Choisir une image</button>
                        <?php if ($img_url): ?><br><img src="<?php echo esc_url($img_url); ?>" style="max-width:200px;margin-top:8px;border-radius:8px;"><?php endif; ?>
                    </td></tr>
                </table>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- ═══════════════════════════════════════ -->
        <!-- TAB: DUO -->
        <!-- ═══════════════════════════════════════ -->
        <div id="tab-duo" class="nl-tab-pane">
            <h2>💑 Page Duo</h2>

            <!-- Hero -->
            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Titre principal</th><td><input type="text" name="pq_duo_hero_title" value="<?php echo esc_attr(get_option('nl_pq_duo_hero_title', '')); ?>" class="large-text" placeholder="À deux, tout change."></td></tr>
                    <tr><th>Sous-titre</th><td><textarea name="pq_duo_hero_subtitle" rows="2" class="large-text" placeholder="Parce que les meilleurs souvenirs se créent avec quelqu'un."><?php echo esc_textarea(get_option('nl_pq_duo_hero_subtitle', '')); ?></textarea></td></tr>
                    <tr><th>Badge</th><td><input type="text" name="pq_duo_hero_badge" value="<?php echo esc_attr(get_option('nl_pq_duo_hero_badge', '')); ?>" class="regular-text" placeholder="Pour les duos"></td></tr>
                </table>
            </div>

            <!-- Intro -->
            <div class="nl-card">
                <h3>📝 Bloc d'introduction</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_duo_intro_title" value="<?php echo esc_attr(get_option('nl_pq_duo_intro_title', '')); ?>" class="large-text" placeholder="L'aventure en duo, c'est magique"></td></tr>
                    <tr><th>Texte</th><td><textarea name="pq_duo_intro_text" rows="3" class="large-text"><?php echo esc_textarea(get_option('nl_pq_duo_intro_text', '')); ?></textarea></td></tr>
                </table>
            </div>

            <!-- Moments — repeater -->
            <div class="nl-card">
                <h3>🎉 Moments / Occasions</h3>
                <p class="description">Les occasions pour lesquelles un duo peut réserver. Ajoutez ou supprimez des lignes.</p>
                <?php
                $moments = nl_pq_get_items('nl_pq_duo_moments', [
                    ['icon' => '🎂', 'title' => 'Anniversaire à deux', 'desc' => 'Une journée mémorable.'],
                    ['icon' => '💍', 'title' => 'EVJF / EVG', 'desc' => "L'aventure avant la grande journée."],
                    ['icon' => '🎁', 'title' => 'Cadeau original', 'desc' => "Offrez une expérience."],
                    ['icon' => '💡', 'title' => 'Premier rendez-vous', 'desc' => "Sortez des sentiers battus."],
                ]);
                ?>
                <div class="nl-repeater" data-name="pq_duo_moments">
                    <?php foreach ($moments as $i => $m): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_duo_moments[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($m['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_duo_moments[<?php echo $i; ?>][title]" value="<?php echo esc_attr($m['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="pq_duo_moments[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($m['desc'] ?? ''); ?>" placeholder="Description courte" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row" title="Supprimer">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_duo_moments" data-fields='["icon|Emoji|xs","title|Titre|md","desc|Description|lg"]'>＋ Ajouter un moment</button>
            </div>

            <!-- Activités duo — repeater -->
            <div class="nl-card">
                <h3>🧗 Activités duo spécifiques</h3>
                <p class="description">⚠️ Si vide, les vraies activités WordPress seront affichées automatiquement. N'ajoutez des lignes ici que si vous voulez des activités avec des prix/descriptions spécifiques pour la page Duo.</p>
                <?php $duo_acts = nl_pq_get_items('nl_pq_duo_activities', []); ?>
                <div class="nl-repeater" data-name="pq_duo_activities">
                    <?php foreach ($duo_acts as $i => $a): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_duo_activities[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($a['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_duo_activities[<?php echo $i; ?>][name]" value="<?php echo esc_attr($a['name'] ?? ''); ?>" placeholder="Nom" class="nl-field-md">
                        <input type="text" name="pq_duo_activities[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($a['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <input type="text" name="pq_duo_activities[<?php echo $i; ?>][diff]" value="<?php echo esc_attr($a['diff'] ?? ''); ?>" placeholder="Difficulté" class="nl-field-sm">
                        <input type="number" name="pq_duo_activities[<?php echo $i; ?>][price]" value="<?php echo esc_attr($a['price'] ?? ''); ?>" placeholder="Prix €" class="nl-field-xs">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_duo_activities" data-fields='["emoji|Emoji|xs","name|Nom|md","desc|Description|lg","diff|Difficulté|sm","price|Prix €|xs:number"]'>＋ Ajouter une activité</button>
            </div>

            <!-- Pack Duo -->
            <div class="nl-card">
                <h3>💝 Pack Duo</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_duo_pack_title" value="<?php echo esc_attr(get_option('nl_pq_duo_pack_title', '')); ?>" class="regular-text" placeholder="Pack Duo"></td></tr>
                    <tr><th>Réduction affichée</th><td><input type="text" name="pq_duo_pack_discount" value="<?php echo esc_attr(get_option('nl_pq_duo_pack_discount', '')); ?>" class="regular-text" placeholder="-15%"></td></tr>
                    <tr><th>Description</th><td><textarea name="pq_duo_pack_desc" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_pq_duo_pack_desc', '')); ?></textarea></td></tr>
                </table>

                <h4>Ce qui est inclus</h4>
                <p class="description">Une ligne par avantage du pack.</p>
                <?php $pack_features = nl_pq_get_items('nl_pq_duo_pack_features', ['2 places au tarif réduit', 'Même activité, même créneau', 'Photo souvenir offerte', 'Annulation gratuite 48h avant']); ?>
                <div class="nl-repeater nl-repeater-simple" data-name="pq_duo_pack_features">
                    <?php foreach ($pack_features as $i => $f): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_duo_pack_features[<?php echo $i; ?>]" value="<?php echo esc_attr(is_string($f) ? $f : ''); ?>" placeholder="Avantage…" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row-simple" data-target="pq_duo_pack_features" data-placeholder="Avantage…">＋ Ajouter</button>

                <h4 style="margin-top:20px">Chiffres clés du pack</h4>
                <?php $pack_stats = nl_pq_get_items('nl_pq_duo_pack_stats', [
                    ['val' => '-15%', 'label' => 'sur 2 places'], ['val' => '2h', 'label' => 'en moyenne'],
                    ['val' => '6', 'label' => 'activités dispo'], ['val' => '4.9★', 'label' => 'note duo'],
                ]); ?>
                <div class="nl-repeater" data-name="pq_duo_pack_stats">
                    <?php foreach ($pack_stats as $i => $s): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_duo_pack_stats[<?php echo $i; ?>][val]" value="<?php echo esc_attr($s['val'] ?? ''); ?>" placeholder="Valeur (ex: -15%)" class="nl-field-sm">
                        <input type="text" name="pq_duo_pack_stats[<?php echo $i; ?>][label]" value="<?php echo esc_attr($s['label'] ?? ''); ?>" placeholder="Label (ex: sur 2 places)" class="nl-field-md">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_duo_pack_stats" data-fields='["val|Valeur|sm","label|Label|md"]'>＋ Ajouter un chiffre</button>
            </div>

            <!-- Témoignages duo -->
            <div class="nl-card">
                <h3>⭐ Témoignages</h3>
                <p class="description">Si vous ne mettez rien ici, les vrais avis WordPress tagués « Couple » seront affichés automatiquement.</p>
                <?php $duo_testi = nl_pq_get_items('nl_pq_duo_testimonials', []); ?>
                <div class="nl-repeater" data-name="pq_duo_testimonials">
                    <?php foreach ($duo_testi as $i => $t): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_duo_testimonials[<?php echo $i; ?>][author]" value="<?php echo esc_attr($t['author'] ?? ''); ?>" placeholder="Auteur" class="nl-field-md">
                        <input type="number" name="pq_duo_testimonials[<?php echo $i; ?>][stars]" value="<?php echo esc_attr($t['stars'] ?? 5); ?>" placeholder="Note" min="1" max="5" class="nl-field-xs">
                        <input type="text" name="pq_duo_testimonials[<?php echo $i; ?>][text]" value="<?php echo esc_attr($t['text'] ?? ''); ?>" placeholder="Commentaire…" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_duo_testimonials" data-fields='["author|Auteur|md","stars|Note (1-5)|xs:number","text|Commentaire|xl"]'>＋ Ajouter un témoignage</button>
            </div>

            <!-- Blog & CTA -->
            <div class="nl-card">
                <h3>📰 Blog & CTA final</h3>
                <p class="description">Les articles de blog s'affichent automatiquement depuis WordPress. Vous pouvez personnaliser les titres de section.</p>
                <table class="form-table">
                    <tr><th>Titre section blog</th><td><input type="text" name="pq_duo_blog_title" value="<?php echo esc_attr(get_option('nl_pq_duo_blog_title', '')); ?>" class="large-text" placeholder="Idées & actualités"></td></tr>
                    <tr><th>Sous-titre blog</th><td><input type="text" name="pq_duo_blog_subtitle" value="<?php echo esc_attr(get_option('nl_pq_duo_blog_subtitle', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Titre CTA</th><td><input type="text" name="pq_duo_cta_title" value="<?php echo esc_attr(get_option('nl_pq_duo_cta_title', '')); ?>" class="large-text" placeholder="Prêts pour l'aventure ?"></td></tr>
                    <tr><th>Sous-titre CTA</th><td><input type="text" name="pq_duo_cta_subtitle" value="<?php echo esc_attr(get_option('nl_pq_duo_cta_subtitle', '')); ?>" class="large-text"></td></tr>
                </table>
            </div>
        </div>

        <!-- ═══════════════════════════════════════ -->
        <!-- TAB: ENFANT -->
        <!-- ═══════════════════════════════════════ -->
        <div id="tab-enfant" class="nl-tab-pane">
            <h2>🧒 Page Enfant</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_enfant_hero_title" value="<?php echo esc_attr(get_option('nl_pq_enfant_hero_title', '')); ?>" class="large-text" placeholder="Leur première grande aventure."></td></tr>
                    <tr><th>Sous-titre</th><td><textarea name="pq_enfant_hero_subtitle" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_pq_enfant_hero_subtitle', '')); ?></textarea></td></tr>
                    <tr><th>Badge</th><td><input type="text" name="pq_enfant_hero_badge" value="<?php echo esc_attr(get_option('nl_pq_enfant_hero_badge', '')); ?>" class="regular-text" placeholder="Pour les enfants"></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>📝 Bloc d'introduction</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_enfant_intro_title" value="<?php echo esc_attr(get_option('nl_pq_enfant_intro_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Texte</th><td><textarea name="pq_enfant_intro_text" rows="3" class="large-text"><?php echo esc_textarea(get_option('nl_pq_enfant_intro_text', '')); ?></textarea></td></tr>
                </table>
            </div>

            <!-- Activités enfant -->
            <div class="nl-card">
                <h3>🧗 Activités enfant</h3>
                <p class="description">⚠️ Si vide, les vraies activités WordPress seront affichées. N'ajoutez des lignes ici que pour des activités spécifiques enfant.</p>
                <?php $enfant_acts = nl_pq_get_items('nl_pq_enfant_activities', []); ?>
                <div class="nl-repeater" data-name="pq_enfant_activities">
                    <?php foreach ($enfant_acts as $i => $a): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_enfant_activities[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($a['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_enfant_activities[<?php echo $i; ?>][name]" value="<?php echo esc_attr($a['name'] ?? ''); ?>" placeholder="Nom" class="nl-field-md">
                        <input type="text" name="pq_enfant_activities[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($a['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <input type="number" name="pq_enfant_activities[<?php echo $i; ?>][ageMin]" value="<?php echo esc_attr($a['ageMin'] ?? ''); ?>" placeholder="Âge min" class="nl-field-xs">
                        <input type="text" name="pq_enfant_activities[<?php echo $i; ?>][duration]" value="<?php echo esc_attr($a['duration'] ?? ''); ?>" placeholder="Durée" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_enfant_activities" data-fields='["emoji|Emoji|xs","name|Nom|md","desc|Description|lg","ageMin|Âge min|xs:number","duration|Durée|sm"]'>＋ Ajouter une activité</button>
            </div>

            <!-- Sécurité -->
            <div class="nl-card">
                <h3>🛡️ Points de sécurité</h3>
                <?php $safety = nl_pq_get_items('nl_pq_enfant_safety', [
                    ['icon' => '🛡️', 'title' => 'Harnais sur mesure', 'desc' => 'Équipements certifiés EN.'],
                    ['icon' => '👨‍🏫', 'title' => 'Moniteurs spécialisés', 'desc' => 'Diplômés BPJEPS ou BAFA.'],
                    ['icon' => '🚑', 'title' => 'Secouriste sur place', 'desc' => 'Présent en permanence.'],
                    ['icon' => '📏', 'title' => 'Tailles et poids', 'desc' => 'Critères vérifiés à l\'accueil.'],
                ]); ?>
                <div class="nl-repeater" data-name="pq_enfant_safety">
                    <?php foreach ($safety as $i => $s): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_enfant_safety[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($s['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_enfant_safety[<?php echo $i; ?>][title]" value="<?php echo esc_attr($s['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="pq_enfant_safety[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($s['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_enfant_safety" data-fields='["icon|Emoji|xs","title|Titre|md","desc|Description|lg"]'>＋ Ajouter</button>
            </div>

            <!-- Anniversaire -->
            <div class="nl-card">
                <h3>🎂 Pack Anniversaire</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_enfant_birthday_title" value="<?php echo esc_attr(get_option('nl_pq_enfant_birthday_title', '')); ?>" class="large-text" placeholder="Anniversaire inoubliable."></td></tr>
                    <tr><th>Description</th><td><textarea name="pq_enfant_birthday_desc" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_pq_enfant_birthday_desc', '')); ?></textarea></td></tr>
                    <tr><th>Prix affiché</th><td><input type="text" name="pq_enfant_birthday_price" value="<?php echo esc_attr(get_option('nl_pq_enfant_birthday_price', '')); ?>" class="regular-text" placeholder="À partir de 199€"></td></tr>
                    <tr><th>Capacité</th><td><input type="text" name="pq_enfant_birthday_capacity" value="<?php echo esc_attr(get_option('nl_pq_enfant_birthday_capacity', '')); ?>" class="regular-text" placeholder="jusqu'à 12 enfants"></td></tr>
                </table>
                <h4>Ce qui est inclus</h4>
                <?php $bday_features = nl_pq_get_items('nl_pq_enfant_birthday_features', ['Invitation personnalisée offerte', 'Zone pique-nique réservée', 'Animation dédiée 1h30', 'Goûter + boissons inclus', 'Photo de groupe imprimée', "Coffret souvenir"]); ?>
                <div class="nl-repeater nl-repeater-simple" data-name="pq_enfant_birthday_features">
                    <?php foreach ($bday_features as $i => $f): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_enfant_birthday_features[<?php echo $i; ?>]" value="<?php echo esc_attr(is_string($f) ? $f : ''); ?>" placeholder="Avantage…" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row-simple" data-target="pq_enfant_birthday_features" data-placeholder="Avantage…">＋ Ajouter</button>
            </div>

            <!-- Témoignages enfant -->
            <div class="nl-card">
                <h3>⭐ Témoignages</h3>
                <p class="description">Si vide → les vrais avis tagués « Famille » ou « Anniversaire » seront affichés.</p>
                <?php $enfant_testi = nl_pq_get_items('nl_pq_enfant_testimonials', []); ?>
                <div class="nl-repeater" data-name="pq_enfant_testimonials">
                    <?php foreach ($enfant_testi as $i => $t): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_enfant_testimonials[<?php echo $i; ?>][author]" value="<?php echo esc_attr($t['author'] ?? ''); ?>" placeholder="Auteur" class="nl-field-md">
                        <input type="number" name="pq_enfant_testimonials[<?php echo $i; ?>][stars]" value="<?php echo esc_attr($t['stars'] ?? 5); ?>" min="1" max="5" class="nl-field-xs">
                        <input type="text" name="pq_enfant_testimonials[<?php echo $i; ?>][text]" value="<?php echo esc_attr($t['text'] ?? ''); ?>" placeholder="Commentaire" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_enfant_testimonials" data-fields='["author|Auteur|md","stars|Note (1-5)|xs:number","text|Commentaire|xl"]'>＋ Ajouter</button>
            </div>

            <div class="nl-card">
                <h3>📢 CTA final</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_enfant_cta_title" value="<?php echo esc_attr(get_option('nl_pq_enfant_cta_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="pq_enfant_cta_subtitle" value="<?php echo esc_attr(get_option('nl_pq_enfant_cta_subtitle', '')); ?>" class="large-text"></td></tr>
                </table>
            </div>
        </div>

        <!-- ═══════════════════════════════════════ -->
        <!-- TAB: ENTREPRISE -->
        <!-- ═══════════════════════════════════════ -->
        <div id="tab-entreprise" class="nl-tab-pane">
            <h2>💼 Page Entreprise</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_entreprise_hero_title" value="<?php echo esc_attr(get_option('nl_pq_entreprise_hero_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><textarea name="pq_entreprise_hero_subtitle" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_pq_entreprise_hero_subtitle', '')); ?></textarea></td></tr>
                    <tr><th>Badge</th><td><input type="text" name="pq_entreprise_hero_badge" value="<?php echo esc_attr(get_option('nl_pq_entreprise_hero_badge', '')); ?>" class="regular-text" placeholder="Pour les entreprises"></td></tr>
                </table>
            </div>

            <!-- KPIs -->
            <div class="nl-card">
                <h3>📊 Chiffres clés (affichés dans le hero)</h3>
                <?php $kpis = nl_pq_get_items('nl_pq_entreprise_kpis', [
                    ['val' => '500+', 'label' => 'événements réalisés'], ['val' => '98%', 'label' => 'de satisfaction'],
                    ['val' => '24h', 'label' => 'délai de réponse'], ['val' => '10–300', 'label' => 'participants'],
                ]); ?>
                <div class="nl-repeater" data-name="pq_entreprise_kpis">
                    <?php foreach ($kpis as $i => $k): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_entreprise_kpis[<?php echo $i; ?>][val]" value="<?php echo esc_attr($k['val'] ?? ''); ?>" placeholder="Valeur (ex: 500+)" class="nl-field-sm">
                        <input type="text" name="pq_entreprise_kpis[<?php echo $i; ?>][label]" value="<?php echo esc_attr($k['label'] ?? ''); ?>" placeholder="Label" class="nl-field-md">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_entreprise_kpis" data-fields='["val|Valeur|sm","label|Label|md"]'>＋ Ajouter</button>
            </div>

            <!-- Formats -->
            <div class="nl-card">
                <h3>📋 Formats d'événement</h3>
                <?php $formats = nl_pq_get_items('nl_pq_entreprise_formats', []); ?>
                <div class="nl-repeater" data-name="pq_entreprise_formats">
                    <?php foreach ($formats as $i => $f): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_entreprise_formats[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($f['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_entreprise_formats[<?php echo $i; ?>][title]" value="<?php echo esc_attr($f['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="pq_entreprise_formats[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($f['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <input type="text" name="pq_entreprise_formats[<?php echo $i; ?>][duration]" value="<?php echo esc_attr($f['duration'] ?? ''); ?>" placeholder="Durée" class="nl-field-sm">
                        <input type="text" name="pq_entreprise_formats[<?php echo $i; ?>][participants]" value="<?php echo esc_attr($f['participants'] ?? ''); ?>" placeholder="Participants" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_entreprise_formats" data-fields='["emoji|Emoji|xs","title|Titre|md","desc|Description|lg","duration|Durée|sm","participants|Participants|sm"]'>＋ Ajouter un format</button>
            </div>

            <!-- Avantages -->
            <div class="nl-card">
                <h3>✅ Avantages</h3>
                <?php $advantages = nl_pq_get_items('nl_pq_entreprise_advantages', []); ?>
                <div class="nl-repeater" data-name="pq_entreprise_advantages">
                    <?php foreach ($advantages as $i => $a): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_entreprise_advantages[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($a['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_entreprise_advantages[<?php echo $i; ?>][title]" value="<?php echo esc_attr($a['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="pq_entreprise_advantages[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($a['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_entreprise_advantages" data-fields='["icon|Emoji|xs","title|Titre|md","desc|Description|lg"]'>＋ Ajouter</button>
            </div>

            <!-- Logos clients -->
            <div class="nl-card">
                <h3>🏢 Logos / Clients de confiance</h3>
                <?php $logos = nl_pq_get_items('nl_pq_entreprise_logos', []); ?>
                <div class="nl-repeater" data-name="pq_entreprise_logos">
                    <?php foreach ($logos as $i => $l): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_entreprise_logos[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($l['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_entreprise_logos[<?php echo $i; ?>][name]" value="<?php echo esc_attr($l['name'] ?? ''); ?>" placeholder="Nom entreprise" class="nl-field-md">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_entreprise_logos" data-fields='["emoji|Emoji|xs","name|Nom entreprise|md"]'>＋ Ajouter</button>
            </div>

            <!-- Témoignages entreprise -->
            <div class="nl-card">
                <h3>⭐ Témoignages</h3>
                <p class="description">Si vide → les vrais avis tagués « Entreprise » ou « Team Building » s'affichent.</p>
                <?php $ent_testi = nl_pq_get_items('nl_pq_entreprise_testimonials', []); ?>
                <div class="nl-repeater" data-name="pq_entreprise_testimonials">
                    <?php foreach ($ent_testi as $i => $t): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_entreprise_testimonials[<?php echo $i; ?>][author]" value="<?php echo esc_attr($t['author'] ?? ''); ?>" placeholder="Auteur / Fonction" class="nl-field-md">
                        <input type="number" name="pq_entreprise_testimonials[<?php echo $i; ?>][stars]" value="<?php echo esc_attr($t['stars'] ?? 5); ?>" min="1" max="5" class="nl-field-xs">
                        <input type="text" name="pq_entreprise_testimonials[<?php echo $i; ?>][text]" value="<?php echo esc_attr($t['text'] ?? ''); ?>" placeholder="Commentaire" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_entreprise_testimonials" data-fields='["author|Auteur|md","stars|Note (1-5)|xs:number","text|Commentaire|xl"]'>＋ Ajouter</button>
            </div>

            <!-- Contact -->
            <div class="nl-card">
                <h3>📞 Contact & Formulaire</h3>
                <table class="form-table">
                    <tr><th>Téléphone</th><td><input type="text" name="pq_entreprise_phone" value="<?php echo esc_attr(get_option('nl_pq_entreprise_phone', '')); ?>" class="regular-text" placeholder="01 23 45 67 89"></td></tr>
                    <tr><th>Email</th><td><input type="email" name="pq_entreprise_email" value="<?php echo esc_attr(get_option('nl_pq_entreprise_email', '')); ?>" class="regular-text" placeholder="entreprise@nolimit.fr"></td></tr>
                    <tr><th>Titre formulaire</th><td><input type="text" name="pq_entreprise_form_title" value="<?php echo esc_attr(get_option('nl_pq_entreprise_form_title', '')); ?>" class="large-text" placeholder="Obtenez votre devis."></td></tr>
                    <tr><th>Sous-titre formulaire</th><td><input type="text" name="pq_entreprise_form_subtitle" value="<?php echo esc_attr(get_option('nl_pq_entreprise_form_subtitle', '')); ?>" class="large-text"></td></tr>
                </table>
            </div>
        </div>

        <!-- ═══════════════════════════════════════ -->
        <!-- TAB: FAMILLE -->
        <!-- ═══════════════════════════════════════ -->
        <div id="tab-famille" class="nl-tab-pane">
            <h2>👨‍👩‍👧‍👦 Page Famille</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_famille_hero_title" value="<?php echo esc_attr(get_option('nl_pq_famille_hero_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><textarea name="pq_famille_hero_subtitle" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_pq_famille_hero_subtitle', '')); ?></textarea></td></tr>
                    <tr><th>Badge</th><td><input type="text" name="pq_famille_hero_badge" value="<?php echo esc_attr(get_option('nl_pq_famille_hero_badge', '')); ?>" class="regular-text" placeholder="Pour les familles"></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>📝 Bloc d'introduction</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_famille_intro_title" value="<?php echo esc_attr(get_option('nl_pq_famille_intro_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Texte</th><td><textarea name="pq_famille_intro_text" rows="3" class="large-text"><?php echo esc_textarea(get_option('nl_pq_famille_intro_text', '')); ?></textarea></td></tr>
                </table>
            </div>

            <!-- Tranches d'âge -->
            <div class="nl-card">
                <h3>👶 Tranches d'âge</h3>
                <?php $age_groups = nl_pq_get_items('nl_pq_famille_age_groups', [
                    ['age' => '5–7 ans', 'emoji' => '🐣', 'note' => 'Accompagné obligatoire'],
                    ['age' => '8–11 ans', 'emoji' => '🌱', 'note' => 'Moniteur dédié'],
                    ['age' => '12–17 ans', 'emoji' => '🚀', 'note' => 'Avec ou sans parent'],
                    ['age' => 'Adultes', 'emoji' => '🏔️', 'note' => 'Liberté totale'],
                ]); ?>
                <div class="nl-repeater" data-name="pq_famille_age_groups">
                    <?php foreach ($age_groups as $i => $g): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_famille_age_groups[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($g['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_famille_age_groups[<?php echo $i; ?>][age]" value="<?php echo esc_attr($g['age'] ?? ''); ?>" placeholder="Tranche d'âge" class="nl-field-sm">
                        <input type="text" name="pq_famille_age_groups[<?php echo $i; ?>][note]" value="<?php echo esc_attr($g['note'] ?? ''); ?>" placeholder="Note (ex: Moniteur dédié)" class="nl-field-md">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_famille_age_groups" data-fields='["emoji|Emoji|xs","age|Tranche d&apos;âge|sm","note|Note|md"]'>＋ Ajouter</button>
            </div>

            <!-- Packs famille -->
            <div class="nl-card">
                <h3>📦 Packs famille</h3>
                <?php $packs = nl_pq_get_items('nl_pq_famille_packs', []); ?>
                <div class="nl-repeater" data-name="pq_famille_packs">
                    <?php foreach ($packs as $i => $p): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_famille_packs[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($p['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_famille_packs[<?php echo $i; ?>][name]" value="<?php echo esc_attr($p['name'] ?? ''); ?>" placeholder="Nom du pack" class="nl-field-md">
                        <input type="text" name="pq_famille_packs[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($p['desc'] ?? ''); ?>" placeholder="Description (ex: 2 adultes + 2 enfants)" class="nl-field-md">
                        <input type="number" name="pq_famille_packs[<?php echo $i; ?>][price]" value="<?php echo esc_attr($p['price'] ?? ''); ?>" placeholder="Prix €" class="nl-field-xs">
                        <input type="number" name="pq_famille_packs[<?php echo $i; ?>][original]" value="<?php echo esc_attr($p['original'] ?? ''); ?>" placeholder="Ancien prix €" class="nl-field-xs">
                        <label class="nl-check-inline"><input type="checkbox" name="pq_famille_packs[<?php echo $i; ?>][popular]" value="1" <?php checked(!empty($p['popular'])); ?>> Populaire</label>
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_famille_packs" data-fields='["emoji|Emoji|xs","name|Nom|md","desc|Description|md","price|Prix €|xs:number","original|Ancien prix €|xs:number"]'>＋ Ajouter un pack</button>
            </div>

            <!-- Événement familial -->
            <div class="nl-card">
                <h3>🎉 Événement familial</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="pq_famille_event_title" value="<?php echo esc_attr(get_option('nl_pq_famille_event_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Description</th><td><textarea name="pq_famille_event_desc" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_pq_famille_event_desc', '')); ?></textarea></td></tr>
                </table>
                <h4>Tags événement</h4>
                <p class="description">Un tag par ligne — ex : « Anniversaire enfant »</p>
                <?php $event_tags = nl_pq_get_items('nl_pq_famille_event_tags', ['Anniversaire enfant', "Fête de fin d'année", 'Grands-parents & petits-enfants']); ?>
                <div class="nl-repeater nl-repeater-simple" data-name="pq_famille_event_tags">
                    <?php foreach ($event_tags as $i => $tag): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_famille_event_tags[<?php echo $i; ?>]" value="<?php echo esc_attr(is_string($tag) ? $tag : ''); ?>" placeholder="Tag…" class="nl-field-md">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row-simple" data-target="pq_famille_event_tags" data-placeholder="Tag…">＋ Ajouter</button>
            </div>

            <!-- Infos pratiques -->
            <div class="nl-card">
                <h3>ℹ️ Infos pratiques</h3>
                <?php $practical = nl_pq_get_items('nl_pq_famille_practical', [
                    ['icon' => '👟', 'title' => 'Tenue requise', 'desc' => 'Chaussures fermées et vêtements sportifs.'],
                    ['icon' => '☀️', 'title' => 'Météo', 'desc' => 'Certaines activités suspendues par mauvais temps.'],
                    ['icon' => '🍱', 'title' => 'Pique-nique', 'desc' => 'Espaces dédiés disponibles.'],
                    ['icon' => '🅿️', 'title' => 'Parking', 'desc' => 'Parking familial gratuit.'],
                    ['icon' => '🍼', 'title' => 'Tout-petits', 'desc' => 'Aire de jeux et espace détente.'],
                    ['icon' => '🏥', 'title' => 'Sécurité', 'desc' => 'Infirmier ou secouriste présent.'],
                ]); ?>
                <div class="nl-repeater" data-name="pq_famille_practical">
                    <?php foreach ($practical as $i => $p): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_famille_practical[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($p['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="pq_famille_practical[<?php echo $i; ?>][title]" value="<?php echo esc_attr($p['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="pq_famille_practical[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($p['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_famille_practical" data-fields='["icon|Emoji|xs","title|Titre|md","desc|Description|lg"]'>＋ Ajouter</button>
            </div>

            <!-- Témoignages famille -->
            <div class="nl-card">
                <h3>⭐ Témoignages</h3>
                <p class="description">Si vide → les vrais avis tagués « Famille » s'affichent automatiquement.</p>
                <?php $fam_testi = nl_pq_get_items('nl_pq_famille_testimonials', []); ?>
                <div class="nl-repeater" data-name="pq_famille_testimonials">
                    <?php foreach ($fam_testi as $i => $t): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="pq_famille_testimonials[<?php echo $i; ?>][author]" value="<?php echo esc_attr($t['author'] ?? ''); ?>" placeholder="Auteur" class="nl-field-md">
                        <input type="number" name="pq_famille_testimonials[<?php echo $i; ?>][stars]" value="<?php echo esc_attr($t['stars'] ?? 5); ?>" min="1" max="5" class="nl-field-xs">
                        <input type="text" name="pq_famille_testimonials[<?php echo $i; ?>][text]" value="<?php echo esc_attr($t['text'] ?? ''); ?>" placeholder="Commentaire" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="pq_famille_testimonials" data-fields='["author|Auteur|md","stars|Note (1-5)|xs:number","text|Commentaire|xl"]'>＋ Ajouter</button>
            </div>

            <div class="nl-card">
                <h3>📰 Blog & CTA</h3>
                <p class="description">Les articles s'affichent automatiquement depuis WordPress.</p>
                <table class="form-table">
                    <tr><th>Titre section blog</th><td><input type="text" name="pq_famille_blog_title" value="<?php echo esc_attr(get_option('nl_pq_famille_blog_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre blog</th><td><input type="text" name="pq_famille_blog_subtitle" value="<?php echo esc_attr(get_option('nl_pq_famille_blog_subtitle', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Titre CTA</th><td><input type="text" name="pq_famille_cta_title" value="<?php echo esc_attr(get_option('nl_pq_famille_cta_title', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre CTA</th><td><input type="text" name="pq_famille_cta_subtitle" value="<?php echo esc_attr(get_option('nl_pq_famille_cta_subtitle', '')); ?>" class="large-text"></td></tr>
                </table>
            </div>
        </div>

        <!-- SUBMIT -->
        <p class="submit" style="margin-top:30px">
            <button type="submit" name="save_pourqui" class="button button-primary button-hero">💾 Sauvegarder toutes les modifications</button>
        </p>
    </form>
</div>

<!-- Styles and scripts are loaded from shared admin.css and admin.js -->
