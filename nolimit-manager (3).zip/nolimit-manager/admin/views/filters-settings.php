<?php
if (!defined('ABSPATH')) exit;

/**
 * Vue admin : Filtres des Parcs
 * Gère les activités, transports et types d'événements affichés dans ParkFilters.tsx
 */

// ── Sauvegarde ────────────────────────────────────────────────
if (isset($_POST['save_filters']) && check_admin_referer('nolimit_save_filters', 'filters_nonce')) {
    $module = null;
    foreach (NoLimit_Loader::get_instance()->get_modules() as $m) {
        if ($m instanceof NoLimit_Module_Filters) { $module = $m; break; }
    }
    if ($module) $module->save_admin_form();
    echo '<div class="notice notice-success"><p>✅ Filtres sauvegardés !</p></div>';
}

// ── Helper ────────────────────────────────────────────────────
function nl_filters_get(string $key, array $default): array {
    $raw = get_option($key, '');
    if ($raw && is_string($raw)) {
        $d = json_decode($raw, true);
        if (is_array($d) && !empty($d)) return $d;
    }
    return $default;
}

$default_activities = [
    ['id' => 'accrobranche',   'label' => 'Accrobranche',        'emoji' => '🌳', 'active' => true],
    ['id' => 'paintball',      'label' => 'Paintball',            'emoji' => '🎯', 'active' => true],
    ['id' => 'escape-game',    'label' => 'Escape Game',          'emoji' => '🔐', 'active' => true],
    ['id' => 'tir-arc',        'label' => "Tir à l'arc",          'emoji' => '🏹', 'active' => true],
    ['id' => 'parcours-filet', 'label' => 'Parcours filet',       'emoji' => '🕸️', 'active' => true],
    ['id' => 'archery-tag',    'label' => 'Archery Tag',          'emoji' => '🎯', 'active' => true],
    ['id' => 'tyrolienne',     'label' => 'Tyrolienne',           'emoji' => '⚡', 'active' => true],
    ['id' => 'orientation',    'label' => 'Orientation',          'emoji' => '🧭', 'active' => true],
    ['id' => 'laser-game',     'label' => 'Laser Game',           'emoji' => '🔫', 'active' => true],
    ['id' => 'parcours-kids',  'label' => 'Parcours Kids',        'emoji' => '👶', 'active' => true],
];

$default_transport = [
    ['id' => 'voiture', 'label' => 'En voiture', 'icon' => 'Car',   'description' => 'Parking gratuit',  'active' => true],
    ['id' => 'train',   'label' => 'En train',   'icon' => 'Train', 'description' => 'Gare à proximité', 'active' => true],
    ['id' => 'bus',     'label' => 'En bus',      'icon' => 'Bus',   'description' => 'Bus ou navette',   'active' => true],
];

$default_events = [
    ['id' => 'evg',          'label' => 'EVG / EVJF',      'emoji' => '🥂', 'popular' => false, 'active' => true],
    ['id' => 'anniversaire', 'label' => 'Anniversaire',    'emoji' => '🎂', 'popular' => true,  'active' => true],
    ['id' => 'famille',      'label' => 'En famille',      'emoji' => '👨‍👩‍👧‍👦', 'popular' => false, 'active' => true],
    ['id' => 'entreprise',   'label' => 'Team Building',   'emoji' => '💼', 'popular' => false, 'active' => true],
    ['id' => 'scolaire',     'label' => 'Sortie scolaire', 'emoji' => '🏫', 'popular' => false, 'active' => true],
    ['id' => 'ami',          'label' => 'Entre amis',      'emoji' => '🤝', 'popular' => false, 'active' => true],
];

$activities  = nl_filters_get('nl_filters_activities',  $default_activities);
$transport   = nl_filters_get('nl_filters_transport',   $default_transport);
$event_types = nl_filters_get('nl_filters_event_types', $default_events);
?>

<div class="wrap nolimit-admin">
    <h1>🔍 Filtres des Parcs</h1>
    <p class="description" style="margin-bottom:20px">
        Gérez les options affichées dans la sidebar de filtres sur la page des parcs. Les items désactivés (☐) ne seront plus visibles sur le site.
    </p>

    <ul class="nl-tabs">
        <li><a href="#tab-activities" class="nl-tab active">⚡ Activités</a></li>
        <li><a href="#tab-transport"  class="nl-tab">🚗 Accessibilité</a></li>
        <li><a href="#tab-events"     class="nl-tab">🎉 Événements</a></li>
    </ul>

    <form method="post">
        <?php wp_nonce_field('nolimit_save_filters', 'filters_nonce'); ?>

        <!-- ═══════════════ TAB : ACTIVITÉS ═══════════════ -->
        <div id="tab-activities" class="nl-tab-pane active">
            <h2>⚡ Activités filtrables</h2>
            <p class="description">Ces activités apparaissent dans la section "Activités" du filtre. L'ID doit être unique (slug) et correspond au <code>parc_activities</code> ACF des parcs.</p>

            <div class="nl-card">
                <div class="nl-repeater" data-name="filter_activities">
                    <?php foreach ($activities as $i => $a): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <label class="nl-check-inline" title="Visible sur le site">
                            <input type="checkbox"
                                   name="filter_activities[<?php echo $i; ?>][active]"
                                   value="1"
                                   <?php checked(!empty($a['active'])); ?>>
                            Actif
                        </label>
                        <input type="text"
                               name="filter_activities[<?php echo $i; ?>][emoji]"
                               value="<?php echo esc_attr($a['emoji'] ?? '⭐'); ?>"
                               placeholder="Emoji"
                               class="nl-field-xs">
                        <input type="text"
                               name="filter_activities[<?php echo $i; ?>][label]"
                               value="<?php echo esc_attr($a['label'] ?? ''); ?>"
                               placeholder="Libellé affiché"
                               class="nl-field-md">
                        <input type="text"
                               name="filter_activities[<?php echo $i; ?>][id]"
                               value="<?php echo esc_attr($a['id'] ?? ''); ?>"
                               placeholder="id (slug, ex: accrobranche)"
                               class="nl-field-md"
                               style="font-family:monospace;font-size:11px;color:#666;">
                        <button type="button" class="button nl-remove-row" title="Supprimer">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button"
                        class="button nl-add-row"
                        data-target="filter_activities"
                        data-fields='["emoji|Emoji|xs","label|Libellé|md","id|ID slug|md"]'>
                    ＋ Ajouter une activité
                </button>
            </div>
        </div>

        <!-- ═══════════════ TAB : TRANSPORT ═══════════════ -->
        <div id="tab-transport" class="nl-tab-pane">
            <h2>🚗 Options de transport / accessibilité</h2>
            <p class="description">Ces options apparaissent dans la section "Accessibilité" du filtre. L'icône est le nom d'un composant <strong>Lucide React</strong> (ex: <code>Car</code>, <code>Train</code>, <code>Bus</code>, <code>Bike</code>).</p>

            <div class="nl-card">
                <div class="nl-repeater" data-name="filter_transport">
                    <?php foreach ($transport as $i => $t): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <label class="nl-check-inline">
                            <input type="checkbox"
                                   name="filter_transport[<?php echo $i; ?>][active]"
                                   value="1"
                                   <?php checked(!empty($t['active'])); ?>>
                            Actif
                        </label>
                        <input type="text"
                               name="filter_transport[<?php echo $i; ?>][label]"
                               value="<?php echo esc_attr($t['label'] ?? ''); ?>"
                               placeholder="Libellé (ex: En voiture)"
                               class="nl-field-md">
                        <input type="text"
                               name="filter_transport[<?php echo $i; ?>][description]"
                               value="<?php echo esc_attr($t['description'] ?? ''); ?>"
                               placeholder="Sous-texte (ex: Parking gratuit)"
                               class="nl-field-md">
                        <input type="text"
                               name="filter_transport[<?php echo $i; ?>][icon]"
                               value="<?php echo esc_attr($t['icon'] ?? 'Car'); ?>"
                               placeholder="Icône Lucide (Car, Train, Bus…)"
                               class="nl-field-sm"
                               style="font-family:monospace;font-size:11px;">
                        <input type="hidden"
                               name="filter_transport[<?php echo $i; ?>][id]"
                               value="<?php echo esc_attr($t['id'] ?? ''); ?>">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button"
                        class="button nl-add-row"
                        data-target="filter_transport"
                        data-fields='["label|Libellé|md","description|Sous-texte|md","icon|Icône Lucide|sm"]'>
                    ＋ Ajouter un moyen de transport
                </button>
            </div>
        </div>

        <!-- ═══════════════ TAB : ÉVÉNEMENTS ═══════════════ -->
        <div id="tab-events" class="nl-tab-pane">
            <h2>🎉 Types d'événement</h2>
            <p class="description">Ces catégories apparaissent dans la section "Votre événement" du filtre. Cochez "Populaire" pour ajouter une étoile ⭐ au label.</p>

            <div class="nl-card">
                <div class="nl-repeater" data-name="filter_event_types">
                    <?php foreach ($event_types as $i => $e): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <label class="nl-check-inline">
                            <input type="checkbox"
                                   name="filter_event_types[<?php echo $i; ?>][active]"
                                   value="1"
                                   <?php checked(!empty($e['active'])); ?>>
                            Actif
                        </label>
                        <input type="text"
                               name="filter_event_types[<?php echo $i; ?>][emoji]"
                               value="<?php echo esc_attr($e['emoji'] ?? '🎉'); ?>"
                               placeholder="Emoji"
                               class="nl-field-xs">
                        <input type="text"
                               name="filter_event_types[<?php echo $i; ?>][label]"
                               value="<?php echo esc_attr($e['label'] ?? ''); ?>"
                               placeholder="Libellé (ex: Anniversaire)"
                               class="nl-field-md">
                        <input type="text"
                               name="filter_event_types[<?php echo $i; ?>][id]"
                               value="<?php echo esc_attr($e['id'] ?? ''); ?>"
                               placeholder="ID slug"
                               class="nl-field-sm"
                               style="font-family:monospace;font-size:11px;color:#666;">
                        <label class="nl-check-inline">
                            <input type="checkbox"
                                   name="filter_event_types[<?php echo $i; ?>][popular]"
                                   value="1"
                                   <?php checked(!empty($e['popular'])); ?>>
                            ⭐ Populaire
                        </label>
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button"
                        class="button nl-add-row"
                        data-target="filter_event_types"
                        data-fields='["emoji|Emoji|xs","label|Libellé|md","id|ID slug|sm"]'>
                    ＋ Ajouter un type d'événement
                </button>
            </div>
        </div>

        <!-- SUBMIT -->
        <p class="submit" style="margin-top:30px">
            <button type="submit" name="save_filters" class="button button-primary button-hero">
                💾 Sauvegarder les filtres
            </button>
        </p>
    </form>
</div>
