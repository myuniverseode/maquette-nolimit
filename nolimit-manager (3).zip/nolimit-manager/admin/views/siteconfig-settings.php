<?php if (!defined('ABSPATH')) exit;

function nl_sc_items(string $key, array $default = []): array {
    $raw = get_option($key, '');
    if ($raw && is_string($raw)) { $d = json_decode($raw, true); if (is_array($d) && !empty($d)) return $d; }
    if (is_array($raw) && !empty($raw)) return $raw;
    return $default;
}
?>
<div class="wrap nolimit-admin">
    <h1>⚙️ Configuration Globale du Site</h1>
    <p class="description">Paramètres transversaux du site : réseaux sociaux, menus, filtres, services, tarifs, niveaux, publics.</p>

    <ul class="nl-tabs">
        <li><a href="#tab-social" class="nl-tab active">📱 Réseaux</a></li>
        <li><a href="#tab-anchors" class="nl-tab">⚓ Menus ancrage</a></li>
        <li><a href="#tab-filters" class="nl-tab">🔍 Filtres</a></li>
        <li><a href="#tab-access" class="nl-tab">♿ Accessibilité</a></li>
        <li><a href="#tab-services" class="nl-tab">🏪 Services</a></li>
        <li><a href="#tab-pricing" class="nl-tab">💰 Tarifs</a></li>
        <li><a href="#tab-transport" class="nl-tab">🚗 Transports</a></li>
        <li><a href="#tab-levels" class="nl-tab">📊 Niveaux</a></li>
        <li><a href="#tab-audience" class="nl-tab">👥 Publics</a></li>
    </ul>

    <form method="post">
        <?php wp_nonce_field('nolimit_save_siteconfig', 'siteconfig_nonce'); ?>

        <!-- SOCIAL -->
        <div id="tab-social" class="nl-tab-pane active">
            <h2>📱 Réseaux sociaux complémentaires</h2>
            <p class="nl-info">Facebook, Instagram, YouTube et Twitter sont dans <strong>Paramètres → Header & Footer</strong>. Ajoutez ici les autres.</p>
            <table class="form-table">
                <tr><th>TikTok</th><td><input type="url" name="social_tiktok" value="<?php echo esc_attr(get_option('nl_social_tiktok', '')); ?>" class="regular-text" placeholder="https://tiktok.com/@..."></td></tr>
                <tr><th>LinkedIn</th><td><input type="url" name="social_linkedin" value="<?php echo esc_attr(get_option('nl_social_linkedin', '')); ?>" class="regular-text" placeholder="https://linkedin.com/company/..."></td></tr>
            </table>
        </div>

        <!-- ANCHORS -->
        <div id="tab-anchors" class="nl-tab-pane">
            <h2>⚓ Menu d'ancrage (Homepage)</h2>
            <p class="description">Les liens de navigation rapide affichés sur la page d'accueil.</p>
            <?php $anchors = nl_sc_items('nl_anchor_menu', []); ?>
            <div class="nl-repeater" data-name="anchor_menu">
                <?php foreach ($anchors as $i => $a): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="anchor_menu[<?php echo $i; ?>][id]" value="<?php echo esc_attr($a['id'] ?? ''); ?>" placeholder="ID (ex: parcs)" class="nl-field-sm">
                    <input type="text" name="anchor_menu[<?php echo $i; ?>][label]" value="<?php echo esc_attr($a['label'] ?? ''); ?>" placeholder="Label affiché" class="nl-field-md">
                    <input type="text" name="anchor_menu[<?php echo $i; ?>][section]" value="<?php echo esc_attr($a['section'] ?? ''); ?>" placeholder="Section cible" class="nl-field-sm">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="anchor_menu" data-fields='["id|ID (ex: parcs)|sm","label|Label affiché|md","section|Section cible|sm"]'>＋ Ajouter</button>

            <h3 style="margin-top:30px;">⚓ Menus par parc</h3>
            <p class="description">Personnalisez le menu de chaque page parc. Si vide, un menu par défaut est utilisé.</p>
            <?php
            $parcs = get_posts(['post_type' => 'nolimit_parc', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']);
            foreach ($parcs as $parc):
                $parc_slug = function_exists('get_field') ? (get_field('parc_slug', $parc->ID) ?: sanitize_title($parc->post_title)) : sanitize_title($parc->post_title);
                $option_key = 'nl_park_' . $parc_slug . '_anchor_menu';
                $park_anchors = nl_sc_items($option_key, []);
            ?>
            <div class="nl-card">
                <h3><?php echo esc_html($parc->post_title); ?> <code style="font-size:11px;color:#999;"><?php echo $parc_slug; ?></code></h3>
                <div class="nl-repeater" data-name="park_anchor_<?php echo esc_attr($parc_slug); ?>">
                    <?php foreach ($park_anchors as $i => $a): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="park_anchor_<?php echo esc_attr($parc_slug); ?>[<?php echo $i; ?>][id]" value="<?php echo esc_attr($a['id'] ?? ''); ?>" placeholder="ID" class="nl-field-sm">
                        <input type="text" name="park_anchor_<?php echo esc_attr($parc_slug); ?>[<?php echo $i; ?>][label]" value="<?php echo esc_attr($a['label'] ?? ''); ?>" placeholder="Label" class="nl-field-md">
                        <input type="text" name="park_anchor_<?php echo esc_attr($parc_slug); ?>[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($a['icon'] ?? ''); ?>" placeholder="Icône (Lucide)" class="nl-field-sm">
                        <input type="text" name="park_anchor_<?php echo esc_attr($parc_slug); ?>[<?php echo $i; ?>][section]" value="<?php echo esc_attr($a['section'] ?? ''); ?>" placeholder="Section" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="park_anchor_<?php echo esc_attr($parc_slug); ?>" data-fields='["id|ID|sm","label|Label|md","icon|Icône|sm","section|Section|sm"]'>＋ Ajouter</button>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- FILTERS -->
        <div id="tab-filters" class="nl-tab-pane">
            <h2>🔍 Filtres d'activités</h2>
            <p class="description">Les onglets de filtre affichés sur la page des activités.</p>
            <?php $filters = nl_sc_items('nl_activity_filters', []); ?>
            <div class="nl-repeater" data-name="activity_filters">
                <?php foreach ($filters as $i => $f): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="activity_filters[<?php echo $i; ?>][id]" value="<?php echo esc_attr($f['id'] ?? ''); ?>" placeholder="ID (ex: accrobranche)" class="nl-field-sm">
                    <input type="text" name="activity_filters[<?php echo $i; ?>][label]" value="<?php echo esc_attr($f['label'] ?? ''); ?>" placeholder="Label affiché" class="nl-field-md">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="activity_filters" data-fields='["id|ID (ex: accrobranche)|sm","label|Label affiché|md"]'>＋ Ajouter un filtre</button>
        </div>

        <!-- ACCESSIBILITY -->
        <div id="tab-access" class="nl-tab-pane">
            <h2>♿ Accessibilité</h2>
            <p class="description">Options d'accessibilité affichées sur les fiches parcs.</p>
            <?php $access = nl_sc_items('nl_accessibility', []); ?>
            <div class="nl-repeater" data-name="accessibility">
                <?php foreach ($access as $i => $a): ?>
                <div class="nl-repeater-row nl-repeater-row-multi">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="accessibility[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($a['icon'] ?? $a['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                    <input type="text" name="accessibility[<?php echo $i; ?>][label]" value="<?php echo esc_attr($a['label'] ?? ''); ?>" placeholder="Label" class="nl-field-md">
                    <input type="text" name="accessibility[<?php echo $i; ?>][detail]" value="<?php echo esc_attr($a['detail'] ?? ''); ?>" placeholder="Détail" class="nl-field-lg">
                    <label class="nl-check-inline"><input type="checkbox" name="accessibility[<?php echo $i; ?>][available]" value="1" <?php checked(!empty($a['available'])); ?>> Disponible</label>
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="accessibility" data-fields='["icon|Emoji|xs","label|Label|md","detail|Détail|lg"]'>＋ Ajouter</button>
        </div>

        <!-- SERVICES -->
        <div id="tab-services" class="nl-tab-pane">
            <h2>🏪 Services sur site</h2>
            <?php $services = nl_sc_items('nl_onsite_services', []); ?>
            <div class="nl-repeater" data-name="onsite_services">
                <?php foreach ($services as $i => $s): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="onsite_services[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($s['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                    <input type="text" name="onsite_services[<?php echo $i; ?>][label]" value="<?php echo esc_attr($s['label'] ?? ''); ?>" placeholder="Nom du service" class="nl-field-md">
                    <input type="text" name="onsite_services[<?php echo $i; ?>][sub]" value="<?php echo esc_attr($s['sub'] ?? ''); ?>" placeholder="Détail (ex: 200 places · gratuit)" class="nl-field-lg">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="onsite_services" data-fields='["icon|Emoji|xs","label|Nom du service|md","sub|Détail|lg"]'>＋ Ajouter</button>
        </div>

        <!-- PRICING -->
        <div id="tab-pricing" class="nl-tab-pane">
            <h2>💰 Types de tarification</h2>
            <?php $pricing = nl_sc_items('nl_pricing_types', []); ?>
            <div class="nl-repeater" data-name="pricing_types">
                <?php foreach ($pricing as $i => $p): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="pricing_types[<?php echo $i; ?>][name]" value="<?php echo esc_attr($p['name'] ?? ''); ?>" placeholder="Nom (ex: Individuel)" class="nl-field-md">
                    <input type="text" name="pricing_types[<?php echo $i; ?>][priceKey]" value="<?php echo esc_attr($p['priceKey'] ?? ''); ?>" placeholder="Clé prix (ex: minPrice)" class="nl-field-sm">
                    <input type="text" name="pricing_types[<?php echo $i; ?>][description]" value="<?php echo esc_attr($p['description'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="pricing_types" data-fields='["name|Nom (Individuel…)|md","priceKey|Clé prix|sm","description|Description|lg"]'>＋ Ajouter</button>
        </div>

        <!-- TRANSPORT -->
        <div id="tab-transport" class="nl-tab-pane">
            <h2>🚗 Modes de transport</h2>
            <?php $transport = nl_sc_items('nl_transport', []); ?>
            <div class="nl-repeater" data-name="transport">
                <?php foreach ($transport as $i => $t): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="transport[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($t['icon'] ?? ''); ?>" placeholder="Icône (Car, Bike…)" class="nl-field-sm">
                    <input type="text" name="transport[<?php echo $i; ?>][title]" value="<?php echo esc_attr($t['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                    <input type="text" name="transport[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($t['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="transport" data-fields='["icon|Icône (Car…)|sm","title|Titre|md","desc|Description|lg"]'>＋ Ajouter</button>
        </div>

        <!-- DIFFICULTY LEVELS -->
        <div id="tab-levels" class="nl-tab-pane">
            <h2>📊 Niveaux de difficulté</h2>
            <?php $levels = nl_sc_items('nl_difficulty_levels', []); ?>
            <div class="nl-repeater" data-name="difficulty_levels">
                <?php foreach ($levels as $i => $l): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="difficulty_levels[<?php echo $i; ?>][key]" value="<?php echo esc_attr($l['key'] ?? ''); ?>" placeholder="Clé (Débutant…)" class="nl-field-sm">
                    <input type="text" name="difficulty_levels[<?php echo $i; ?>][label]" value="<?php echo esc_attr($l['label'] ?? ''); ?>" placeholder="Label affiché" class="nl-field-md">
                    <input type="text" name="difficulty_levels[<?php echo $i; ?>][color]" value="<?php echo esc_attr($l['color'] ?? '#22c55e'); ?>" placeholder="Couleur" class="nl-field-sm" style="width:80px!important;">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="difficulty_levels" data-fields='["key|Clé (Débutant…)|sm","label|Label affiché|md","color|Couleur hex|sm"]'>＋ Ajouter</button>
        </div>

        <!-- AUDIENCE -->
        <div id="tab-audience" class="nl-tab-pane">
            <h2>👥 Types de publics</h2>
            <?php $audience = nl_sc_items('nl_audience_types', []); ?>
            <div class="nl-repeater" data-name="audience_types">
                <?php foreach ($audience as $i => $a): ?>
                <div class="nl-repeater-row nl-repeater-row-multi">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="audience_types[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($a['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                    <input type="text" name="audience_types[<?php echo $i; ?>][id]" value="<?php echo esc_attr($a['id'] ?? ''); ?>" placeholder="ID" class="nl-field-sm">
                    <input type="text" name="audience_types[<?php echo $i; ?>][label]" value="<?php echo esc_attr($a['label'] ?? ''); ?>" placeholder="Label" class="nl-field-md">
                    <input type="text" name="audience_types[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($a['desc'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                    <input type="text" name="audience_types[<?php echo $i; ?>][color]" value="<?php echo esc_attr($a['color'] ?? ''); ?>" placeholder="#hex" class="nl-field-xs">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="audience_types" data-fields='["emoji|Emoji|xs","id|ID|sm","label|Label|md","desc|Description|lg","color|Couleur #hex|xs"]'>＋ Ajouter</button>
        </div>

        <p class="submit" style="margin-top:30px">
            <button type="submit" name="save_siteconfig" class="button button-primary button-hero">💾 Sauvegarder la configuration</button>
        </p>
    </form>
</div>
