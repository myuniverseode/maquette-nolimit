<?php
if (!defined('ABSPATH')) exit;

/**
 * Vue admin : Bloc Texte (entre Hero et Section Parcs)
 */

// ── Sauvegarde ────────────────────────────────────────────────
if (isset($_POST['save_textbloc']) && check_admin_referer('nolimit_save_textbloc', 'textbloc_nonce')) {

    update_option('nl_textbloc_enabled', isset($_POST['textbloc_enabled']) ? 1 : 0);
    update_option('nl_textbloc_badge',   sanitize_text_field($_POST['textbloc_badge']     ?? ''));
    update_option('nl_textbloc_title',   sanitize_text_field($_POST['textbloc_title']     ?? ''));
    update_option('nl_textbloc_text',    sanitize_textarea_field($_POST['textbloc_text']  ?? ''));
    update_option('nl_textbloc_text_secondary', sanitize_textarea_field($_POST['textbloc_text_secondary'] ?? ''));
    update_option('nl_textbloc_cta_label', sanitize_text_field($_POST['textbloc_cta_label'] ?? ''));
    update_option('nl_textbloc_cta_url',   sanitize_text_field($_POST['textbloc_cta_url']   ?? ''));

    // Stats : tableau de {value, label, sublabel}
    $stats = [];
    foreach ((array) ($_POST['textbloc_stats'] ?? []) as $row) {
        $val = sanitize_text_field($row['value']    ?? '');
        $lbl = sanitize_text_field($row['label']    ?? '');
        $sub = sanitize_text_field($row['sublabel'] ?? '');
        if ($val !== '' || $lbl !== '') {
            $stats[] = ['value' => $val, 'label' => $lbl, 'sublabel' => $sub];
        }
    }
    update_option('nl_textbloc_stats', wp_json_encode($stats, JSON_UNESCAPED_UNICODE));

    echo '<div class="notice notice-success is-dismissible"><p>✅ Bloc texte sauvegardé !</p></div>';
}

// ── Lecture des options ───────────────────────────────────────
function nl_tb_get_stats(): array {
    $raw = get_option('nl_textbloc_stats', '');
    if ($raw && is_string($raw)) {
        $d = json_decode($raw, true);
        if (is_array($d) && !empty($d)) return $d;
    }
    return [
        ['value' => '5',       'label' => 'Parcs en France',      'sublabel' => 'Île-de-France & régions'],
        ['value' => '+10 000', 'label' => 'Aventuriers / an',      'sublabel' => 'Nous font confiance'    ],
        ['value' => '15+',     'label' => 'Activités différentes', 'sublabel' => 'Pour tous les niveaux'  ],
        ['value' => '4.9★',   'label' => 'Note moyenne',          'sublabel' => 'Sur +1 200 avis'         ],
    ];
}

$enabled        = get_option('nl_textbloc_enabled', 1);
$badge          = get_option('nl_textbloc_badge',   'NoLimit Aventure');
$title          = get_option('nl_textbloc_title',   "L'aventure **en pleine nature**, c'est maintenant");
$text           = get_option('nl_textbloc_text',    "Depuis plus de 10 ans...");
$text_secondary = get_option('nl_textbloc_text_secondary', "Familles, entreprises...");
$cta_label      = get_option('nl_textbloc_cta_label', 'Découvrir nos activités');
$cta_url        = get_option('nl_textbloc_cta_url',   '/activites');
$stats          = nl_tb_get_stats();
?>

<div class="wrap nolimit-admin">
    <h1>📝 Bloc Texte — Entre Hero et Parcs</h1>
    <p class="description" style="margin-bottom:20px">
        Cette section s'affiche juste après le hero et avant la liste des parcs.
        Elle présente un texte de présentation et des chiffres clés.
    </p>

    <form method="post">
        <?php wp_nonce_field('nolimit_save_textbloc', 'textbloc_nonce'); ?>

        <!-- ── Activation ── -->
        <div class="nl-card">
            <h3>⚙️ Affichage</h3>
            <table class="form-table">
                <tr>
                    <th>Activer cette section</th>
                    <td>
                        <label>
                            <input type="checkbox" name="textbloc_enabled" value="1" <?php checked($enabled, 1); ?>>
                            Afficher le bloc texte sur la page d'accueil
                        </label>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ── Contenu texte ── -->
        <div class="nl-card">
            <h3>✍️ Contenu</h3>
            <p class="description">
                Dans le <strong>titre</strong>, utilisez <code>**mot**</code> pour le mettre en vert
                et <code>~~mot~~</code> pour le mettre en orange.
            </p>
            <table class="form-table">
                <tr>
                    <th>Badge (petit label au-dessus)</th>
                    <td><input type="text" name="textbloc_badge" value="<?php echo esc_attr($badge); ?>" class="regular-text" placeholder="NoLimit Aventure"></td>
                </tr>
                <tr>
                    <th>Titre principal</th>
                    <td>
                        <input type="text" name="textbloc_title" value="<?php echo esc_attr($title); ?>" class="large-text">
                        <p class="description">Ex: <code>L'aventure **en pleine nature**, c'est maintenant</code></p>
                    </td>
                </tr>
                <tr>
                    <th>Texte principal</th>
                    <td><textarea name="textbloc_text" rows="4" class="large-text"><?php echo esc_textarea($text); ?></textarea></td>
                </tr>
                <tr>
                    <th>Texte secondaire <small>(optionnel)</small></th>
                    <td>
                        <textarea name="textbloc_text_secondary" rows="2" class="large-text"><?php echo esc_textarea($text_secondary); ?></textarea>
                        <p class="description">Affiché en gris clair sous le texte principal. Laissez vide pour masquer.</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ── Bouton CTA ── -->
        <div class="nl-card">
            <h3>🔗 Bouton (optionnel)</h3>
            <p class="description">Laissez le libellé vide pour ne pas afficher de bouton.</p>
            <table class="form-table">
                <tr>
                    <th>Libellé du bouton</th>
                    <td><input type="text" name="textbloc_cta_label" value="<?php echo esc_attr($cta_label); ?>" class="regular-text" placeholder="Découvrir nos activités"></td>
                </tr>
                <tr>
                    <th>URL du bouton</th>
                    <td><input type="text" name="textbloc_cta_url" value="<?php echo esc_attr($cta_url); ?>" class="regular-text" placeholder="/activites"></td>
                </tr>
            </table>
        </div>

        <!-- ── Stats ── -->
        <div class="nl-card">
            <h3>📊 Chiffres clés (optionnels)</h3>
            <p class="description">
                Jusqu'à 4 chiffres affichés en grille 2×2 à droite du texte.
                Laissez vide pour masquer la grille et afficher uniquement le texte (centré).
            </p>

            <div class="nl-repeater" data-name="textbloc_stats">
                <?php foreach ($stats as $i => $s): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text"
                           name="textbloc_stats[<?php echo $i; ?>][value]"
                           value="<?php echo esc_attr($s['value'] ?? ''); ?>"
                           placeholder="Valeur (ex: +10 000)"
                           class="nl-field-sm">
                    <input type="text"
                           name="textbloc_stats[<?php echo $i; ?>][label]"
                           value="<?php echo esc_attr($s['label'] ?? ''); ?>"
                           placeholder="Label (ex: Aventuriers / an)"
                           class="nl-field-md">
                    <input type="text"
                           name="textbloc_stats[<?php echo $i; ?>][sublabel]"
                           value="<?php echo esc_attr($s['sublabel'] ?? ''); ?>"
                           placeholder="Sous-label (optionnel)"
                           class="nl-field-md">
                    <button type="button" class="button nl-remove-row" title="Supprimer">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button"
                    class="button nl-add-row"
                    data-target="textbloc_stats"
                    data-fields='["value|Valeur|sm","label|Label|md","sublabel|Sous-label (optionnel)|md"]'>
                ＋ Ajouter un chiffre
            </button>
        </div>

        <!-- ── Aperçu syntaxe titre ── -->
        <div class="nl-card" style="background:#f9f9f9;">
            <h3>💡 Aide — Syntaxe du titre</h3>
            <table class="form-table" style="max-width:600px">
                <tr><td><code>**mot**</code></td><td>→ <span style="color:#357600;font-weight:bold">mot en vert</span></td></tr>
                <tr><td><code>~~mot~~</code></td><td>→ <span style="color:#eb700f;font-weight:bold">mot en orange</span></td></tr>
                <tr><td colspan="2"><em>Ex : <code>L'aventure **en pleine nature**, c'est ~~maintenant~~</code></em></td></tr>
            </table>
        </div>

        <p class="submit" style="margin-top:24px">
            <button type="submit" name="save_textbloc" class="button button-primary button-hero">
                💾 Sauvegarder le bloc texte
            </button>
        </p>
    </form>
</div>
