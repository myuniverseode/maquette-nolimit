<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap nolimit-admin">
    <h1>❓ Configuration FAQ</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_faq_config', 'faq_config_nonce'); ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>📝 Textes de la page</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="faq_title" value="<?php echo esc_attr(get_option('nl_faq_title', 'Foire Aux Questions')); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="faq_subtitle" value="<?php echo esc_attr(get_option('nl_faq_subtitle', '')); ?>" class="large-text"></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🏷️ Catégories de filtre</h2>
            <p class="description">Format : <code>id|Label affiché</code> (1 par ligne). La catégorie "Toutes" est ajoutée automatiquement.</p>
            <textarea name="faq_categories" rows="8" class="large-text" placeholder="general|Général&#10;booking|Réservation&#10;activities|Activités&#10;safety|Sécurité&#10;practical|Pratique"><?php echo esc_textarea(get_option('nl_faq_categories', "general|Général\nbooking|Réservation\nactivities|Activités\nsafety|Sécurité\npractical|Pratique")); ?></textarea>
        </div>

        <p><button type="submit" name="save_faq_config" class="button button-primary button-large">💾 Sauvegarder</button></p>
    </form>
</div>
