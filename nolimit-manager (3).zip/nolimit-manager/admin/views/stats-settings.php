<?php if (!defined('ABSPATH')) exit;
$colors = ['green' => 'Vert', 'orange' => 'Orange', 'blue' => 'Bleu', 'purple' => 'Violet'];
$icons = ['MapPin' => '📍 MapPin', 'Star' => '⭐ Star', 'Users' => '👥 Users', 'Award' => '🏆 Award', 'Trophy' => '🏅 Trophy', 'TrendingUp' => '📈 TrendingUp', 'Heart' => '❤️ Heart', 'Zap' => '⚡ Zap'];
?>
<div class="wrap nolimit-admin">
    <h1>📊 Stats & Features</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_stats', 'stats_nonce'); ?>

        <div class="card" style="max-width:1100px;margin:20px 0">
            <h2>📊 Statistiques (Grille Hero)</h2>
            <p class="description">Les 4 statistiques affichées sur le hero de la page d'accueil.</p>
            <?php for ($i = 1; $i <= 4; $i++): ?>
            <div style="border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0;background:#fafafa;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
                <div>
                    <label><strong>Valeur</strong><br><input type="text" name="stat_<?php echo $i; ?>_value" value="<?php echo esc_attr(get_option("nl_stat_{$i}_value", '')); ?>" class="regular-text" placeholder="Ex: 5, 98%, 50k+"></label>
                </div>
                <div>
                    <label><strong>Label</strong><br><input type="text" name="stat_<?php echo $i; ?>_label" value="<?php echo esc_attr(get_option("nl_stat_{$i}_label", '')); ?>" class="regular-text" placeholder="Ex: Parcs"></label>
                </div>
                <div>
                    <label><strong>Sous-label</strong><br><input type="text" name="stat_<?php echo $i; ?>_sublabel" value="<?php echo esc_attr(get_option("nl_stat_{$i}_sublabel", '')); ?>" class="regular-text" placeholder="Ex: en France"></label>
                </div>
                <div>
                    <label><strong>Icône</strong><br>
                    <select name="stat_<?php echo $i; ?>_icon">
                        <?php foreach ($icons as $val => $lbl): ?>
                            <option value="<?php echo $val; ?>" <?php selected(get_option("nl_stat_{$i}_icon", 'Star'), $val); ?>><?php echo $lbl; ?></option>
                        <?php endforeach; ?>
                    </select></label>
                </div>
                <div>
                    <label><strong>Tendance</strong><br><input type="text" name="stat_<?php echo $i; ?>_trend" value="<?php echo esc_attr(get_option("nl_stat_{$i}_trend", '')); ?>" class="regular-text" placeholder="Ex: +15% vs 2023"></label>
                </div>
                <div>
                    <label><strong>Couleur</strong><br>
                    <select name="stat_<?php echo $i; ?>_color">
                        <?php foreach ($colors as $val => $lbl): ?>
                            <option value="<?php echo $val; ?>" <?php selected(get_option("nl_stat_{$i}_color", 'green'), $val); ?>><?php echo $lbl; ?></option>
                        <?php endforeach; ?>
                    </select></label>
                </div>
            </div>
            <?php endfor; ?>
        </div>

        <div class="card" style="max-width:1100px;margin:20px 0">
            <h2>🛡️ Features (Bandeau sous le Hero)</h2>
            <p class="description">Les 3 points forts affichés sous le carousel.</p>
            <?php for ($i = 1; $i <= 3; $i++): ?>
            <div style="border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0;background:#fafafa;">
                <table class="form-table" style="margin:0;">
                    <tr><th>Icône</th><td><input type="text" name="feature_<?php echo $i; ?>_icon" value="<?php echo esc_attr(get_option("nl_feature_{$i}_icon", '')); ?>" class="regular-text" placeholder="shield, users, leaf, star..."></td></tr>
                    <tr><th>Titre</th><td><input type="text" name="feature_<?php echo $i; ?>_title" value="<?php echo esc_attr(get_option("nl_feature_{$i}_title", '')); ?>" class="large-text"></td></tr>
                    <tr><th>Description</th><td><input type="text" name="feature_<?php echo $i; ?>_desc" value="<?php echo esc_attr(get_option("nl_feature_{$i}_desc", '')); ?>" class="large-text"></td></tr>
                </table>
            </div>
            <?php endfor; ?>
        </div>

        <p><button type="submit" name="save_stats" class="button button-primary button-large">💾 Sauvegarder</button></p>
    </form>
</div>
