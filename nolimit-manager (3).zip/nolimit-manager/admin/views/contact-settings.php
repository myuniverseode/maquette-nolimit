<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap nolimit-admin">
    <h1>📞 Page Contact</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_contact', 'contact_nonce'); ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>📝 Textes de la page</h2>
            <table class="form-table">
                <tr><th>Titre</th><td><input type="text" name="contact_title" value="<?php echo esc_attr(get_option('nl_contact_title', 'Contactez-nous')); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="contact_subtitle" value="<?php echo esc_attr(get_option('nl_contact_subtitle', '')); ?>" class="large-text"></td></tr>
                <tr><th>Adresse</th><td><textarea name="contact_address" rows="2" class="large-text"><?php echo esc_textarea(get_option('nl_contact_address', '')); ?></textarea></td></tr>
                <tr><th>Horaires affichés</th><td><input type="text" name="contact_hours" value="<?php echo esc_attr(get_option('nl_contact_hours', '')); ?>" class="large-text"></td></tr>
                <tr><th>URL Google Maps (embed)</th><td><input type="url" name="contact_map_url" value="<?php echo esc_attr(get_option('nl_contact_map_url', '')); ?>" class="large-text" placeholder="https://www.google.com/maps/embed?..."></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>📋 Formulaire</h2>
            <table class="form-table">
                <tr><th>Sujets possibles<br><small>(1 par ligne)</small></th><td><textarea name="contact_subjects" rows="6" class="large-text"><?php echo esc_textarea(get_option('nl_contact_subjects', "Information générale\nRéservation\nGroupe / Événement\nRéclamation\nPartenariat\nAutre")); ?></textarea></td></tr>
                <tr><th>Message de succès</th><td><input type="text" name="contact_success_msg" value="<?php echo esc_attr(get_option('nl_contact_success_msg', 'Message envoyé avec succès !')); ?>" class="large-text"></td></tr>
            </table>
            <p class="description">📧 L'email de réception est celui configuré dans Paramètres → Footer → Email : <strong><?php echo esc_html(get_option('nl_f_email', get_option('admin_email'))); ?></strong></p>
        </div>

        <p><button type="submit" name="save_contact" class="button button-primary button-large">💾 Sauvegarder</button></p>
    </form>
</div>
