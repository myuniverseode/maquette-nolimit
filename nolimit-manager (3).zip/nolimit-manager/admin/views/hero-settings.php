<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap nolimit-admin">
    <h1>🎠 Hero / Carousel</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_hero', 'hero_nonce'); ?>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🏷️ Badge & Titre principal</h2>
            <table class="form-table">
                <tr><th>Texte du badge</th><td><input type="text" name="badge_text" value="<?php echo esc_attr(get_option('nl_hero_badge_text', "L'aventure commence ici")); ?>" class="large-text"></td></tr>
                <tr><th>Icône du badge</th><td><input type="text" name="badge_icon" value="<?php echo esc_attr(get_option('nl_hero_badge_icon', 'Sparkles')); ?>" class="regular-text"><br><small>Nom Lucide React : Sparkles, Star, Zap, Heart...</small></td></tr>
                <tr><th>Titre ligne 1</th><td><input type="text" name="main_line1" value="<?php echo esc_attr(get_option('nl_hero_main_line1', "L'aventure vous")); ?>" class="large-text"></td></tr>
                <tr><th>Mot mis en avant</th><td><input type="text" name="main_highlight" value="<?php echo esc_attr(get_option('nl_hero_main_highlight', 'appelle')); ?>" class="regular-text"></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🎬 Vidéo</h2>
            <table class="form-table">
                <tr><th>URL vidéo</th><td><input type="url" name="video_url" value="<?php echo esc_attr(get_option('nl_hero_video_url', '')); ?>" class="large-text" placeholder="https://youtube.com/..."></td></tr>
                <tr><th>Miniature vidéo</th><td>
                    <input type="hidden" name="video_thumb_id" id="video_thumb_id" value="<?php echo esc_attr(get_option('nl_hero_video_thumb_id', 0)); ?>">
                    <button type="button" class="button" onclick="selectImage('video_thumb_id')">Choisir</button>
                </td></tr>
                <tr><th>Texte bouton</th><td><input type="text" name="video_btn" value="<?php echo esc_attr(get_option('nl_hero_video_btn', 'Voir la vidéo')); ?>" class="regular-text"></td></tr>
                <tr><th>Description</th><td><input type="text" name="video_desc" value="<?php echo esc_attr(get_option('nl_hero_video_desc', "Découvrez l'expérience")); ?>" class="large-text"></td></tr>
            </table>
        </div>

        <div class="card" style="max-width:1000px;margin:20px 0">
            <h2>🖼️ Slides du Carousel (max 5)</h2>
            <?php for ($i = 1; $i <= 5; $i++):
                $img_id = get_option("nl_hero_slide_{$i}_image_id", 0);
                $img_url = $img_id ? wp_get_attachment_url($img_id) : '';
            ?>
            <div style="border:1px solid #ddd;border-radius:8px;padding:16px;margin:12px 0;background:#fafafa;">
                <h3>Slide <?php echo $i; ?></h3>
                <table class="form-table" style="margin:0;">
                    <tr><th>Image</th><td>
                        <input type="hidden" name="slide_<?php echo $i; ?>_image_id" id="slide_<?php echo $i; ?>_image_id" value="<?php echo esc_attr($img_id); ?>">
                        <button type="button" class="button" onclick="selectImage('slide_<?php echo $i; ?>_image_id')">📁 Choisir</button>
                        <?php if ($img_url): ?><br><img src="<?php echo esc_url($img_url); ?>" style="max-width:200px;margin-top:8px;border-radius:4px;"><?php endif; ?>
                    </td></tr>
                    <tr><th>Titre</th><td><input type="text" name="slide_<?php echo $i; ?>_title" value="<?php echo esc_attr(get_option("nl_hero_slide_{$i}_title", '')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="slide_<?php echo $i; ?>_subtitle" value="<?php echo esc_attr(get_option("nl_hero_slide_{$i}_subtitle", '')); ?>" class="large-text"></td></tr>
                </table>
            </div>
            <?php endfor; ?>
        </div>

        <p><button type="submit" name="save_hero" class="button button-primary button-large">💾 Sauvegarder</button></p>
    </form>
</div>
<script>
function selectImage(fieldId) {
    var frame = wp.media({ title: 'Choisir une image', multiple: false, library: { type: 'image' }});
    frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        document.getElementById(fieldId).value = attachment.id;
    });
    frame.open();
}
</script>
