<?php
if (!defined('ABSPATH')) exit;

function nl_ab_items(string $key, array $default = []): array {
    $raw = get_option($key, '');
    if ($raw && is_string($raw)) { $d = json_decode($raw, true); if (is_array($d) && !empty($d)) return $d; }
    if (is_array($raw) && !empty($raw)) return $raw;
    return $default;
}

// ─── Save handler (self-contained in the view) ─────────────
if (isset($_POST['save_about']) && check_admin_referer('nolimit_save_about', 'about_nonce')) {
    $text_fields = [
        'nl_about_hero_badge', 'nl_about_hero_title', 'nl_about_hero_subtitle',
        'nl_about_cta1_text', 'nl_about_cta1_link', 'nl_about_cta2_text', 'nl_about_cta2_link',
        'nl_about_hub_badge', 'nl_about_hub_title',
        'nl_hist_hero_badge', 'nl_hist_hero_h1', 'nl_hist_hero_h1accent', 'nl_hist_hero_intro',
        'nl_hist_timeline_title', 'nl_hist_timeline_subtitle',
        'nl_hist_vision_badge', 'nl_hist_vision_title', 'nl_hist_vision_subtitle',
        'nl_hist_vision_cta_text', 'nl_hist_vision_cta_link',
        'nl_about_history_title', 'nl_about_history_subtitle', 'nl_about_vision',
        'nl_val_hero_badge', 'nl_val_hero_h1', 'nl_val_hero_h1accent', 'nl_val_hero_intro',
        'nl_val_values_title', 'nl_val_manifesto_title', 'nl_val_manifesto_subtitle',
        'nl_about_values_title', 'nl_about_values_subtitle',
        'nl_jobs_hero_badge', 'nl_jobs_hero_h1', 'nl_jobs_hero_h1accent', 'nl_jobs_hero_intro',
        'nl_jobs_perks_title', 'nl_jobs_perks_subtitle', 'nl_jobs_positions_title',
        'nl_jobs_spont_title', 'nl_jobs_spont_subtitle', 'nl_jobs_cta_button',
        'nl_jobs_confirmed_title', 'nl_jobs_confirmed_text',
        'nl_about_jobs_title', 'nl_about_jobs_subtitle',
        'nl_about_jobs_email', 'nl_about_jobs_spontaneous_text',
        'nl_part_hero_badge', 'nl_part_hero_h1', 'nl_part_hero_h1accent', 'nl_part_hero_intro',
        'nl_part_section_title', 'nl_part_section_subtitle',
        'nl_part_become_title', 'nl_part_become_subtitle', 'nl_part_become_cta',
        'nl_part_confirmed_title', 'nl_part_confirmed_text',
        'nl_about_partners_title', 'nl_about_partners_subtitle',
        'nl_about_rse_title', 'nl_about_rse_subtitle',
    ];
    foreach ($text_fields as $field) {
        if (isset($_POST[$field])) update_option($field, sanitize_text_field($_POST[$field]));
    }
    update_option('nl_about_jobs_spontaneous', isset($_POST['nl_about_jobs_spontaneous']) ? 1 : 0);

    // Repeater fields → serialize to JSON
    $repeater_fields = [
        'nl_about_nav_cards', 'nl_about_stats',
        'nl_about_timeline', 'nl_about_history_stats', 'nl_about_vision_metrics',
        'nl_about_values', 'nl_about_manifesto',
        'nl_about_perks', 'nl_about_positions',
        'nl_about_partners', 'nl_about_rse',
    ];
    foreach ($repeater_fields as $field) {
        $raw = $_POST[$field] ?? [];
        if (is_string($raw)) {
            // Legacy JSON fallback
            $decoded = json_decode(stripslashes($raw), true);
            if (is_array($decoded)) update_option($field, wp_json_encode($decoded, JSON_UNESCAPED_UNICODE));
            continue;
        }
        if (!is_array($raw) || empty($raw)) { update_option($field, '[]'); continue; }
        $items = [];
        foreach ($raw as $row) {
            if (is_string($row)) {
                $v = sanitize_text_field(trim($row));
                if ($v !== '') $items[] = $v;
            } elseif (is_array($row)) {
                $clean = []; $has = false;
                foreach ($row as $k => $v) { $cv = sanitize_text_field(trim($v)); $clean[$k] = $cv; if ($cv !== '') $has = true; }
                if ($has) $items[] = $clean;
            }
        }
        update_option($field, wp_json_encode(array_values($items), JSON_UNESCAPED_UNICODE));
    }

    echo '<div class="notice notice-success is-dismissible"><p>✅ Paramètres "À propos" enregistrés.</p></div>';
}

function nl_ab_opt($key, $default = '') { return get_option($key, $default); }
?>

<div class="wrap nolimit-admin">
    <h1>📖 Pages "À Propos"</h1>

    <ul class="nl-tabs">
        <li><a href="#tab-main" class="nl-tab active">🏠 Principale</a></li>
        <li><a href="#tab-history" class="nl-tab">📜 Histoire</a></li>
        <li><a href="#tab-values" class="nl-tab">💎 Valeurs</a></li>
        <li><a href="#tab-jobs" class="nl-tab">💼 Emplois</a></li>
        <li><a href="#tab-partners" class="nl-tab">🤝 Partenaires</a></li>
    </ul>

    <form method="post">
        <?php wp_nonce_field('nolimit_save_about', 'about_nonce'); ?>

        <!-- ═══ MAIN ═══ -->
        <div id="tab-main" class="nl-tab-pane active">
            <h2>🏠 Page principale À Propos</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Badge</th><td><input type="text" name="nl_about_hero_badge" value="<?php echo esc_attr(nl_ab_opt('nl_about_hero_badge', 'Depuis 2015 · Leader')); ?>" class="regular-text"></td></tr>
                    <tr><th>Titre</th><td><input type="text" name="nl_about_hero_title" value="<?php echo esc_attr(nl_ab_opt('nl_about_hero_title', 'On est NoLimit.')); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><textarea name="nl_about_hero_subtitle" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_about_hero_subtitle', '')); ?></textarea></td></tr>
                    <tr><th>CTA 1 — Texte</th><td><input type="text" name="nl_about_cta1_text" value="<?php echo esc_attr(nl_ab_opt('nl_about_cta1_text', 'Notre histoire')); ?>" class="regular-text"></td></tr>
                    <tr><th>CTA 1 — Lien</th><td><input type="text" name="nl_about_cta1_link" value="<?php echo esc_attr(nl_ab_opt('nl_about_cta1_link', '/about/histoire')); ?>" class="regular-text"></td></tr>
                    <tr><th>CTA 2 — Texte</th><td><input type="text" name="nl_about_cta2_text" value="<?php echo esc_attr(nl_ab_opt('nl_about_cta2_text', 'Découvrir nos parcs')); ?>" class="regular-text"></td></tr>
                    <tr><th>CTA 2 — Lien</th><td><input type="text" name="nl_about_cta2_link" value="<?php echo esc_attr(nl_ab_opt('nl_about_cta2_link', '/parcs')); ?>" class="regular-text"></td></tr>
                    <tr><th>Badge hub</th><td><input type="text" name="nl_about_hub_badge" value="<?php echo esc_attr(nl_ab_opt('nl_about_hub_badge', 'Tout sur NoLimit')); ?>" class="regular-text"></td></tr>
                    <tr><th>Titre hub</th><td><input type="text" name="nl_about_hub_title" value="<?php echo esc_attr(nl_ab_opt('nl_about_hub_title', 'Explorez notre univers')); ?>" class="regular-text"></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>🗂️ Cartes de navigation</h3>
                <p class="description">Les cartes affichées sur la page principale pour accéder aux sous-pages.</p>
                <?php $nav_cards = nl_ab_items('nl_about_nav_cards', []); ?>
                <div class="nl-repeater" data-name="nl_about_nav_cards">
                    <?php foreach ($nav_cards as $i => $c): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_nav_cards[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($c['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="nl_about_nav_cards[<?php echo $i; ?>][title]" value="<?php echo esc_attr($c['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="nl_about_nav_cards[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($c['desc'] ?? $c['description'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <input type="text" name="nl_about_nav_cards[<?php echo $i; ?>][link]" value="<?php echo esc_attr($c['link'] ?? ''); ?>" placeholder="Lien (ex: /about/histoire)" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_nav_cards" data-fields='["emoji|Emoji|xs","title|Titre|md","desc|Description|lg","link|Lien|sm"]'>＋ Ajouter une carte</button>
            </div>

            <div class="nl-card">
                <h3>📊 Statistiques principales</h3>
                <?php $stats = nl_ab_items('nl_about_stats', []); ?>
                <div class="nl-repeater" data-name="nl_about_stats">
                    <?php foreach ($stats as $i => $s): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_stats[<?php echo $i; ?>][value]" value="<?php echo esc_attr($s['value'] ?? $s['val'] ?? ''); ?>" placeholder="Valeur (ex: 5)" class="nl-field-sm">
                        <input type="text" name="nl_about_stats[<?php echo $i; ?>][label]" value="<?php echo esc_attr($s['label'] ?? ''); ?>" placeholder="Label (ex: Parcs)" class="nl-field-md">
                        <input type="text" name="nl_about_stats[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($s['icon'] ?? ''); ?>" placeholder="Icône" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_stats" data-fields='["value|Valeur|sm","label|Label|md","icon|Icône|sm"]'>＋ Ajouter</button>
            </div>
        </div>

        <!-- ═══ HISTORY ═══ -->
        <div id="tab-history" class="nl-tab-pane">
            <h2>📜 Page Histoire</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Badge</th><td><input type="text" name="nl_hist_hero_badge" value="<?php echo esc_attr(nl_ab_opt('nl_hist_hero_badge', '🏔️ Notre Histoire')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (partie 1)</th><td><input type="text" name="nl_hist_hero_h1" value="<?php echo esc_attr(nl_ab_opt('nl_hist_hero_h1', '10 ans')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (accent)</th><td><input type="text" name="nl_hist_hero_h1accent" value="<?php echo esc_attr(nl_ab_opt('nl_hist_hero_h1accent', "d'aventure.")); ?>" class="regular-text"></td></tr>
                    <tr><th>Intro</th><td><textarea name="nl_hist_hero_intro" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_hist_hero_intro', '')); ?></textarea></td></tr>
                    <tr><th>Titre timeline</th><td><input type="text" name="nl_hist_timeline_title" value="<?php echo esc_attr(nl_ab_opt('nl_hist_timeline_title', 'Notre timeline')); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre timeline</th><td><input type="text" name="nl_hist_timeline_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_hist_timeline_subtitle', 'Une étape à la fois.')); ?>" class="regular-text"></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>📅 Timeline</h3>
                <p class="description">Les grandes étapes de votre histoire, dans l'ordre chronologique.</p>
                <?php $timeline = nl_ab_items('nl_about_timeline', []); ?>
                <div class="nl-repeater" data-name="nl_about_timeline">
                    <?php foreach ($timeline as $i => $t): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_timeline[<?php echo $i; ?>][year]" value="<?php echo esc_attr($t['year'] ?? ''); ?>" placeholder="Année" class="nl-field-xs">
                        <input type="text" name="nl_about_timeline[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($t['emoji'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="nl_about_timeline[<?php echo $i; ?>][title]" value="<?php echo esc_attr($t['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="nl_about_timeline[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($t['desc'] ?? $t['description'] ?? ''); ?>" placeholder="Description" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_timeline" data-fields='["year|Année|xs","emoji|Emoji|xs","title|Titre|md","desc|Description|xl"]'>＋ Ajouter une étape</button>
            </div>

            <div class="nl-card">
                <h3>📊 Stats de la page histoire</h3>
                <?php $hist_stats = nl_ab_items('nl_about_history_stats', []); ?>
                <div class="nl-repeater" data-name="nl_about_history_stats">
                    <?php foreach ($hist_stats as $i => $s): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_history_stats[<?php echo $i; ?>][value]" value="<?php echo esc_attr($s['value'] ?? $s['val'] ?? ''); ?>" placeholder="Valeur" class="nl-field-sm">
                        <input type="text" name="nl_about_history_stats[<?php echo $i; ?>][label]" value="<?php echo esc_attr($s['label'] ?? ''); ?>" placeholder="Label" class="nl-field-md">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_history_stats" data-fields='["value|Valeur|sm","label|Label|md"]'>＋ Ajouter</button>
            </div>

            <div class="nl-card">
                <h3>🔭 Vision</h3>
                <table class="form-table">
                    <tr><th>Badge</th><td><input type="text" name="nl_hist_vision_badge" value="<?php echo esc_attr(nl_ab_opt('nl_hist_vision_badge', 'Notre vision 2027')); ?>" class="regular-text"></td></tr>
                    <tr><th>Titre</th><td><input type="text" name="nl_hist_vision_title" value="<?php echo esc_attr(nl_ab_opt('nl_hist_vision_title', 'Leader national du parc aventure.')); ?>" class="large-text"></td></tr>
                    <tr><th>Description</th><td><textarea name="nl_hist_vision_subtitle" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_hist_vision_subtitle', '')); ?></textarea></td></tr>
                    <tr><th>CTA texte</th><td><input type="text" name="nl_hist_vision_cta_text" value="<?php echo esc_attr(nl_ab_opt('nl_hist_vision_cta_text', 'Voir nos parcs')); ?>" class="regular-text"></td></tr>
                    <tr><th>CTA lien</th><td><input type="text" name="nl_hist_vision_cta_link" value="<?php echo esc_attr(nl_ab_opt('nl_hist_vision_cta_link', '/about/parcs')); ?>" class="regular-text"></td></tr>
                    <tr><th>Vision (texte long)</th><td><textarea name="nl_about_vision" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_about_vision', '')); ?></textarea></td></tr>
                </table>

                <h4>Métriques vision</h4>
                <?php $vision_metrics = nl_ab_items('nl_about_vision_metrics', []); ?>
                <div class="nl-repeater" data-name="nl_about_vision_metrics">
                    <?php foreach ($vision_metrics as $i => $m): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_vision_metrics[<?php echo $i; ?>][value]" value="<?php echo esc_attr($m['value'] ?? $m['val'] ?? ''); ?>" placeholder="Valeur" class="nl-field-sm">
                        <input type="text" name="nl_about_vision_metrics[<?php echo $i; ?>][label]" value="<?php echo esc_attr($m['label'] ?? ''); ?>" placeholder="Label" class="nl-field-md">
                        <input type="text" name="nl_about_vision_metrics[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($m['icon'] ?? ''); ?>" placeholder="Icône" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_vision_metrics" data-fields='["value|Valeur|sm","label|Label|md","icon|Icône|sm"]'>＋ Ajouter</button>
            </div>
        </div>

        <!-- ═══ VALUES ═══ -->
        <div id="tab-values" class="nl-tab-pane">
            <h2>💎 Page Valeurs</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Badge</th><td><input type="text" name="nl_val_hero_badge" value="<?php echo esc_attr(nl_ab_opt('nl_val_hero_badge', '💚 Notre ADN')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (partie 1)</th><td><input type="text" name="nl_val_hero_h1" value="<?php echo esc_attr(nl_ab_opt('nl_val_hero_h1', 'Ce qui nous')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (accent)</th><td><input type="text" name="nl_val_hero_h1accent" value="<?php echo esc_attr(nl_ab_opt('nl_val_hero_h1accent', 'définit.')); ?>" class="regular-text"></td></tr>
                    <tr><th>Intro</th><td><textarea name="nl_val_hero_intro" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_val_hero_intro', '')); ?></textarea></td></tr>
                    <tr><th>Titre section</th><td><input type="text" name="nl_val_values_title" value="<?php echo esc_attr(nl_ab_opt('nl_val_values_title', 'Nos valeurs en détail')); ?>" class="regular-text"></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>💎 Nos valeurs</h3>
                <p class="description">Chaque valeur avec son emoji, titre, description et couleur.</p>
                <?php $values = nl_ab_items('nl_about_values', []); ?>
                <div class="nl-repeater" data-name="nl_about_values">
                    <?php foreach ($values as $i => $v): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_values[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($v['emoji'] ?? $v['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="nl_about_values[<?php echo $i; ?>][title]" value="<?php echo esc_attr($v['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="nl_about_values[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($v['desc'] ?? $v['description'] ?? ''); ?>" placeholder="Description" class="nl-field-xl">
                        <input type="text" name="nl_about_values[<?php echo $i; ?>][color]" value="<?php echo esc_attr($v['color'] ?? '#357600'); ?>" placeholder="#hex" class="nl-field-xs">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_values" data-fields='["emoji|Emoji|xs","title|Titre|md","desc|Description|xl","color|Couleur #hex|xs"]'>＋ Ajouter une valeur</button>
            </div>

            <div class="nl-card">
                <h3>📜 Manifesto</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="nl_val_manifesto_title" value="<?php echo esc_attr(nl_ab_opt('nl_val_manifesto_title', "Ce qu'on croit.")); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="nl_val_manifesto_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_val_manifesto_subtitle', "Des convictions qu'on ne négocie pas.")); ?>" class="regular-text"></td></tr>
                </table>
                <h4>Points du manifesto</h4>
                <p class="description">Une conviction par ligne.</p>
                <?php $manifesto = nl_ab_items('nl_about_manifesto', []); ?>
                <div class="nl-repeater nl-repeater-simple" data-name="nl_about_manifesto">
                    <?php foreach ($manifesto as $i => $m): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <?php $mval = is_string($m) ? $m : ($m['text'] ?? $m['title'] ?? ''); ?>
                        <input type="text" name="nl_about_manifesto[<?php echo $i; ?>]" value="<?php echo esc_attr($mval); ?>" placeholder="Conviction…" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row-simple" data-target="nl_about_manifesto" data-placeholder="Conviction…">＋ Ajouter</button>
            </div>
        </div>

        <!-- ═══ JOBS ═══ -->
        <div id="tab-jobs" class="nl-tab-pane">
            <h2>💼 Page Emplois</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Badge</th><td><input type="text" name="nl_jobs_hero_badge" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_hero_badge', '🧗 Nos Emplois')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (partie 1)</th><td><input type="text" name="nl_jobs_hero_h1" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_hero_h1', 'Ta passion,')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (accent)</th><td><input type="text" name="nl_jobs_hero_h1accent" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_hero_h1accent', 'ton métier.')); ?>" class="regular-text"></td></tr>
                    <tr><th>Intro</th><td><textarea name="nl_jobs_hero_intro" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_jobs_hero_intro', '')); ?></textarea></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>✨ Avantages à nous rejoindre</h3>
                <table class="form-table">
                    <tr><th>Titre section</th><td><input type="text" name="nl_jobs_perks_title" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_perks_title', 'Pourquoi nous rejoindre ?')); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="nl_jobs_perks_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_perks_subtitle', '')); ?>" class="regular-text"></td></tr>
                </table>
                <?php $perks = nl_ab_items('nl_about_perks', []); ?>
                <div class="nl-repeater" data-name="nl_about_perks">
                    <?php foreach ($perks as $i => $p): ?>
                    <div class="nl-repeater-row">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_perks[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($p['emoji'] ?? $p['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="nl_about_perks[<?php echo $i; ?>][title]" value="<?php echo esc_attr($p['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="nl_about_perks[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($p['desc'] ?? $p['description'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_perks" data-fields='["emoji|Emoji|xs","title|Titre|md","desc|Description|lg"]'>＋ Ajouter un avantage</button>
            </div>

            <div class="nl-card">
                <h3>📋 Offres d'emploi</h3>
                <table class="form-table">
                    <tr><th>Titre section</th><td><input type="text" name="nl_jobs_positions_title" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_positions_title', 'Postes à pourvoir')); ?>" class="regular-text"></td></tr>
                </table>
                <?php $positions = nl_ab_items('nl_about_positions', []); ?>
                <div class="nl-repeater" data-name="nl_about_positions">
                    <?php foreach ($positions as $i => $p): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_positions[<?php echo $i; ?>][title]" value="<?php echo esc_attr($p['title'] ?? ''); ?>" placeholder="Titre du poste" class="nl-field-md">
                        <input type="text" name="nl_about_positions[<?php echo $i; ?>][type]" value="<?php echo esc_attr($p['type'] ?? ''); ?>" placeholder="Type (CDI, CDD, Saison…)" class="nl-field-sm">
                        <input type="text" name="nl_about_positions[<?php echo $i; ?>][location]" value="<?php echo esc_attr($p['location'] ?? ''); ?>" placeholder="Lieu" class="nl-field-sm">
                        <input type="text" name="nl_about_positions[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($p['desc'] ?? $p['description'] ?? ''); ?>" placeholder="Description courte" class="nl-field-lg">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_positions" data-fields='["title|Titre du poste|md","type|Type (CDI…)|sm","location|Lieu|sm","desc|Description|lg"]'>＋ Ajouter une offre</button>
            </div>

            <div class="nl-card">
                <h3>📩 Candidature spontanée</h3>
                <table class="form-table">
                    <tr><th>Activer</th><td><input type="checkbox" name="nl_about_jobs_spontaneous" value="1" <?php checked(nl_ab_opt('nl_about_jobs_spontaneous', 1), 1); ?>></td></tr>
                    <tr><th>Titre</th><td><input type="text" name="nl_jobs_spont_title" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_spont_title', "Pas votre poste ici ? Écrivez-nous.")); ?>" class="large-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="nl_jobs_spont_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_spont_subtitle', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Bouton CTA</th><td><input type="text" name="nl_jobs_cta_button" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_cta_button', 'Envoyer ma candidature')); ?>" class="regular-text"></td></tr>
                    <tr><th>Email recrutement</th><td><input type="email" name="nl_about_jobs_email" value="<?php echo esc_attr(nl_ab_opt('nl_about_jobs_email', 'jobs@nolimit-aventure.fr')); ?>" class="regular-text"></td></tr>
                    <tr><th>Titre confirmation</th><td><input type="text" name="nl_jobs_confirmed_title" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_confirmed_title', 'Candidature reçue !')); ?>" class="regular-text"></td></tr>
                    <tr><th>Texte confirmation</th><td><input type="text" name="nl_jobs_confirmed_text" value="<?php echo esc_attr(nl_ab_opt('nl_jobs_confirmed_text', 'On revient vers vous sous 5 jours.')); ?>" class="large-text"></td></tr>
                </table>
            </div>
        </div>

        <!-- ═══ PARTNERS ═══ -->
        <div id="tab-partners" class="nl-tab-pane">
            <h2>🤝 Page Partenaires & RSE</h2>

            <div class="nl-card">
                <h3>🎬 Hero</h3>
                <table class="form-table">
                    <tr><th>Badge</th><td><input type="text" name="nl_part_hero_badge" value="<?php echo esc_attr(nl_ab_opt('nl_part_hero_badge', '🤝 Nos Partenaires')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (partie 1)</th><td><input type="text" name="nl_part_hero_h1" value="<?php echo esc_attr(nl_ab_opt('nl_part_hero_h1', 'Ensemble,')); ?>" class="regular-text"></td></tr>
                    <tr><th>H1 (accent)</th><td><input type="text" name="nl_part_hero_h1accent" value="<?php echo esc_attr(nl_ab_opt('nl_part_hero_h1accent', 'on va plus loin.')); ?>" class="regular-text"></td></tr>
                    <tr><th>Intro</th><td><textarea name="nl_part_hero_intro" rows="3" class="large-text"><?php echo esc_textarea(nl_ab_opt('nl_part_hero_intro', '')); ?></textarea></td></tr>
                    <tr><th>Titre partenaires</th><td><input type="text" name="nl_part_section_title" value="<?php echo esc_attr(nl_ab_opt('nl_part_section_title', 'Ils nous font confiance')); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="nl_part_section_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_part_section_subtitle', '')); ?>" class="regular-text"></td></tr>
                </table>
            </div>

            <div class="nl-card">
                <h3>🏢 Partenaires</h3>
                <?php $partners = nl_ab_items('nl_about_partners', []); ?>
                <div class="nl-repeater" data-name="nl_about_partners">
                    <?php foreach ($partners as $i => $p): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_partners[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($p['emoji'] ?? $p['icon'] ?? ''); ?>" placeholder="Emoji/Logo" class="nl-field-xs">
                        <input type="text" name="nl_about_partners[<?php echo $i; ?>][name]" value="<?php echo esc_attr($p['name'] ?? $p['title'] ?? ''); ?>" placeholder="Nom" class="nl-field-md">
                        <input type="text" name="nl_about_partners[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($p['desc'] ?? $p['description'] ?? ''); ?>" placeholder="Description" class="nl-field-lg">
                        <input type="text" name="nl_about_partners[<?php echo $i; ?>][url]" value="<?php echo esc_attr($p['url'] ?? $p['link'] ?? ''); ?>" placeholder="URL site web" class="nl-field-sm">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_partners" data-fields='["emoji|Emoji|xs","name|Nom|md","desc|Description|lg","url|URL|sm"]'>＋ Ajouter un partenaire</button>
            </div>

            <div class="nl-card">
                <h3>🌿 Engagements RSE</h3>
                <table class="form-table">
                    <tr><th>Titre section</th><td><input type="text" name="nl_about_rse_title" value="<?php echo esc_attr(nl_ab_opt('nl_about_rse_title', '')); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="nl_about_rse_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_about_rse_subtitle', '')); ?>" class="regular-text"></td></tr>
                </table>
                <?php $rse = nl_ab_items('nl_about_rse', []); ?>
                <div class="nl-repeater" data-name="nl_about_rse">
                    <?php foreach ($rse as $i => $r): ?>
                    <div class="nl-repeater-row nl-repeater-row-multi">
                        <span class="nl-drag">☰</span>
                        <input type="text" name="nl_about_rse[<?php echo $i; ?>][emoji]" value="<?php echo esc_attr($r['emoji'] ?? $r['icon'] ?? ''); ?>" placeholder="Emoji" class="nl-field-xs">
                        <input type="text" name="nl_about_rse[<?php echo $i; ?>][title]" value="<?php echo esc_attr($r['title'] ?? ''); ?>" placeholder="Titre" class="nl-field-md">
                        <input type="text" name="nl_about_rse[<?php echo $i; ?>][desc]" value="<?php echo esc_attr($r['desc'] ?? $r['description'] ?? ''); ?>" placeholder="Description" class="nl-field-xl">
                        <button type="button" class="button nl-remove-row">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button nl-add-row" data-target="nl_about_rse" data-fields='["emoji|Emoji|xs","title|Titre|md","desc|Description|xl"]'>＋ Ajouter un engagement</button>
            </div>

            <div class="nl-card">
                <h3>📩 Devenir partenaire</h3>
                <table class="form-table">
                    <tr><th>Titre</th><td><input type="text" name="nl_part_become_title" value="<?php echo esc_attr(nl_ab_opt('nl_part_become_title', 'Devenir partenaire.')); ?>" class="regular-text"></td></tr>
                    <tr><th>Sous-titre</th><td><input type="text" name="nl_part_become_subtitle" value="<?php echo esc_attr(nl_ab_opt('nl_part_become_subtitle', '')); ?>" class="large-text"></td></tr>
                    <tr><th>Texte bouton</th><td><input type="text" name="nl_part_become_cta" value="<?php echo esc_attr(nl_ab_opt('nl_part_become_cta', 'Envoyer ma demande')); ?>" class="regular-text"></td></tr>
                    <tr><th>Titre confirmation</th><td><input type="text" name="nl_part_confirmed_title" value="<?php echo esc_attr(nl_ab_opt('nl_part_confirmed_title', 'Demande reçue !')); ?>" class="regular-text"></td></tr>
                    <tr><th>Texte confirmation</th><td><input type="text" name="nl_part_confirmed_text" value="<?php echo esc_attr(nl_ab_opt('nl_part_confirmed_text', 'Notre responsable vous contactera sous 48h.')); ?>" class="large-text"></td></tr>
                </table>
            </div>
        </div>

        <p class="submit" style="margin-top:30px">
            <button type="submit" name="save_about" class="button button-primary button-hero">💾 Sauvegarder toutes les modifications</button>
        </p>
    </form>
</div>
