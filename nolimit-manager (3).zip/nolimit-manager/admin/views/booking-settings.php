<?php if (!defined('ABSPATH')) exit;

function nl_bk_items(string $key, array $default = []): array {
    $raw = get_option($key, '');
    if ($raw && is_string($raw)) { $d = json_decode($raw, true); if (is_array($d) && !empty($d)) return $d; }
    if (is_array($raw) && !empty($raw)) return $raw;
    return $default;
}
?>
<div class="wrap nolimit-admin">
    <h1>🎫 Réservation</h1>
    <form method="post">
        <?php wp_nonce_field('nolimit_save_booking', 'booking_nonce'); ?>

        <div class="nl-card">
            <h3>📋 Configuration générale</h3>
            <table class="form-table">
                <tr><th>Titre page</th><td><input type="text" name="booking_title" value="<?php echo esc_attr(get_option('nl_booking_title', 'Réservation')); ?>" class="large-text"></td></tr>
                <tr><th>Sous-titre</th><td><input type="text" name="booking_subtitle" value="<?php echo esc_attr(get_option('nl_booking_subtitle', '')); ?>" class="large-text"></td></tr>
                <tr><th>Réservation activée</th><td><input type="checkbox" name="booking_enabled" value="1" <?php checked(get_option('nl_booking_enabled', 1), 1); ?>> <span class="description">Décocher pour fermer les réservations</span></td></tr>
                <tr><th>Message quand fermé</th><td><input type="text" name="booking_closed_msg" value="<?php echo esc_attr(get_option('nl_booking_closed_msg', '')); ?>" class="large-text" placeholder="Les réservations sont temporairement fermées."></td></tr>
            </table>
        </div>

        <div class="nl-card">
            <h3>🔗 Quickle (système externe)</h3>
            <table class="form-table">
                <tr><th>Quickle activé</th><td><input type="checkbox" name="booking_quickle_enabled" value="1" <?php checked(get_option('nl_booking_quickle_enabled', 1), 1); ?>></td></tr>
                <tr><th>URL Quickle</th><td><input type="url" name="booking_quickle_url" value="<?php echo esc_attr(get_option('nl_booking_quickle_url', '')); ?>" class="large-text" placeholder="https://booking.quickle.fr/..."></td></tr>
            </table>
        </div>

        <div class="nl-card">
            <h3>⏰ Créneaux horaires</h3>
            <table class="form-table">
                <tr><th>Min participants</th><td><input type="number" name="booking_min_participants" value="<?php echo esc_attr(get_option('nl_booking_min_participants', 1)); ?>" min="1" style="width:80px;"></td></tr>
                <tr><th>Max participants</th><td><input type="number" name="booking_max_participants" value="<?php echo esc_attr(get_option('nl_booking_max_participants', 30)); ?>" min="1" style="width:80px;"></td></tr>
            </table>

            <h4>Créneaux disponibles</h4>
            <p class="description">Les horaires proposés lors de la réservation.</p>
            <?php $slots = nl_bk_items('nl_booking_time_slots', []); ?>
            <div class="nl-repeater" data-name="booking_time_slots">
                <?php foreach ($slots as $i => $s): ?>
                <div class="nl-repeater-row">
                    <span class="nl-drag">☰</span>
                    <input type="text" name="booking_time_slots[<?php echo $i; ?>][value]" value="<?php echo esc_attr($s['value'] ?? ''); ?>" placeholder="Valeur (ex: 09:00)" class="nl-field-sm">
                    <input type="text" name="booking_time_slots[<?php echo $i; ?>][label]" value="<?php echo esc_attr($s['label'] ?? ''); ?>" placeholder="Label affiché (ex: 9h00)" class="nl-field-md">
                    <button type="button" class="button nl-remove-row">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button nl-add-row" data-target="booking_time_slots" data-fields='["value|Valeur (09:00)|sm","label|Label (9h00)|md"]'>＋ Ajouter un créneau</button>
        </div>

        <p><button type="submit" name="save_booking" class="button button-primary button-hero">💾 Sauvegarder</button></p>
    </form>
</div>
