<?php
/**
 * Plugin Name: NoLimit Complete Manager
 * Description: Gestion COMPLÈTE du site NoLimit Aventure - Header, Footer, Pages, Activités, FAQ, Avis, etc.
 * Version: 8.0.0
 * Author: NoLimit Aventure
 * Text Domain: nolimit-manager
 */

if (!defined('ABSPATH')) exit;

define('NOLIMIT_VERSION', '8.0.0');
define('NOLIMIT_PATH', plugin_dir_path(__FILE__));
define('NOLIMIT_URL', plugin_dir_url(__FILE__));
define('NOLIMIT_API_NS', 'nolimit/v1');

/**
 * Clé API pour sécuriser les endpoints
 */
define('NOLIMIT_API_KEY', 'CHANGE_THIS_SECRET_KEY');

/**
 * ─── Core ───────────────────────────────────────────────────
 */
require_once NOLIMIT_PATH . 'includes/class-module.php';
require_once NOLIMIT_PATH . 'includes/class-helpers.php';
require_once NOLIMIT_PATH . 'includes/class-loader.php';
require_once NOLIMIT_PATH . 'includes/class-admin.php';
require_once NOLIMIT_PATH . 'includes/class-cors.php';

/**
 * ─── Boot ───────────────────────────────────────────────────
 */
add_action('plugins_loaded', function () {
    NoLimit_Loader::get_instance();
});