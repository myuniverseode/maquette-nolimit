<?php

if (!defined('ABSPATH')) exit;

class NoLimit_CORS {

    public static function init() {

        add_action('rest_api_init', function () {

            remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');

            add_filter('rest_pre_serve_request', function ($value) {

                $allowed_origins = [
                    'https://preprod.nolimit-aventure.com',
                    'https://dev.nolimit-aventure.com',
                    'https://nolimit-aventure.com',
                    'http://localhost:3000',
                    'http://localhost:5173'
                ];

                $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

                if (in_array($origin, $allowed_origins)) {

                    header("Access-Control-Allow-Origin: $origin");

                }

                header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
                header('Access-Control-Allow-Credentials: true');
                header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, X-NoLimit-Key');

                return $value;

            });

        });

    }

}