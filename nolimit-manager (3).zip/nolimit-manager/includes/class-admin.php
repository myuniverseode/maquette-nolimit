<?php
/**
 * Administration NoLimit Manager v8 - COMPLÈTE
 *
 * Gère tous les menus admin, vues et sauvegardes.
 */
if (!defined('ABSPATH')) exit;

class NoLimit_Admin {

    private static array $modules = [];

    public static function init(array $modules): void {
        self::$modules = $modules;
        add_action('admin_notices', [self::class, 'check_acf']);
        add_action('admin_menu', [self::class, 'add_menus']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_assets']);
        add_action('admin_init', [self::class, 'handle_actions']);
    }

    public static function check_acf(): void {
        if (!class_exists('ACF')) {
            echo '<div class="notice notice-error"><p><strong>NoLimit Manager</strong> nécessite ACF. <a href="' . admin_url('plugin-install.php?s=Advanced+Custom+Fields&tab=search') . '">Installer</a></p></div>';
        }
    }

    public static function enqueue_assets(string $hook): void {
        if (strpos($hook, 'nolimit') !== false) {
            wp_enqueue_media();
            wp_enqueue_style('nolimit-admin', NOLIMIT_URL . 'assets/admin.css', [], NOLIMIT_VERSION);
            wp_enqueue_script('nolimit-admin', NOLIMIT_URL . 'assets/admin.js', ['jquery'], NOLIMIT_VERSION, true);
        }
    }

    /* ─── MENUS ─────────────────────────────────────────── */
    public static function add_menus(): void {
        add_menu_page('NoLimit', 'NoLimit', 'edit_posts', 'nolimit-manager', [self::class, 'render_page'], 'dashicons-admin-site-alt3', 30);

        $pages = [
            ['📋 Tableau de bord', 'nolimit-manager'],
            ['⚙️ Header & Footer', 'nolimit-settings'],
            ['Page Accueil',     'nolimit-home'],
            ['Hero / Carousel',  'nolimit-hero'],
            ['Stats & Features', 'nolimit-stats'],
            ['Pour Qui',         'nolimit-pourqui'],
            ['Newsletter',       'nolimit-newsletter'],
            ['Contact',          'nolimit-contact'],
            ['FAQ Config',       'nolimit-faq-config'],
            ['À Propos',         'nolimit-about'],
            ['Blog Config',      'nolimit-blog-config'],
            ['Réservation',      'nolimit-booking'],
            ['Config Globale',   'nolimit-siteconfig'],
            ['Groupes (pages)',  'nolimit-groups'],
            ['🔍 Filtres Parcs', 'nolimit-filters'],
            ['📝 Bloc Texte',    'nolimit-textbloc'],
        ];

        foreach ($pages as $p) {
            add_submenu_page('nolimit-manager', $p[0], $p[0], 'edit_posts', $p[1], [self::class, 'render_page']);
        }

        // CPT links
        $cpts = ['Menu Items' => 'nolimit_menu', 'Parcs' => 'nolimit_parc', 'Activités' => 'nolimit_activity',
                 'FAQ' => 'nolimit_faq', 'Avis' => 'nolimit_review', 'Actualités' => 'nolimit_news',
                 'Blog' => 'nolimit_blog'];
        foreach ($cpts as $label => $cpt) {
            add_submenu_page('nolimit-manager', $label, $label, 'edit_posts', "edit.php?post_type=$cpt");
        }

    }

    /* ─── RENDER (dispatch par slug de page) ───────────── */
    public static function render_page(): void {
        $page = $_GET['page'] ?? 'nolimit-manager';
        $map = [
            'nolimit-manager'    => 'nolimit-manager',
            'nolimit-settings'   => 'main-settings',
            'nolimit-home'       => 'home-settings',
            'nolimit-hero'       => 'hero-settings',
            'nolimit-stats'      => 'stats-settings',
            'nolimit-pourqui'    => 'pourqui-settings',
            'nolimit-newsletter' => 'newsletter-settings',
            'nolimit-contact'    => 'contact-settings',
            'nolimit-faq-config' => 'faq-config-settings',
            'nolimit-groups'     => 'groups-settings',
            'nolimit-about'      => 'about-settings',
            'nolimit-blog-config'=> 'blog-settings',
            'nolimit-booking'    => 'booking-settings',
            'nolimit-siteconfig' => 'siteconfig-settings',
            'nolimit-filters'    => 'filters-settings',
            'nolimit-textbloc'   => 'textbloc-settings',
        ];
        $view = $map[$page] ?? 'main-settings';
        $file = NOLIMIT_PATH . "admin/views/{$view}.php";
        if (file_exists($file)) {
            require $file;
        } else {
            echo "<div class='wrap'><h1>Vue non trouvée</h1><p>Fichier manquant : <code>admin/views/{$view}.php</code></p></div>";
        }
    }

    /* ─── SAVE DISPATCHER ──────────────────────────────── */
    public static function handle_actions(): void {
        $saves = [
            'save_settings'    => ['nolimit_save', 'nolimit_nonce', 'save_main_settings'],
            'save_main_settings' => ['nolimit_save', 'nolimit_nonce', 'save_main_settings'],
            'save_home'        => ['nolimit_save_home', 'home_nonce', 'save_home_settings'],
            'save_hero'        => ['nolimit_save_hero', 'hero_nonce', 'save_hero_settings'],
            'save_stats'       => ['nolimit_save_stats', 'stats_nonce', 'save_stats_settings'],
            'save_pourqui'     => ['nolimit_save_pourqui', 'pourqui_nonce', 'save_pourqui_settings'],
            'save_newsletter'  => ['nolimit_save_newsletter', 'newsletter_nonce', 'save_newsletter_settings'],
            'save_contact'     => ['nolimit_save_contact', 'contact_nonce', 'save_contact_settings'],
            'save_faq_config'  => ['nolimit_save_faq_config', 'faq_config_nonce', 'save_faq_config_settings'],
            'save_groups_page' => ['nolimit_save_groups', 'groups_nonce', 'save_groups_settings'],
            'save_about'       => ['nolimit_save_about', 'about_nonce', 'save_about_settings'],
            'save_blog_config' => ['nolimit_save_blog', 'blog_nonce', 'save_blog_settings'],
            'save_booking'     => ['nolimit_save_booking', 'booking_nonce', 'save_booking_settings'],
            'save_siteconfig'  => ['nolimit_save_siteconfig', 'siteconfig_nonce', 'save_siteconfig_settings'],
            'save_filters'     => ['nolimit_save_filters',   'filters_nonce',    'save_filters_settings'],
            'save_textbloc'    => ['nolimit_save_textbloc', 'textbloc_nonce',   'save_textbloc_settings'],
        ];

        foreach ($saves as $post_key => [$action, $nonce, $method]) {
            if (isset($_POST[$post_key]) && check_admin_referer($action, $nonce)) {
                self::$method();
                add_action('admin_notices', fn() => print '<div class="notice notice-success is-dismissible"><p>✅ Sauvegardé !</p></div>');
            }
        }

        // Defaults
        if (isset($_POST['create_defaults']) && check_admin_referer('nolimit_create_defaults', 'create_defaults_nonce')) {
            NoLimit_Loader::get_instance()->create_all_defaults();
            add_action('admin_notices', fn() => print '<div class="notice notice-success is-dismissible"><p>✅ Données par défaut créées !</p></div>');
        }
    }

    /* ─── SAVE METHODS ─────────────────────────────────── */

    private static function save_main_settings(): void {
        $fields = ['logo_id' => 'int', 'primary' => 'color', 'secondary' => 'color', 'green' => 'color',
            'cta_text' => 'text', 'cta_page_id' => 'int', 'show_parks' => 'bool',
            'f_bg' => 'color', 'f_phone' => 'text', 'f_email' => 'email', 'f_desc' => 'textarea',
            'f_stat1' => 'text', 'f_stat2' => 'text', 'f_stat3' => 'text',
            'f_cta_title' => 'text', 'f_cta_sub' => 'textarea', 'f_show_back' => 'bool'];
        foreach ($fields as $key => $type) {
            self::save_field("nl_{$key}", $key, $type);
        }
        foreach (['social_facebook', 'social_instagram', 'social_youtube', 'social_twitter', 'social_tiktok', 'social_linkedin'] as $s) {
            update_option("nl_{$s}", esc_url_raw($_POST[$s] ?? ''));
        }
        // Quick links + legal links
        $quick = array_filter(array_map('sanitize_text_field', $_POST['quick'] ?? []));
        update_option('nl_f_quick', array_values($quick));
        update_option('nl_f_quick_page_ids', array_map('intval', $_POST['quick_page_id'] ?? []));
        $legal = array_filter(array_map('sanitize_text_field', $_POST['legal'] ?? []));
        update_option('nl_f_legal', array_values($legal));
        update_option('nl_f_legal_page_ids', array_map('intval', $_POST['legal_page_id'] ?? []));
    }

    private static function save_home_settings(): void {
        self::save_field('nl_home_hero_title', 'hero_title', 'text');
        self::save_field('nl_home_hero_subtitle', 'hero_subtitle', 'text');
        self::save_field('nl_home_hero_desc', 'hero_desc', 'textarea');
        self::save_field('nl_home_hero_cta', 'hero_cta', 'text');
        self::save_field('nl_home_hero_video', 'hero_video', 'url');
        self::save_field('nl_home_hero_image_id', 'hero_image_id', 'int');

        foreach (['parcs', 'activities', 'pourqui', 'actualites', 'newsletter', 'reviews', 'groups'] as $s) {
            update_option("nl_home_enable_{$s}", isset($_POST["enable_{$s}"]) ? 1 : 0);
            if (isset($_POST["{$s}_title"])) update_option("nl_home_{$s}_title", sanitize_text_field($_POST["{$s}_title"]));
            if (isset($_POST["{$s}_subtitle"])) update_option("nl_home_{$s}_subtitle", sanitize_text_field($_POST["{$s}_subtitle"]));
            if (isset($_POST["{$s}_max_items"])) update_option("nl_home_{$s}_max_items", intval($_POST["{$s}_max_items"]));
        }
        if (isset($_POST['groups_desc'])) update_option('nl_home_groups_desc', sanitize_textarea_field($_POST['groups_desc']));
        if (isset($_POST['groups_benefits'])) update_option('nl_home_groups_benefits', sanitize_textarea_field($_POST['groups_benefits']));
        self::save_field('nl_home_cta_title', 'cta_title', 'text');
        self::save_field('nl_home_cta_subtitle', 'cta_subtitle', 'text');
    }

    private static function save_hero_settings(): void {
        foreach (['badge_text', 'badge_icon', 'main_line1', 'main_highlight', 'video_btn', 'video_desc'] as $f) {
            self::save_field("nl_hero_{$f}", $f, 'text');
        }
        self::save_field('nl_hero_video_url', 'video_url', 'url');
        self::save_field('nl_hero_video_thumb_id', 'video_thumb_id', 'int');
        for ($i = 1; $i <= 5; $i++) {
            self::save_field("nl_hero_slide_{$i}_image_id", "slide_{$i}_image_id", 'int');
            self::save_field("nl_hero_slide_{$i}_title", "slide_{$i}_title", 'text');
            self::save_field("nl_hero_slide_{$i}_subtitle", "slide_{$i}_subtitle", 'text');
        }
    }

    private static function save_stats_settings(): void {
        for ($i = 1; $i <= 4; $i++) {
            foreach (['value', 'label', 'sublabel', 'icon', 'trend', 'color'] as $f) {
                self::save_field("nl_stat_{$i}_{$f}", "stat_{$i}_{$f}", 'text');
            }
        }
        for ($i = 1; $i <= 3; $i++) {
            self::save_field("nl_feature_{$i}_icon", "feature_{$i}_icon", 'text');
            self::save_field("nl_feature_{$i}_title", "feature_{$i}_title", 'text');
            self::save_field("nl_feature_{$i}_desc", "feature_{$i}_desc", 'textarea');
        }
    }

    private static function save_pourqui_settings(): void {
        // ── Cartes hub ──
        foreach (['duo', 'famille', 'enfant', 'entreprise'] as $id) {
            foreach (['title', 'desc', 'icon', 'link'] as $f) self::save_field("nl_pq_{$id}_{$f}", "pq_{$id}_{$f}", 'text');
            self::save_field("nl_pq_{$id}_color", "pq_{$id}_color", 'color');
            self::save_field("nl_pq_{$id}_image_id", "pq_{$id}_image_id", 'int');
        }

        // ── Page DUO ──
        self::save_field('nl_pq_duo_hero_title', 'pq_duo_hero_title', 'text');
        self::save_field('nl_pq_duo_hero_subtitle', 'pq_duo_hero_subtitle', 'textarea');
        self::save_field('nl_pq_duo_hero_badge', 'pq_duo_hero_badge', 'text');
        self::save_field('nl_pq_duo_intro_title', 'pq_duo_intro_title', 'text');
        self::save_field('nl_pq_duo_intro_text', 'pq_duo_intro_text', 'textarea');
        self::save_repeater_field('nl_pq_duo_moments', 'pq_duo_moments');
        self::save_repeater_field('nl_pq_duo_activities', 'pq_duo_activities');
        self::save_field('nl_pq_duo_pack_title', 'pq_duo_pack_title', 'text');
        self::save_field('nl_pq_duo_pack_discount', 'pq_duo_pack_discount', 'text');
        self::save_field('nl_pq_duo_pack_desc', 'pq_duo_pack_desc', 'textarea');
        self::save_repeater_field('nl_pq_duo_pack_features', 'pq_duo_pack_features');
        self::save_repeater_field('nl_pq_duo_pack_stats', 'pq_duo_pack_stats');
        self::save_repeater_field('nl_pq_duo_testimonials', 'pq_duo_testimonials');
        self::save_field('nl_pq_duo_blog_title', 'pq_duo_blog_title', 'text');
        self::save_field('nl_pq_duo_blog_subtitle', 'pq_duo_blog_subtitle', 'text');
        self::save_field('nl_pq_duo_cta_title', 'pq_duo_cta_title', 'text');
        self::save_field('nl_pq_duo_cta_subtitle', 'pq_duo_cta_subtitle', 'text');

        // ── Page ENFANT ──
        self::save_field('nl_pq_enfant_hero_title', 'pq_enfant_hero_title', 'text');
        self::save_field('nl_pq_enfant_hero_subtitle', 'pq_enfant_hero_subtitle', 'textarea');
        self::save_field('nl_pq_enfant_hero_badge', 'pq_enfant_hero_badge', 'text');
        self::save_field('nl_pq_enfant_intro_title', 'pq_enfant_intro_title', 'text');
        self::save_field('nl_pq_enfant_intro_text', 'pq_enfant_intro_text', 'textarea');
        self::save_repeater_field('nl_pq_enfant_activities', 'pq_enfant_activities');
        self::save_repeater_field('nl_pq_enfant_safety', 'pq_enfant_safety');
        self::save_field('nl_pq_enfant_birthday_title', 'pq_enfant_birthday_title', 'text');
        self::save_field('nl_pq_enfant_birthday_desc', 'pq_enfant_birthday_desc', 'textarea');
        self::save_field('nl_pq_enfant_birthday_price', 'pq_enfant_birthday_price', 'text');
        self::save_field('nl_pq_enfant_birthday_capacity', 'pq_enfant_birthday_capacity', 'text');
        self::save_repeater_field('nl_pq_enfant_birthday_features', 'pq_enfant_birthday_features');
        self::save_repeater_field('nl_pq_enfant_testimonials', 'pq_enfant_testimonials');
        self::save_field('nl_pq_enfant_cta_title', 'pq_enfant_cta_title', 'text');
        self::save_field('nl_pq_enfant_cta_subtitle', 'pq_enfant_cta_subtitle', 'text');

        // ── Page ENTREPRISE ──
        self::save_field('nl_pq_entreprise_hero_title', 'pq_entreprise_hero_title', 'text');
        self::save_field('nl_pq_entreprise_hero_subtitle', 'pq_entreprise_hero_subtitle', 'textarea');
        self::save_field('nl_pq_entreprise_hero_badge', 'pq_entreprise_hero_badge', 'text');
        self::save_repeater_field('nl_pq_entreprise_kpis', 'pq_entreprise_kpis');
        self::save_repeater_field('nl_pq_entreprise_formats', 'pq_entreprise_formats');
        self::save_repeater_field('nl_pq_entreprise_advantages', 'pq_entreprise_advantages');
        self::save_repeater_field('nl_pq_entreprise_logos', 'pq_entreprise_logos');
        self::save_repeater_field('nl_pq_entreprise_testimonials', 'pq_entreprise_testimonials');
        self::save_field('nl_pq_entreprise_phone', 'pq_entreprise_phone', 'text');
        self::save_field('nl_pq_entreprise_email', 'pq_entreprise_email', 'email');
        self::save_field('nl_pq_entreprise_form_title', 'pq_entreprise_form_title', 'text');
        self::save_field('nl_pq_entreprise_form_subtitle', 'pq_entreprise_form_subtitle', 'text');

        // ── Page FAMILLE ──
        self::save_field('nl_pq_famille_hero_title', 'pq_famille_hero_title', 'text');
        self::save_field('nl_pq_famille_hero_subtitle', 'pq_famille_hero_subtitle', 'textarea');
        self::save_field('nl_pq_famille_hero_badge', 'pq_famille_hero_badge', 'text');
        self::save_field('nl_pq_famille_intro_title', 'pq_famille_intro_title', 'text');
        self::save_field('nl_pq_famille_intro_text', 'pq_famille_intro_text', 'textarea');
        self::save_repeater_field('nl_pq_famille_age_groups', 'pq_famille_age_groups');
        self::save_repeater_field('nl_pq_famille_packs', 'pq_famille_packs');
        self::save_field('nl_pq_famille_event_title', 'pq_famille_event_title', 'text');
        self::save_field('nl_pq_famille_event_desc', 'pq_famille_event_desc', 'textarea');
        self::save_repeater_field('nl_pq_famille_event_tags', 'pq_famille_event_tags');
        self::save_repeater_field('nl_pq_famille_practical', 'pq_famille_practical');
        self::save_repeater_field('nl_pq_famille_testimonials', 'pq_famille_testimonials');
        self::save_field('nl_pq_famille_blog_title', 'pq_famille_blog_title', 'text');
        self::save_field('nl_pq_famille_blog_subtitle', 'pq_famille_blog_subtitle', 'text');
        self::save_field('nl_pq_famille_cta_title', 'pq_famille_cta_title', 'text');
        self::save_field('nl_pq_famille_cta_subtitle', 'pq_famille_cta_subtitle', 'text');
    }

    private static function save_newsletter_settings(): void {
        foreach (['title', 'subtitle', 'placeholder', 'button', 'privacy', 'success'] as $f) {
            self::save_field("nl_nl_{$f}", "nl_{$f}", ($f === 'subtitle' || $f === 'privacy') ? 'textarea' : 'text');
        }
        self::save_field('nl_nl_brevo_api_key', 'nl_brevo_api_key', 'text');
        self::save_field('nl_nl_brevo_list_id', 'nl_brevo_list_id', 'text');
        for ($i = 1; $i <= 3; $i++) {
            foreach (['icon', 'title', 'desc'] as $f) self::save_field("nl_nl_benefit_{$i}_{$f}", "benefit_{$i}_{$f}", 'text');
        }
    }

    private static function save_contact_settings(): void {
        foreach (['title', 'subtitle', 'hours', 'success_msg'] as $f) self::save_field("nl_contact_{$f}", "contact_{$f}", 'text');
        self::save_field('nl_contact_address', 'contact_address', 'textarea');
        self::save_field('nl_contact_map_url', 'contact_map_url', 'url');
        self::save_field('nl_contact_subjects', 'contact_subjects', 'textarea');
    }

    private static function save_faq_config_settings(): void {
        self::save_field('nl_faq_title', 'faq_title', 'text');
        self::save_field('nl_faq_subtitle', 'faq_subtitle', 'text');
        self::save_field('nl_faq_categories', 'faq_categories', 'textarea');
    }

    private static function save_groups_settings(): void {
        self::save_field('nl_groups_hero_title', 'hero_title', 'text');
        self::save_field('nl_groups_hero_subtitle', 'hero_subtitle', 'textarea');
        self::save_field('nl_groups_hero_image_id', 'hero_image_id', 'int');
        self::save_field('nl_groups_benefits_title', 'benefits_title', 'text');
        self::save_field('nl_groups_benefits_desc', 'benefits_desc', 'textarea');
        self::save_field('nl_groups_benefits', 'benefits', 'textarea');
        self::save_field('nl_groups_cta_title', 'cta_title', 'text');
        self::save_field('nl_groups_cta_subtitle', 'cta_subtitle', 'text');
        self::save_field('nl_groups_cta_btn', 'cta_btn', 'text');
        self::save_field('nl_groups_cta_url', 'cta_url', 'text');
        self::save_field('nl_groups_cse_title', 'cse_title', 'text');
        self::save_field('nl_groups_cse_subtitle', 'cse_subtitle', 'text');
        // JSON fields
        self::save_repeater_field('nl_groups_categories', 'groups_categories');
        self::save_repeater_field('nl_groups_stats', 'groups_stats');
        self::save_repeater_field('nl_groups_testimonials', 'groups_testimonials');
    }

    private static function save_about_settings(): void {
        foreach (['hero_title', 'hero_subtitle'] as $f) self::save_field("nl_about_{$f}", "about_{$f}", 'text');
        self::save_field('nl_about_vision', 'about_vision', 'textarea');
        self::save_field('nl_about_history_title', 'about_history_title', 'text');
        self::save_field('nl_about_history_subtitle', 'about_history_subtitle', 'text');
        self::save_field('nl_about_values_title', 'about_values_title', 'text');
        self::save_field('nl_about_values_subtitle', 'about_values_subtitle', 'text');
        self::save_field('nl_about_jobs_title', 'about_jobs_title', 'text');
        self::save_field('nl_about_jobs_subtitle', 'about_jobs_subtitle', 'text');
        self::save_field('nl_about_jobs_email', 'about_jobs_email', 'email');
        self::save_field('nl_about_jobs_spontaneous_text', 'about_jobs_spontaneous_text', 'text');
        update_option('nl_about_jobs_spontaneous', isset($_POST['about_jobs_spontaneous']) ? 1 : 0);
        self::save_field('nl_about_partners_title', 'about_partners_title', 'text');
        self::save_field('nl_about_partners_subtitle', 'about_partners_subtitle', 'text');
        self::save_field('nl_about_rse_title', 'about_rse_title', 'text');
        self::save_field('nl_about_rse_subtitle', 'about_rse_subtitle', 'text');
        // JSON / Repeater fields
        foreach (['nav_cards', 'stats', 'timeline', 'history_stats', 'vision_metrics', 'values', 'manifesto', 'perks', 'positions', 'partners', 'rse'] as $j) {
            self::save_repeater_field("nl_about_{$j}", "nl_about_{$j}");
        }
    }

    private static function save_blog_settings(): void {
        self::save_field('nl_blog_title', 'blog_title', 'text');
        self::save_field('nl_blog_subtitle', 'blog_subtitle', 'text');
    }

    private static function save_booking_settings(): void {
        self::save_field('nl_booking_title', 'booking_title', 'text');
        self::save_field('nl_booking_subtitle', 'booking_subtitle', 'text');
        self::save_field('nl_booking_quickle_url', 'booking_quickle_url', 'url');
        update_option('nl_booking_quickle_enabled', isset($_POST['booking_quickle_enabled']) ? 1 : 0);
        update_option('nl_booking_enabled', isset($_POST['booking_enabled']) ? 1 : 0);
        self::save_field('nl_booking_min_participants', 'booking_min_participants', 'int');
        self::save_field('nl_booking_max_participants', 'booking_max_participants', 'int');
        self::save_field('nl_booking_closed_msg', 'booking_closed_msg', 'text');
        self::save_repeater_field('nl_booking_time_slots', 'booking_time_slots');
    }

    private static function save_siteconfig_settings(): void {
        foreach (['social_tiktok', 'social_linkedin'] as $s) {
            update_option("nl_{$s}", esc_url_raw($_POST[$s] ?? ''));
        }
        foreach (['anchor_menu', 'activity_filters', 'accessibility', 'onsite_services', 'pricing_types', 'transport', 'difficulty_levels', 'audience_types'] as $j) {
            self::save_repeater_field("nl_{$j}", $j);
        }
        // Save park-specific anchor menus
        $parcs = get_posts(['post_type' => 'nolimit_parc', 'posts_per_page' => -1]);
        foreach ($parcs as $parc) {
            $slug = get_field('parc_slug', $parc->ID) ?: sanitize_title($parc->post_title);
            $key = 'park_anchor_' . $slug;
            self::save_repeater_field('nl_park_' . $slug . '_anchor_menu', $key);
        }
    }



    private static function save_filters_settings(): void {
        // Activités
        $activities = [];
        foreach ((array) ($_POST['filter_activities'] ?? []) as $item) {
            if (empty($item['id'])) continue;
            $activities[] = [
                'id'     => sanitize_key($item['id']),
                'label'  => sanitize_text_field($item['label'] ?? ''),
                'emoji'  => sanitize_text_field($item['emoji'] ?? '⭐'),
                'active' => !empty($item['active']),
            ];
        }
        if (!empty($activities)) {
            update_option('nl_filters_activities', wp_json_encode($activities, JSON_UNESCAPED_UNICODE));
        }

        // Transport
        $transport = [];
        foreach ((array) ($_POST['filter_transport'] ?? []) as $item) {
            if (empty($item['label'])) continue;
            $transport[] = [
                'id'          => sanitize_key($item['id'] ?? ''),
                'label'       => sanitize_text_field($item['label']),
                'icon'        => sanitize_text_field($item['icon'] ?? 'Car'),
                'description' => sanitize_text_field($item['description'] ?? ''),
                'active'      => !empty($item['active']),
            ];
        }
        if (!empty($transport)) {
            update_option('nl_filters_transport', wp_json_encode($transport, JSON_UNESCAPED_UNICODE));
        }

        // Types d'événement
        $event_types = [];
        foreach ((array) ($_POST['filter_event_types'] ?? []) as $item) {
            if (empty($item['id'])) continue;
            $event_types[] = [
                'id'      => sanitize_key($item['id']),
                'label'   => sanitize_text_field($item['label'] ?? ''),
                'emoji'   => sanitize_text_field($item['emoji'] ?? '🎉'),
                'popular' => !empty($item['popular']),
                'active'  => !empty($item['active']),
            ];
        }
        if (!empty($event_types)) {
            update_option('nl_filters_event_types', wp_json_encode($event_types, JSON_UNESCAPED_UNICODE));
        }
    }

    private static function save_textbloc_settings(): void {
        update_option('nl_textbloc_enabled',        isset($_POST['textbloc_enabled']) ? 1 : 0);
        update_option('nl_textbloc_badge',          sanitize_text_field($_POST['textbloc_badge']             ?? ''));
        update_option('nl_textbloc_title',          sanitize_text_field($_POST['textbloc_title']             ?? ''));
        update_option('nl_textbloc_text',           sanitize_textarea_field($_POST['textbloc_text']          ?? ''));
        update_option('nl_textbloc_text_secondary', sanitize_textarea_field($_POST['textbloc_text_secondary'] ?? ''));
        update_option('nl_textbloc_cta_label',      sanitize_text_field($_POST['textbloc_cta_label']         ?? ''));
        update_option('nl_textbloc_cta_url',        sanitize_text_field($_POST['textbloc_cta_url']           ?? ''));

        $stats = [];
        foreach ((array) ($_POST['textbloc_stats'] ?? []) as $row) {
            $val = sanitize_text_field($row['value']    ?? '');
            $lbl = sanitize_text_field($row['label']    ?? '');
            $sub = sanitize_text_field($row['sublabel'] ?? '');
            if ($val !== '' || $lbl !== '') {
                $stats[] = ['value' => $val, 'label' => $lbl, 'sublabel' => $sub];
            }
        }
        update_option('nl_textbloc_stats', wp_json_encode($stats, JSON_UNESCAPED_UNICODE));
    }

    /* ─── HELPERS ───────────────────────────────────────── */
    private static function save_field(string $option, string $post_key, string $type): void {
        $val = $_POST[$post_key] ?? '';
        switch ($type) {
            case 'int':      update_option($option, intval($val)); break;
            case 'bool':     update_option($option, isset($_POST[$post_key]) ? 1 : 0); break;
            case 'color':    update_option($option, sanitize_hex_color($val) ?: $val); break;
            case 'email':    update_option($option, sanitize_email($val)); break;
            case 'url':      update_option($option, esc_url_raw($val)); break;
            case 'textarea': update_option($option, sanitize_textarea_field($val)); break;
            default:         update_option($option, sanitize_text_field($val)); break;
        }
    }

    private static function save_json_field(string $option, string $post_key): void {
        $raw = $_POST[$post_key] ?? '';
        if (is_string($raw) && $raw) {
            $decoded = json_decode(stripslashes($raw), true);
            if (is_array($decoded)) { update_option($option, wp_json_encode($decoded)); return; }
        }
        update_option($option, $raw);
    }

    /**
     * Save a repeater field: accepts PHP array from HTML name="field[0][key]" inputs,
     * sanitizes all values, re-indexes, and stores as JSON.
     * Also supports simple arrays: name="field[0]" (string values).
     */
    private static function save_repeater_field(string $option, string $post_key): void {
        $raw = $_POST[$post_key] ?? [];

        // If it's a string (legacy JSON textarea fallback), handle it the old way
        if (is_string($raw)) {
            self::save_json_field($option, $post_key);
            return;
        }

        if (!is_array($raw) || empty($raw)) {
            update_option($option, '[]');
            return;
        }

        $items = [];
        foreach ($raw as $row) {
            if (is_string($row)) {
                // Simple repeater (flat array of strings)
                $val = sanitize_text_field(trim($row));
                if ($val !== '') $items[] = $val;
            } elseif (is_array($row)) {
                // Structured repeater (array of objects)
                $clean = [];
                $has_value = false;
                foreach ($row as $key => $value) {
                    $clean_val = sanitize_text_field(trim($value));
                    $clean[$key] = $clean_val;
                    if ($clean_val !== '') $has_value = true;
                }
                if ($has_value) $items[] = $clean;
            }
        }

        update_option($option, wp_json_encode(array_values($items), JSON_UNESCAPED_UNICODE));
    }
}
