<?php
/**
 * Fonctions utilitaires partagées.
 */

if (!defined('ABSPATH')) exit;

class NoLimit_Helpers {

    /**
     * Récupère l'URL du logo.
     */
    public static function get_logo_url(): string {
        $logo_id = get_option('nl_logo_id', 0);
        return $logo_id ? wp_get_attachment_url($logo_id) : '';
    }

    /**
     * Récupère les couleurs du site.
     */
    public static function get_colors(): array {
        return [
            'primary'   => get_option('nl_primary', '#f97316'),
            'secondary' => get_option('nl_secondary', '#eb700f'),
            'green'     => get_option('nl_green', '#357600'),
        ];
    }

    /**
     * Récupère un champ ACF avec fallback.
     */
    public static function acf(string $field, $post_id = null, $default = '') {
        if (!function_exists('get_field')) {
            return $default;
        }
        $value = get_field($field, $post_id);
        return ($value !== null && $value !== false && $value !== '') ? $value : $default;
    }

    /**
     * Retourne le slug relatif d'une page par son ID, utilisable comme route React.
     * Ex : page "CGV" avec slug "cgv" -> "/cgv"
     * Si page_id = 0 ou page introuvable -> retourne $fallback.
     */
    public static function page_url(int $page_id, string $fallback = '/'): string {
        if (!$page_id) return $fallback;
        $post = get_post($page_id);
        if (!$post || $post->post_status !== 'publish') return $fallback;
        // Slug relatif compatible React Router
        $path = '/' . ltrim(str_replace(home_url(), '', get_permalink($page_id)), '/');
        return $path !== '/' ? rtrim($path, '/') : $path;
    }
}
