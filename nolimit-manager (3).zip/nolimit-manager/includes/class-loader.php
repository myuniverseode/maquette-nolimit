<?php



if (!defined('ABSPATH')) exit;



class NoLimit_Loader {



    private static $instance = null;



    /** @var NoLimit_Module[] */

    private array $modules = [];



    public static function get_instance(): self {

        if (self::$instance === null) {

            self::$instance = new self();

        }

        return self::$instance;

    }



    private function __construct() {



        $this->load_modules();



        add_action('init', [$this, 'init_post_types']);

        add_action('rest_api_init', [$this, 'init_api']);

        add_action('acf/init', [$this, 'init_acf']);



        // Admin

        NoLimit_Admin::init($this->modules);



        // CORS

        NoLimit_CORS::init();



        // Activation

        register_activation_hook(NOLIMIT_PATH . 'nolimit-manager.php', [$this, 'activate']);

    }



    /**

     * Vérifie la clé API

     */

    public function check_api_key($request) {



        $key = $request->get_header('x-nolimit-key');



        if ($key !== '123456789') { 



            return new WP_Error(

                'forbidden',

                'Invalid API key',

                ['status' => 403]

            );



        }



        return true;

    }



    /**

     * Scanne le dossier modules/

     */

    private function load_modules(): void {



        $modules_dir = NOLIMIT_PATH . 'modules/';



        foreach (glob($modules_dir . '*/class-*.php') as $file) {



            $classes_before = get_declared_classes();



            require_once $file;



            $classes_after = get_declared_classes();



            $new_classes = array_diff($classes_after, $classes_before);



            foreach ($new_classes as $class) {



                if (is_subclass_of($class, 'NoLimit_Module')) {



                    $this->modules[] = new $class();



                }



            }



        }



    }



    /**

     * Enregistre CPT et taxonomies

     */

    public function init_post_types(): void {



        foreach ($this->modules as $module) {



            $module->register_post_types();

            $module->register_taxonomies();



        }



    }



    /**

     * Enregistre les routes API

     */

    public function init_api(): void {



        foreach ($this->modules as $module) {



            foreach ($module->get_api_routes() as $route => $config) {



                if (isset($config[0]) && is_array($config[0])) {



                    $args = [];



                    foreach ($config as $c) {



                        $args[] = [

                            'methods'             => $c['methods'] ?? 'GET',

                            'callback'            => $c['callback'],

                            'permission_callback' => $c['permission_callback'] ?? (($c['methods'] ?? 'GET') === 'GET' ? '__return_true' : [$this, 'check_api_key']),

                        ];



                    }



                } else {



                    $args = [

                        'methods'             => $config['methods'] ?? 'GET',

                        'callback'            => $config['callback'],

                        'permission_callback' => $config['permission_callback'] ?? (($config['methods'] ?? 'GET') === 'GET' ? '__return_true' : [$this, 'check_api_key']),

                    ];



                }



                register_rest_route(NOLIMIT_API_NS, '/' . $route, $args);



            }



        }



    }



    /**

     * Enregistre les champs ACF

     */

    public function init_acf(): void {



        if (!function_exists('acf_add_local_field_group')) return;



        foreach ($this->modules as $module) {



            $module->register_acf_fields();



        }



    }



    /**

     * Crée les données par défaut

     */

    public function create_all_defaults(): void {



        foreach ($this->modules as $module) {



            $module->create_defaults();



        }



    }



    /**

     * Activation du plugin

     */

    public function activate(): void {



        $this->init_post_types();



        flush_rewrite_rules();



    }



    /**

     * Accès aux modules

     */

    public function get_modules(): array {



        return $this->modules;



    }



}