<?php
/**
 * Classe abstraite de base pour tous les modules.
 *
 * Chaque module DOIT étendre cette classe et implémenter au minimum :
 *   - get_api_routes() : définir les routes REST
 *
 * Méthodes optionnelles à surcharger :
 *   - register_post_types()  : créer des CPT
 *   - register_taxonomies()  : créer des taxonomies
 *   - register_acf_fields()  : déclarer les champs ACF
 *   - create_defaults()      : données par défaut
 *   - get_admin_config()     : config pour la page admin principale
 */

if (!defined('ABSPATH')) exit;

abstract class NoLimit_Module {

    // ─── À implémenter ───────────────────────────────────────

    /**
     * Retourne les routes REST du module.
     *
     * Format :
     * [
     *     'parks' => [                      // route : /nolimit/v1/parks
     *         'methods'  => 'GET',
     *         'callback' => [$this, 'api_list'],
     *     ],
     *     'parks/(?P<id>[a-zA-Z0-9-]+)' => [
     *         'methods'  => 'GET',
     *         'callback' => [$this, 'api_single'],
     *     ],
     * ]
     *
     * @return array
     */
    abstract public function get_api_routes(): array;

    // ─── Optionnels (à surcharger si besoin) ─────────────────

    /** Enregistrer des Custom Post Types. */
    public function register_post_types(): void {}

    /** Enregistrer des taxonomies. */
    public function register_taxonomies(): void {}

    /** Enregistrer des champs ACF via acf_add_local_field_group(). */
    public function register_acf_fields(): void {}

    /** Créer des données par défaut (contenu de démo). */
    public function create_defaults(): void {}

    // ─── Helpers disponibles dans tous les modules ───────────

    /**
     * Raccourci get_option() avec valeur par défaut.
     */
    protected function opt(string $key, $default = '') {
        $val = get_option($key, $default);
        return is_string($val) ? wp_unslash($val) : $val;
    }

    /**
     * Raccourci get_field() ACF avec fallback.
     */
    protected function acf(string $field, $post_id = null, $default = '') {
        if (!function_exists('get_field')) {
            return $default;
        }
        $value = get_field($field, $post_id);
        return ($value !== null && $value !== false && $value !== '') ? $value : $default;
    }

    /**
     * Query rapide sur un CPT, retourne un tableau de WP_Post.
     */
    protected function query(string $post_type, int $limit = -1, string $orderby = 'menu_order', string $order = 'ASC'): array {
        if (!post_type_exists($post_type)) {
            return [];
        }
        return get_posts([
            'post_type'      => $post_type,
            'posts_per_page' => $limit,
            'orderby'        => $orderby,
            'order'          => $order,
        ]);
    }
}
